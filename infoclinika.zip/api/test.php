<?

	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	\Bitrix\Main\Loader::includeModule('catalog');
	\Bitrix\Main\Loader::includeModule('sale');
	
	global $USER;
	
	$USER->Authorize(1);
	

	$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(2);
	
	$item=$factory156->getItem(515);
	
	print_r($item['CATEGORY_ID']);
	

	
	
		$property_enums = CIBlockPropertyEnum::GetList(Array("DEF"=>"DESC", "SORT"=>"ASC"), Array(""));
while($enum_fields = $property_enums->GetNext())
{
print_r($enum_fields);	
}	
	