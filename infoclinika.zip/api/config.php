<?

$COMPANY='bestclinic';
$CODE='dsfsdfsdfsdfsdfsdffsfsdfsd';  // Сменил для портфолио



?>