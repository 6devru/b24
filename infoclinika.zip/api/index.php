<?

set_time_limit(0);

ini_set('max_execution_time', 36000);

define('TEST','Y');
define('ID_TYPE_VRACH','2');

$uuu=[];
$vrachs=array('798','20001275','30021212');
global $vrachs;
// Врачи которые закрытые автоматом

function AddLog($s,$n)
{

	$f=fopen($_SERVER["DOCUMENT_ROOT"].'/api/logs/'.$n.'.txt','a');
	fwrite($f,$s."\r\n\r\n");
	fclose($f);	

}

//

	$ld=date('dmY',time());

AddLog(date('H:i:s').':'.$_SERVER['REQUEST_URI'].'@'.print_r($_REQUEST,true),'times'.$ld);

define('UF_CRM_2_1708942581339','UF_CRM_2_1708942581339');   // - ID Врача в смарт процессе



///////// Cоздать обязательные поля
/*


UF_CRM_1672233998  -  ID визита  (строка)
UF_CRM_1672234220  - Назначение  (Привязка к элементам инф. блоков, каталог)

сделки

UF_CRM_1672234490 - Врач (специалист) из запланированного визита (Пользователь)
UF_CRM_1674746402 - Дата предварительной записи
UF_CRM_1665671917386 - Рекомендации
UF_CRM_1672234696 - Диагноз визита
UF_CRM_1674745471 - Тип визита
UF_CRM_1665671704049 - Дата и время записи
UF_CRM_1705413461 - Врач (Смартпроцесс)



Контакты:

UF_CRM_1665672224147  - пол
UF_CRM_1665672449531  - номер полиса
UF_CRM_1665672430009  - Страховая компания
UF_CRM_1665672515999  - Дата создания
UF_CRM_1665672361821  - Дата последнего посещения
UF_CRM_1665672289879  - Дата следующего посещения
F_CRM_1676469377058  -  Номер карты
UF_CRM_1686143426     -  Дата exit



if ($arr['refuseclmail']==1)  $arParams['UF_CRM_1676900488']='1';  // Пациен отказывается от рассылок
		if ($arr['refusecall']==1)  $arParams['UF_CRM_1676890703402']='1';
		if ($arr['refusesms']==0)  $arParams['UF_CRM_1676900702']='454';
		if ($arr['refusesms']==1)  $arParams['UF_CRM_1676900702']='455';
		if ($arr['refusesms']==2)  $arParams['UF_CRM_1676900702']='456';
		if ($arr['refusesms']==3)  $arParams['UF_CRM_1676900702']='457';




*/
////////  Для пользователя UF_OR  define('','');

// Статусы

define('status_new','PREPARATION');
define('status_online','NEW');
define('status_lose','LOSE');
define('status_won','WON');
define('status_in','FINAL_INVOICE');


// Новые поля для UF_CRM_1699610429

define('UF_CRM_1699610429','UF_CRM_1699610429'); // Обязательное поле врач
define('UF_CRM_1700650365','UF_CRM_1700650365');  // Дата следующего визита (была только в контаках а тут в  сделках
define('UF_CRM_1712751207','UF_CRM_1712751207');  // Дата завершения

define('UF_CRM_1712750486','UF_CRM_1712750486'); // Филиал
define('UF_CRM_1714218742','UF_CRM_1714218742'); // Департамент

define('UF_CRM_1714223722','UF_CRM_1714223722'); // Кабинет
define('UF_CRM_1712750625','UF_CRM_1712750625');  // Врач

define('UF_CRM_1715677082','UF_CRM_1715677082'); // ID в ИК сделки

define('UF_CRM_1715771784','UF_CRM_1715771784'); // Создать для лида УИП


define('IBLOCK_FILIAL','17');
define('IBLOCK_CABINET','65');
define('IBLOCK_TYPE',56);

define('TYPE_SMART_QUEUE',16);  // Тип свойства для смарта очереди
define('TYPE_SMART_PLAN',15);  // Тип свойства для смарта очереди
define("ID_SMART_VRACH",156);  // Смарт процесс врачей
define("ID_SMART_QUEUE",144);  // Смарт для Очереди
define("ID_SMART_PLAN",151);  // Смарт для Планы


// Поля для компании
define('UF_CRM_1714724732','UF_CRM_1714724732'); // Краткое название
define('UF_CRM_1714724762','UF_CRM_1714724762'); // Контакт (ФИО руководителя)
define('UF_CRM_1714724795','UF_CRM_1714724795'); // Контакт (ФИО бухгалтера)
define('UF_CRM_1714725006','UF_CRM_1714725006'); // Сфера деятельности


//////////////

// Сделки

define('UF_CRM_1672233998','UF_CRM_1714216160');  // ID Визита в расписании
define('UF_CRM_1672234220','UF_CRM_1702541203');  // Назначение

define('UF_CRM_1672234490','UF_CRM_1702541263');  // Врач из запланированного визита

define('UF_CRM_1705413461','UF_CRM_1705413461');  // Врач



define('UF_CRM_1674746402','UF_CRM_1712750980'); // Дата предварительной записи 

define('UF_CRM_1665671917386','UF_CRM_1702541605'); // Рекомендации
define('UF_CRM_1672234696','UF_CRM_1702541714'); // Диагноз визита

define('UF_CRM_1674745471','UF_CRM_1712749662'); // Тип визита

define('UF_CRM_1665671704049','UF_CRM_1699610665');  // Дата и время записи
define('UF_CRM_1712751011','UF_CRM_1717655766'); // Дата создания записи



//// Контакты

define('UF_CRM_1665672224147','UF_CRM_1712748122397'); // Пол
define('UF_CRM_1665672449531','UF_CRM_1712748976115'); // Номер полиса

define('UF_CRM_1665672430009','UF_CRM_1712748939183'); // Страховая компания

define('UF_CRM_1665672515999','UF_CRM_1714203258'); // Дата создания контакта

define('UF_CRM_1665672361821','UF_CRM_1712748622');  // Дата последнего
define('UF_CRM_1665672289879','UF_CRM_1712748205156');  // Дата следующего посещения

define('UF_CRM_1676469377058','UF_CRM_1712748744357'); // Номер карты

define('UF_CRM_1714205621','UF_CRM_1714205621'); // Комментарий для записи
define('UF_CRM_1714205773','UF_CRM_1714205773'); // Условия обслуживания



define('UF_CRM_1714206433','UF_CRM_1714206433'); // Программа обслуживания
define('UF_CRM_1714206777','UF_CRM_1714206777'); // Срок действия условий обслуживания (начало)
define('UF_CRM_1714206839','UF_CRM_1714206839'); // Срок действия условий обслуживания (конец)
define('UF_CRM_1714206904','UF_CRM_1714206904'); // УИП из МИС ИК
define('UF_CRM_1714207605','UF_CRM_1714207605'); // Представитель

define('UF_CRM_1714207780','UF_CRM_1714207780'); // Компания



define('UF_CRM_1676900488','UF_CRM_1714209327'); // Пациент отказывается от рассылок на почту

define('UF_CRM_1676890703402','UF_CRM_1714203430'); // Пациент просил ему не звонить


define('UF_CRM_1676900702','UF_CRM_1714205244'); // Рассылка SMS


	define('USER_ADMIN',1);
	define('IBLOCK_SECTION',3); // Структура компании
	define('DOMEN','mos-clinics.ru'); // если у пользователя нет емейла, он создает для данного домена
	define('IBLOCK_CATALOG',14);  // Инфоблок с услугами
	
	define('IBLOCK_DEP',18);
	
	
	define("TOVAR_SEC",235); // Раздел товаров
	define("SERVICE_SEC",236); // Раздел услуг
	
	define("SERVICE_SEC_NO",237); // Раздел услуг другие (бросаем туда остатки)
	
	define('SECTION_SERVICE',false); // Раздел с услугами
	define('ASSIGNED_BY_ID',94);  // Пользователь от чего имени происходит наполнение (если не указано в данных обратное(
	
	
	

	
//	define('TEST','Y');  // Если Y то позволяет отправлять запрос через ?get=    и без SH
	define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	header("Access-Control-Allow-Headers: X-Requested-With");	
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');

use Bitrix\Crm\Service;

\Bitrix\Main\Loader::includeModule('crm');
	\Bitrix\Main\Loader::includeModule('catalog');
	\Bitrix\Main\Loader::includeModule('sale');
	
	global $USER;
	
	$USER->Authorize(USER_ADMIN);
	
$OK='OK';
	
	$sol="3e74a21d15194c7251dc4090293435f4";

global $MESSAGES;
$MESSAGES=array();
 
function AddError($message)
{
	global $MESSAGES;
	if ($message!='') $MESSAGES[]=$message;
}

function function4034($arr)
{

// Найти филиал для данной сделки 
$idf=0;
$idD=0;
if ($arr['id']>0) {
$deal = new CCrmDeal(false);
$deals=$deal->GetList([],["ORIGIN_ID"=>$arr['id']])->fetch();
$idD=$deals['ID'];
}

	if ($arr['filial']>0) {

$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields22 = $ob->GetFields();
	$idf=$arFields22['ID'];
}
	
	
		}
		
		
if ($arr['client_id']>0) {

// UF_CRM_1714206904 
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),array(UF_CRM_NUMBER_POLICA=>$arr['client_id']),array("*", "UF_*", "PHONE", "IM"));		
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}
		
} 

////////////////////// Найти завершенные сделки для данного клиента и филиала



$arFD=array('CONTACT_ID'=>$crma['ID'],'UF_CRM_1712750486'=>$idf,"STAGE_ID"=>'WON');
$res2=CCrmDEal::GetList(array('DATE_CREATE' => 'DESC'),$arFD,array("*", "UF_*", "PHONE", "IM","STAGE_ID"));
		if ($res2->SelectedRowsCount()>0)
		{
		$crma2=$res2->fetch();
		
		

		
		$deal = new CCrmDeal(false);			
		$arFieldsA=array('UF_CRM_1712750795'=>4956);
		$deal->Update($idD,$arFieldsA);	
		

			
		
		}  else {
			
			//
			
		$deal = new CCrmDeal(false);			
		

		
		$arFieldsA=array('UF_CRM_1712750795'=>4955);
		$deal->Update($idD,$arFieldsA);	
			
			
	
			
		}
		

		
///////////////////// 


		
// 
	
}

function function4026($arr)
{
	//
	

	
// Найти для данного $arr['client_id'] контакт а для контакта UF_CRM_1714206904  

$idD=0;
$dealId=0;

if ($arr['id']>0) {
$deal = new CCrmDeal(false);
$deals=$deal->GetList([],["ORIGIN_ID"=>$arr['id']])->fetch();
$idD=$deals['ID'];
}


// Найти сделку,  обновить по сделке данные LEAD_ID


if ($arr['client_id']>0) {

// UF_CRM_1714206904 
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),array(UF_CRM_NUMBER_POLICA=>$arr['client_id']),array("*", "UF_*", "PHONE", "IM"));		
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}
		
} 

if ( ($crma['ID']>0) && ($crma[UF_CRM_1714206904]>0) ) {
	
	$res2=CCrmLead::GetList(array('DATE_CREATE' => 'DESC'),array(UF_CRM_1715771784=>$crma[UF_CRM_1714206904]),array("*", "UF_*", "STAGE_ID"));
	
	
		if ($res2->SelectedRowsCount()>0)
		{
		$crma2=$res2->fetch();
		
		$crma2=CCrmLead::getByID($crma2['ID']);
				
		if ($crma2['STATUS_ID']=='NEW') {
			
			$entity = new CCrmLead; 
			
			$a=array('STATUS_ID'=>'CONVERTED');
			$entity->Update($crma2['ID'],$a);
			
			
			$arFieldsA=array('LEAD_ID'=>$crma2['ID']);
			if ($idD>0)  {
				$dealId = $deal->Update($idD,$arFieldsA);
				echo 'Обновить '.$idD.'<br>';
			}
			
			

			
		}
		
		}


    $res2=CCrmLead::GetList(array('DATE_CREATE' => 'DESC'),array('CONTACT_ID'=>$crma['ID']),array("*", "UF_*", "STAGE_ID"));

	if ($res2->SelectedRowsCount()>0)
	{
		$crma2=$res2->fetch();

		$crma2=CCrmLead::getByID($crma2['ID']);

		if ($crma2['STATUS_ID']=='NEW') {

			$entity = new CCrmLead;

			$a=array('STATUS_ID'=>'CONVERTED');
			$entity->Update($crma2['ID'],$a);


			$arFieldsA=array('LEAD_ID'=>$crma2['ID']);
			if ($idD>0)  {
				$dealId = $deal->Update($idD,$arFieldsA);
				echo 'Обновить '.$idD.'<br>';
			}




		}

	}










	
	
}

// Найти лид для данного пользователя UF_CRM_1715771784

// Если есть, то закрыть лид. 

	
}

function Addplan($arr)
{
	
/////

$idvr=0;

if ($arr['plan_doctor']>0) {

$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['plan_doctor']),
));

if ($items146['0']['ID']>0) $idvr=$items146['0']['ID'];

}

	
$factory144 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_PLAN);
	
$items144 = $factory144->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('UF_CRM_'.TYPE_SMART_PLAN."_ID"=>$arr['plan_id']),
));

$arr['plan_date']=str_replace(' 0:00:00',' 00:00:00',$arr['plan_date']);

// найти пациента
$idp=0;

if ($arr['plan_client']>0) {
	
	
	
		$arFilterClient=array(UF_CRM_NUMBER_POLICA=>$arr['plan_client']);
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),$arFilterClient);
		if ($res->SelectedRowsCount()>0)
		{
			
		$crma=$res->fetch();
		$idp=$crma['ID'];
		}
}

// Найти услуги ID_2

 
$data = [
'TITLE' => $arr['plan_name'],
'UF_CRM_'.TYPE_SMART_PLAN.'_ID'=>$arr['plan_id'],
'UF_CRM_'.TYPE_SMART_PLAN.'_1712225493'=>$arr['plan_date'],
'CATEGORY_ID'=>49,
'ASSIGNED_BY_ID'=>1,
'MODE'=>0,
	'OPPORTUNITY'=>'30000',
	'CURRENCY_ID'=>'RUB'
	
];


	if ($arr['EXECDATE']!='')  $data['STAGE_ID']='final';

// Филиалы

$f1=0;

if ($arr['plan_filial']>0) {
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['plan_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$f1=$arFields['ID'];
}		
}




////////

if ($idp>0) $data['UF_CRM_'.TYPE_SMART_PLAN.'_CONTACT']=$idp;
if ($idvr>0) $data['UF_CRM_15_1712656347']=$idvr;

if ($f1>0) $data['UF_CRM_'.TYPE_SMART_PLAN.'_ID_FIL']=$f1;


if ($arr['plan_isclose']>0) $data['UF_CRM_'.TYPE_SMART_PLAN.'_CLOSE']=1;

if (count($items144)<=0) {
	
	// Создать данные

	$newItem = $factory144->createItem($data);
	// $newItem->save();

	$operation = $factory144->getAddOperation($newItem);
	$operation
		->disableCheckAccess()
		->enableAfterSaveActions()
		->enableBizProc()
		->enableAutomation();
	$resultOperation = $operation->launch();
	if ($resultOperation->isSuccess()) {




	}
	else
	{

	}


/*
	$operation = $factory144->getUpdateOperation($newItem);
	$operation
		->disableCheckAccess()
		->enableAfterSaveActions()
		->enableBizProc()
		->enableAutomation();
	$resultOperation = $operation->launch();
	$errorsNewLead = [];
	if ($resultOperation->isSuccess()) {
		// success
	} else {
		//fail
		$errorsTmp = $resultOperation->getErrors();
		foreach ($errorsTmp as $err) {
			$errorsNewLead [] = $err->getMessage();
		}
	}

*/




	$idW=$newItem->getData()['ID'];
	
	//  Прикрепить товары к смарту
	
	$arProToN=[];
	$sa=0;

	// CCrmProductRow::DeleteByOwner('D',$idW);

foreach ($arr['plan_service'] as $k=>$s)
{



$arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, "PROPERTY_ID"=>$s[0]);

$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$sa=$sa+1;
$arProToN=array(
'OWNER_ID'=>$idW,
'OWNER_TYPE'=>$factory144->getEntityAbbreviation(),
'PRODUCT_ID'=>$arFields['ID'],
'QUANTITY'=>$s[2],
"PRODUCT_NAME"=>''.$arFields['NAME'].' ',
'PRICE'=>$s[1],
	'PRICE_NETTO'=>$s[1],
	'PRICE_EXCLUSIVE'=> $s[1],
	'TAX_RATE'=>0,
	'PRICE_NETTO'=>$s[1],
	'PRICE_BRUTTO'=>$s[1],
	'NAME'=>''.$arFields['NAME'].' ',
	'DESCRIPTION' => $nameOffer,
	'SORT'=>10
);

print_r($arProToN);

	CCrmProductRow::Add($arProToN);


}

}




	$newItem->save();



	$newItem=$factory144->GetItem($idW);

	$OPPORTUNITY=0;

	foreach ($arr['plan_service'] as $k=>$s)
	{
		$OPPORTUNITY=$OPPORTUNITY+$s[1]*$s[2];

	}

	$newItem->SET('OPPORTUNITY',$OPPORTUNITY);
	$newItem->SET('CURRENCY_ID','RUB');

	$operation = $factory144->getUpdateOperation($newItem);
	$operation
		->disableCheckAccess()
		->enableAfterSaveActions()
		->enableBizProc()
		->enableAutomation();
	$resultOperation = $operation->launch();
	$errorsNewLead = [];
	if ($resultOperation->isSuccess()) {
		// success
	} else {
		//fail
		$errorsTmp = $resultOperation->getErrors();
		foreach ($errorsTmp as $err) {
			$errorsNewLead [] = $err->getMessage();
		}
	}





	

	
}  else {


	$OPPORTUNITY=0;

	foreach ($arr['plan_service'] as $k=>$s)
	{
		$OPPORTUNITY=$OPPORTUNITY+$s[1]*$s[2];

	}








	foreach ($items144 as $item) {
		
		
	$item144 = $factory144->getItem($item['ID']);	
	
	foreach ($data as $k=>$v) {
	if ($k!='MODE') {
    $item144->set($k,$v);
	}
	}

		$item144->SET('OPPORTUNITY',$OPPORTUNITY);
		$item144->SET('CURRENCY_ID','RUB');


		if ($arr['EXECDATE']!='')  $item144->set('STAGE_ID','final');

	$item144->save();	
		
		
		
		
		
		
		
	}
	
}
/////
	
}

function Addqueue($arr)
{


$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['queue_doctor']),
));

$idvr=0;



if ($items146['0']['ID']>0) $idvr=$items146['0']['ID'];


	
$factory144 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_QUEUE);
	
$items144 = $factory144->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('UF_CRM_'.TYPE_SMART_QUEUE."_ID"=>$arr['queue_id'],'CATEGORY_ID'=>0),
));

$arr['queue_date']=str_replace(' 0:00:00',' 00:00:00',$arr['queue_date']);

// найти пациента
$idp=0;

if ($arr['queue_client']>0) {
	
	
	
$arFilterClient=array(UF_CRM_NUMBER_POLICA=>$arr['queue_client']);
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),$arFilterClient);
		if ($res->SelectedRowsCount()>0)
		{
			
		$crma=$res->fetch();
		$idp=$crma['ID'];
		}
}


$data = [
'TITLE' => 'очередь',
'UF_CRM_'.TYPE_SMART_QUEUE.'_ID'=>$arr['queue_id'],
'UF_CRM_'.TYPE_SMART_QUEUE.'_1712226083'=>$arr['queue_date'],
'CATEGORY_ID'=>50,
'ASSIGNED_BY_ID'=>1,
'MODE'=>0,
	
];

// Филиалы

$f1=0;
$f2=0;

if ($arr['queue_filial']>0) {
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['queue_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$f1=$arFields['ID'];
}		
}


if ($arr['queue_to_filial']>0) {
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['queue_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$f2=$arFields['ID'];
}	
}

////////

if ($idp>0) $data['UF_CRM_'.TYPE_SMART_QUEUE.'_CONTACT']=$idp;
if ($idvr>0) $data['UF_CRM_16_1712656397']=$idvr;

if ($f1>0) $data['UF_CRM_'.TYPE_SMART_QUEUE.'_ID_FIL']=$f1;
if ($f2>0) $data['UF_CRM_'.TYPE_SMART_QUEUE.'_FIL']=$f2;





if (count($items144)<=0) {
	
	// Создать данные

	
	$newItem = $factory144->createItem($data);
	$newItem->save();
	


	

	
}  else {

	foreach ($items146 as $item) {

	foreach ($data as $k=>$v) {
	if ($k!='MODE') {
    $item146->set($k,$v);
	}
	}	

		
	}
	
	$item146->save();
	
}


	
	
}

///////////

function getIzm($iz)
{
	// Проверяем, есть ли такая единица измерения, если нет создать, если есть выдать ее ID
}

function AddCompany($arr)
{
	// Найти компанию по id ORIGIN_ID
	
	
	
	
	if ($arr['company_id']!='') {
		
		
		AddLog('company_id='.$arr['company_id'].'<br>','0304comp.txt');
		
		$arFilter=array('ORIGIN_ID'=>$arr['company_id']);
		$res=CCrmCompany::GetList(array('DATE_CREATE' => 'DESC'),$arFilter);
		if ($res->SelectedRowsCount()<=0)
		{
			
$arCompany=array('TITLE'=>$arr['company_name'],'ORIGIN_ID'=>$arr['company_id'],UF_CRM_1714725006=>$arr['company_acttype'],UF_CRM_1714724795=>$arr['company_buchfio'],UF_CRM_1714724762=>$arr['company_header'],UF_CRM_1714724732=>$arr['company_shortname']);
$cCompany=new CCrmCompany(false);

$idC=$cCompany->Add($arCompany);
			
			
		} else {
		
		
		$crma=$res->fetch();
		$idC=$crma['ID'];
// Создать сделку		
		
		}
		
		if ($idC>0) {
			
		
			
		
		
		// Найти реквизиты для данного I

	$arCompany=array('TITLE'=>$arr['company_name'],'ORIGIN_ID'=>$arr['company_id'],UF_CRM_1714725006=>$arr['company_acttype'],UF_CRM_1714724795=>$arr['company_buchfio'],UF_CRM_1714724762=>$arr['company_header'],UF_CRM_1714724732=>$arr['company_shortname']);

if ($arr['company_phone']!='') {
		
		$arCompany['FM']['PHONE']['n0']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['company_phone'],
  );

		}
	

	
	if ($arr['company_email']!='') {
		
$arCompany['FM']['EMAIL'] = array(
   'n0' => array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $arr['company_email'],
   )
  );
  
	}
	
	$cCompany=new CCrmCompany(false);
	
	

	$cCompany->update($idC,$arCompany);
	
	$arRQAddr=[];
	
	if ( $arr['company_requisite_addr']!='') {
	
	$arRQAddr['6'] = [ //1 - Физический адрес, 6 -Юридический адрес
        'ADDRESS_1' => $arr['company_requisite_addr'],
    ];
	
	}
	
	
	$fields =
        [
            'PRESET_ID' => 1,
            'NAME' => $arr['company_name'],
            'ACTIVE' => 'Y',
            'ENTITY_TYPE_ID' =>  \CCrmOwnerType::Company,
            'ENTITY_ID' => $idC,
			'RQ_INN' => $arr['company_requisite_inn'],
	
        ];
		
		if ($arr['company_name']!='') $fields['RQ_COMPANY_FULL_NAME']=$arr['company_name'];
		if ($arr['company_shortname']!='') $fields['RQ_COMPANY_NAME']=$arr['company_shortname'];
		if ($arr['company_buchfio']!='') $fields['RQ_ACCOUNTANT']=$arr['company_buchfio'];
		if ($arr['company_header']!='')  $fields['RQ_DIRECTOR']=$arr['company_header'];
		if (($arr['company_requisite_ogrn']!='') && (strlen($arr['company_requisite_kpp'])==13)) $fields['RQ_OGRN']=$arr['company_requisite_ogrn'];
		if ($arr['company_requisite_oktmo']!='') $fields['RQ_OKTMO']=$arr['company_requisite_oktmo'];
		if (($arr['company_requisite_kpp']!='') && (strlen($arr['company_requisite_kpp'])<10)) $fields['RQ_KPP']=$arr['company_requisite_kpp'];
		if ($arr['company_requisite_addr']!='') $fields['RQ_ADDR']=$arRQAddr;
		if ($arr['company_requisite_okpo']!='') $fields['RQ_OKPO'] =$arr['company_requisite_okpo'];

   
	$entityRequisite = new \Bitrix\Crm\EntityRequisite();
	$resentityRequisite=$entityRequisite->add($fields);
	
	
	
    $id = $resentityRequisite->getId();
	

	
	if ($id>0) {
	

	
	  $fields2 =
        [
            
            'ACTIVE' => 'Y',
            'ENTITY_ID' => $id,
			'NAME'=>'Банковские реквизиты',
			"ENTITY_TYPE_ID"=>8,
			"RQ_BANK_NAME"=>$arr['company_bank_name'],
			"RQ_BIK"=>$arr['company_bank_bic'],
			"RQ_ACC_NUM"=>$arr['company_bank_account'],
			"RQ_COR_ACC_NUM"=>$arr['company_bank_corr'],
			"RQ_CITY"=>$arr['company_bank_city']
			
			
        ];

	

	
	
	$entityRequisite2 = new \Bitrix\Crm\EntityBankDetail();
	$entityRequisite2->add($fields2);


	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		}
	

		
		
		// Найти 
		
	}
	
	
	
}


function departmentAdd($arr)
{
	//
$idd=0;




	
if ($idd<=0) {

if ($arr['dep_num']!='') {

$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_DEP,'PROPERTY_ID'=>$arr['dep_num']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	

	
	$idd=$arFields['ID'];
}	
}

}
	
	

if ($idd<=0) {
	
	if ($arr['dep_name']!='') {
	
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_DEP,'NAME'=>$arr['dep_name']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	
	$arFields = $ob->GetFields();
	$idd=$arFields['ID'];
}	

	}
	
}
	

	

$idf=0;	

if ($arr['dep_filial']>0) {
	
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['dep_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$idf=$arFields['ID'];
}		

}

if ($idd<=0) {

$el = new CIBlockElement;

$arLoadProductArray = Array(
	"IBLOCK_SECTION_ID" => false,          // элемент лежит в корне раздела
	"IBLOCK_ID"      => IBLOCK_DEP,
	"NAME"           => $arr['dep_name'],
	"ACTIVE"         => "Y",            // активен
);

$idd = $el->Add($arLoadProductArray);

	
} else {
	

	
}

if ($idd>0) {
	
// Обновим свойства элемента инфоблока	

if ($arr['dep_num']>0) CIBlockElement::SetPropertyValues($idd, IBLOCK_DEP, $arr['dep_num'],'ID'); 
if ($idf>0) CIBlockElement::SetPropertyValues($idd, IBLOCK_DEP,$idf,'FID'); 
	
}

	
	

// if ($idd<0) $bs->Add($arFieldsDep);

// if ($idd>0) $bs->Update($arFieldsDep);

	
}

function Addcabibet($arr)
{


$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CABINET,'PROPERTY_ID'=>$arr['cabinet_id']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$ide=0;
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$ide=$arFields['ID'];
}	

$el = new CIBlockElement;
$PROP=[];

if ($arr['cabinet_number']!='') $PROP['NUMBER']=$arr['cabinet_number'];
if ($arr['cabinet_disdate']!='') $PROP['DATEC']=$arr['cabinet_disdate'];
if ($arr['cabinet_id']!='') $PROP['ID']=$arr['cabinet_id'];
if ($arr['cabinet_filial']!='') {
	
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['cabinet_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$idf=0;
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$idf=$arFields['ID'];
}		

if ($idf>0) $PROP['FID']=$idf;
	
}

$arLoadProductArray = Array(
	"IBLOCK_SECTION_ID" => false,          // элемент лежит в корне раздела
	"IBLOCK_ID"      => IBLOCK_CABINET,
	"PROPERTY_VALUES"=> $PROP,
	"ACTIVE"=>"Y",
	"NAME"=>$arr['cabinet_name']
	);

if ($ide<=0) {


$el->Add($arLoadProductArray);

} else {

$el->Update($ide,$arLoadProductArray);	
	
}




	
}

function AddFilial($arr)
{
	

	
	
	if ($arr['filial']>0) {
	
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$ide=0;
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$ide=$arFields['ID'];
}	

$aFilial=[];

if ($arr['filial_fullname']!='') $aFilial['NAME']=$arr['filial_fullname'];
$aFilial['PROPERTY_ID_IZ_IK']=$arr['filial'];
	}
	
$el = new CIBlockElement;
$PROP=[];

if ($arr['filial']>0) $PROP['ID_IZ_IK']=$arr['filial'];

if ($ide<=0) {

$arLoadProductArray = Array(
	"IBLOCK_SECTION_ID" => false,          // элемент лежит в корне раздела
	"IBLOCK_ID"      => IBLOCK_FILIAL,
	"PROPERTY_VALUES"=> $PROP,
	"ACTIVE"=>"Y",
	"NAME"=>$arr['filial_fullname']
	);

$el->Add($arLoadProductArray);
	
}	

if ($ide>0) {
	
	// Изменяем свойства для филиала
	



	
	
}


	


// 
	
	
// Найти филиал 

/*

$factory171 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(171);			

$items171 = $factory171->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('UF_CRM_13_ID'=>$arr['filial'],'CATEGORY_ID'=>0),
));

if (count($items171)>0) {
	
	
	
$newLead = $factory171->getItem($items171[0]['ID']);
$newLead->set('UF_CRM_13_ID', $arr['filial']);
$newLead->set('UF_CRM_13_ADDR', $arr['filial_shortaddress']);
$newLead->set('TITLE', $arr['filial_fullname']);
if ($arr['filial_ismain']==1) $newLead->set('UF_CRM_13_BASE',1);
if ($arr['filial_ismain']==0) $newLead->set('UF_CRM_13_BASE',0);

$newLead->save();
	
	
} else {
	
	

$data=[];
$data['UF_CRM_13_ID']=$arr['filial'];
$data['UF_CRM_13_ADDR']=$arr['filial_shortaddress'];
$data['TITLE']=$arr['filial_fullname'];

if ($arr['filial_ismain']==1) $data['UF_CRM_13_BASE']=1;
if ($arr['filial_ismain']==0) $data['UF_CRM_13_BASE']=0;

$data['MODE']=1;
$data['ASSIGNED_BY_ID']=1;
$data['CREATED_BY']=1;
$data['CATEGORY_ID']=0;



$newItem = $factory171->createItem($data);
$newItem->save();

echo $factory171->LAST_ERROR;
	
//  
	
}

*/
	
}


function AddPriceService($arr)
{
	
global $DB;

// create table prices (price_schid INT, price_kateg_num INT,price_sprice INT, times INT, FID INT);

$arr['price_sprice']=str_replace(',','.',$arr['price_sprice']);

if ($arr['price_schid']>0) {
	

	
$a=$DB->Query('SELECT * FROM prices  where price_schid='.$arr['price_schid'].' and price_kateg_num='.$arr['price_kateg_num'].' and FID='.$arr['price_filial'])->Fetch();

if ($a['price_schid']<=0) $DB->Query("INSERT INTO prices (price_schid, price_kateg_num,price_sprice, times,FID) VALUES (".$arr['price_schid'].",".$arr['price_kateg_num'].",".$arr['price_sprice'].",".strtotime($arr['price_fdate']).",".$arr['price_filial'].")");
if ($a['price_schid']>0)  $DB->Query("UPDATE prices SET price_sprice=".$arr['price_sprice'].", times=".strtotime($arr['price_fdate'])."  WHERE price_schid=".$a['price_schid'].' and price_kateg_num='.$arr['price_kateg_num'].' and FID='.$arr['price_filial']);

}
$ide=0;
	

$ac='';
	
	$arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*",'ACTIVE');//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, "PROPERTY_ID"=>$arr['price_schid'],'SECTION_ID'=>SERVICE_SEC,'INCLUDE_SUBSECTIONS'=>'Y');
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$ac=$arFields['ACTIVE'];
$ide=$arFields['ID'];
}


AddError($ide.'ac='.$ac.'<br>');


if (($ide>0) && ($ac=='Y')) {
	
AddError('Активирован '.$ide.' ');
	

// Смотрим есть ли такой тип цены для этого филиала.

$idf=0;

if ($arr['price_filial']>0) {


$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['price_filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	$idf=$arFields['ID'];
	$nf=$arFields['NAME'];
}	
}



if ($idf>0)
{
	
// Найти 	$items171[0]['UF_CRM_13_ID'] такую цену базовую или закупочную



$dbPriceType = CCatalogGroup::GetList(
	array("SORT" => "ASC"),
	array("NAME" => "PRICE_".$arr['price_kateg_num'].'_'.$arr['price_filial'])
);


$IDP=0;




while ($arPriceType = $dbPriceType->Fetch())
{
	$IDP=$arPriceType['ID'];
}




$d=0;

if (time()>strtotime($arr['price_fdate'])) $d=1;

if ( ($IDP<=0) && ($d>0) ) {
	// СОздать тип цены
	
$B='N';
// if ($items171[0]['UF_CRM_13_BASE']>0) $B='Y';
// $item171=$factory171->GetItem($items171[0]['ID']);

$arFields = array(
	"NAME"=>"PRICE_".$arr['price_kateg_num'].'_'.$arr['price_filial'],
	"SORT" => 100,
	"BASE"=>$B,
	"USER_GROUP" => array(2, 3),   // видят цены члены групп 2 и 4
	"USER_GROUP_BUY" => array(3),  // покупают по этой цене
		// только члены группы 2
	"USER_LANG" => array(
		"ru" => $arr["price_kateg_text"].' в филиале '.$nf,
	)
);
$IDP= CCatalogGroup::Add($arFields);

}

if ($IDP>0) {
	
$PRODUCT_ID=$ide;
$PRICE_TYPE_ID=$IDP;



AddError('Создать цену для '.$ide.' ');

$arFields = Array(
	"PRODUCT_ID" => $PRODUCT_ID,
	"CATALOG_GROUP_ID" => $PRICE_TYPE_ID,
	"PRICE" => $arr['price_sprice'],
	"CURRENCY" => "RUB",
);

	
$res = CPrice::GetList(
	array(),
	array(
		"PRODUCT_ID" => $PRODUCT_ID,
		"CATALOG_GROUP_ID" => $PRICE_TYPE_ID
	)
);
if ($arr = $res->Fetch())
{
	CPrice::Update($arr["ID"], $arFields);
}
else
{
	CPrice::Add($arFields);
}	
	
	
	
	
}


////// 


	
}  // Конец 




	
}
	
	
} 



function AddCatalog($arr)
	{
	
	
	// Есть ли такой элемент
	
	

$ide=0;

if ($arr['mat_code']!='') {
	
	
	
	
	// Создаем раздел или определяем его
	
	$sId=TOVAR_SEC;
		
		
		if ($arr['mat_grpcod']!='') {
		
	$db_list = CIBlockSection::GetList(Array($by=>$order), ['IBLOCK_ID'=>IBLOCK_CATALOG,'UF_ID'=>$arr['mat_grpcod']], true);	while($ar_result = $db_list->GetNext())
	{
	
		$sId = $ar_result['ID'];
	}
	
	$bs = new CIBlockSection;
	
	$arParams = array("replace_space"=>"-","replace_other"=>"-");



$arFields = Array(
	"IBLOCK_SECTION_ID" => TOVAR_SEC,
	"IBLOCK_ID" => IBLOCK_CATALOG,
	"NAME" => $arr['mat_grpname'],
	'UF_ID'=> $arr['mat_grpcod'],
	'ACTIVE'=>'Y',
	"CODE" => Cutil::translit($arr['mat_grpname'],"ru",$arParams)
	);

	
	if ($sId==TOVAR_SEC) {
	

	
	$sId = $bs->Add($arFields);
		
	} else {
		

		
	$bs->Update($sId,$arFields);
		
	}
	
	
		}
	
	// 
	
	
	

	$arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, "PROPERTY_ID2"=>$arr['mat_code'],'SECTION_ID'=>TOVAR_SEC,'INCLUDE_SUBSECTIONS'=>'Y');
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$ide=$arFields['ID'];
}

if ($ide<=0) {
	
	
	
	$el = new CIBlockElement;
	
	$arLoadProductArray=array('NAME'=>$arr['mat_name'],"IBLOCK_SECTION_ID"=>$sId,'PROPERTY_VALUES'=>array("ID2"=>$arr['mat_code'],'FIIAL'=>$arr['mat_filial']),'IBLOCK_ID'=>IBLOCK_CATALOG,'ACTIVE'=>'Y');
	
	$ide = $el->Add($arLoadProductArray);
	
	$e=CCatalogProduct::add(array('ID' => $ide, 'TYPE'=>'1'));

	
	AddError($el->LAST_ERROR);
	
} else {
	
	
	
$el = new CIBlockElement;	



$arLoadProductArray=array('NAME'=>$arr['mat_name'],"IBLOCK_SECTION_ID"=>$sId,'PROPERTY_VALUES'=>array("ID2"=>$arr['mat_code'],'FIIAL'=>$arr['mat_filial']),'IBLOCK_ID'=>IBLOCK_CATALOG,'ACTIVE'=>'Y');

$el->Update($ide,$arLoadProductArray);
$dd=CCatalogProduct::add(array('ID' => $ide, 'TYPE'=>'1'));

	AddError($el->LAST_ERROR);
}

} else {
	
	AddError('Без ID не может добавить товар');
}

if ($ide>0) {
	// Торговое предложение создать
	$unit=0;
	// $arF=array("MEASURE_TITLE"=>$arr['units']);

	$res_measure = CCatalogMeasure::getList(array(),$arF);
        while($measure = $res_measure->Fetch()) {
		
		if ($measure['MEASURE_TITLE']==$arr['mat_edizm']) $unit=$measure['ID'];
        }    
		
		if ($unit<=0)
		{
	// Создаем свой юнит
	// Найти последее ID в таблице mysql
	
	global $DB;
	
	$a=$DB->query("select ID FROM b_catalog_measure ORDER by ID ASC")->Fetch();

	
	$arParams = array("replace_space"=>"-","replace_other"=>"-");
	$unit=CCatalogMeasure::Add(array("CODE"=>$a['ID']+1,"MEASURE_TITLE"=>$arr['mat_edizm']));
	
		}
	
	$adp=array('ID' => $ide,"MEASURE"=>$unit);
	$idp=CCatalogProduct::add($adp);
	
	// Ставим цену для товара
	
	CPrice::SetBasePrice($ide,$arr['mat_price'][0]['mat_price'],"RUB");
	
	

	
}

	
	
	}


////// создание раздел каталоге

function AddSectionService($arr)
{
	
	$code='';
	$nm='';
	$active='Y';
	
	$sec=SERVICE_SEC;
	
 
	
	if ($arr['main_folder_code']!='') $code=$arr['main_folder_code'];
	if ($arr['main_folder_name']!='') $nm=$arr['main_folder_name'];
	if ($arr['main_folder_disabled']=='1') $active='N';
	
	if ($arr['folder_schid']!='') {
	
	if ($arr['folder_schid']!='') $code=$arr['folder_schid'];
	if ($arr['folder_name']!='') $nm=$arr['folder_name'];
	if ($arr['main_folder_disabled']=='1') $active='N';
	
	
	
	$sec=SERVICE_SEC;
	
	
		if ($arr['folder_parentschid']<=0) {
			$arr['folder_parentschid']=$arr['main_folder_code'];
		}
	
	

	

if ($arr['folder_parentschid']!='') {
	
	
	
	$db_list = CIBlockSection::GetList(Array($by=>$order), ['IBLOCK_ID'=>IBLOCK_CATALOG,'UF_ID2'=>$arr['folder_parentschid']], true);	while($ar_result = $db_list->GetNext())
	{
		$sec = $ar_result['ID'];
	}
	 
	
}
	
	
	
	}
	
	
	
			if ($code!='') {
				
				
		
	$db_list = CIBlockSection::GetList(Array($by=>$order), ['IBLOCK_ID'=>IBLOCK_CATALOG,'UF_ID2'=>$code], true);	while($ar_result = $db_list->GetNext())
	{
		$sId = $ar_result['ID'];
	}
	
	$bs = new CIBlockSection;
	
	$arParams = array("replace_space"=>"-","replace_other"=>"-");

$da=$arr['folder_disdate'];

$arFields = Array(
	"ACTIVE" => $active,
	"DATE_ACTIVE_TO"=>$da,
	"IBLOCK_SECTION_ID" => $sec,
	"IBLOCK_ID" => IBLOCK_CATALOG,
	"NAME" => $nm,
	'UF_ID2'=> $code,
	"CODE" => Cutil::translit($nm,"ru",$arParams)
	);
	
	

	
	if ($sId<=0) {
	

	
	$sId = $bs->Add($arFields);
		
	} else {
		


		
	$bs->Update($sId,$arFields);
		
	}
	
	
		}
	
	
	
	
	
	
	
	
}

///////////


	function AddService($arr)
	{
		
		
	
	
	// Есть ли такой элемент

$ide=0;

if ($arr['service_id']!='') {

	$arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, "PROPERTY_ID"=>$arr['service_id'],'SECTION_ID'=>SERVICE_SEC,'INCLUDE_SUBSECTIONS'=>'Y');
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$ide=$arFields['ID'];
}


	$SECTION_SERVICE=SERVICE_SEC;
if ($arr['main_folder']<0) $SECTION_SERVICE=SERVICE_SEC_NO;
if ($arr['folder_schid']==0)  $arr['folder_schid']=$arr['main_folder'];
if ($arr['folder_schid']=='')  $arr['folder_schid']=$arr['main_folder'];




	
	if ($arr['folder_schid']>0) {
	
	$db_list = CIBlockSection::GetList(Array($by=>$order), ['IBLOCK_ID'=>IBLOCK_CATALOG,'UF_ID2'=>$arr['folder_schid']], true);	while($ar_result = $db_list->GetNext())
	{
		$SECTION_SERVICE = $ar_result['ID'];
	}
	
	}

if ($ide<=0) {
	
	// $arr['folder_schid']
	

	$el = new CIBlockElement;
	
	
	
	$da=$arr['service_disdate'];
	
	$arLoadProductArray=array('NAME'=>trim($arr['service_kodoper']).' '.trim($arr['service_name']),"DATE_ACTIVE_TO"=>$da,'PROPERTY_VALUES'=>array("ID"=>$arr['service_id'],'CODE'=>trim($arr['service_kodoper']),'NAME'=>$arr['service_name']),'IBLOCK_SECTION_ID'=>$SECTION_SERVICE,'IBLOCK_ID'=>IBLOCK_CATALOG,'ACTIVE'=>'Y');
	
	
	
	$ide = $el->Add($arLoadProductArray);
	
	AddError('создать #'.$ide);
	
	$e=CCatalogProduct::add(array('ID' => $ide, 'TYPE'=>'7'));

	
	if ($el->LAST_ERROR!='') AddError('ошибка: '.$el->LAST_ERROR);
	
} else {
	
		AddError('обновить #'.$ide);
	
	
$el = new CIBlockElement;	

$da=$arr['service_disdate'];

$arLoadProductArray=array('NAME'=>trim($arr['service_kodoper']).' '.trim($arr['service_name']),"DATE_ACTIVE_TO"=>$da,'PROPERTY_VALUES'=>array("ID"=>$arr['service_id'],'CODE'=>trim($arr['service_kodoper']),'NAME'=>$arr['service_name']),'IBLOCK_SECTION_ID'=>$SECTION_SERVICE,'IBLOCK_ID'=>IBLOCK_CATALOG);

$el->Update($ide,$arLoadProductArray);
$dd=CCatalogProduct::add(array('ID' => $ide, 'TYPE'=>'7'));

if ($el->LAST_ERROR!='') AddError('ошибка: '.$el->LAST_ERROR);
}

} else {
	
	AddError('Без ID не может добавить товар');
}


	
	
	}
	
	
	
function AddVrachi($arr)
{

	if ($arr['id']>0) {
			
			

$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['id']),
));

 

// Параметры
$nm=explode(' ',$arr['name']);

$data = [
    'TITLE' => $arr['name'],
'UF_CRM_'.ID_TYPE_VRACH.'_DEPARTMENT'=>$arr['department'],
'UF_CRM_'.ID_TYPE_VRACH.'_1708942581339'=>$arr['id'],
'UF_CRM_'.ID_TYPE_VRACH.'_EMAIL'=>$arr['email'],
'UF_CRM_'.ID_TYPE_VRACH.'_1705316993'=>$arr['specialization'],
'CATEGORY_ID'=>4,
'ASSIGNED_BY_ID'=>1,
'STAGE_ID'=>'DT156_4:PREPARATION',
	'UF_CRM_'.ID_TYPE_VRACH.'_1702406170'=>$nm[0],
	'UF_CRM_'.ID_TYPE_VRACH.'_1702406180'=>$nm[1],
	'UF_CRM_'.ID_TYPE_VRACH.'_1702406188'=>$nm[2],
];

if (count($items146)<=0) {
	
	// Создать данные
	

	$newItem = $factory146->createItem($data);
	$newItem->save();

}  else {
	


	
	foreach ($items146 as $item) {
		

	
$nm=explode(' ',$arr['name']);
	
 
	
	$item146 = $factory146->getItem($item['ID']);	
	
	if ($nm[0]!='') $item146->set("UF_CRM_2_1702406170",$nm[0]);
	if ($nm[1]!='') $item146->set("UF_CRM_2_1702406180",$nm[1]);
	if ($nm[2]!='') $item146->set("UF_CRM_2_1702406188",$nm[2]);
	
	$item146->set('CATEGORY_ID',4);
	$item146->set('STAGE_ID','DT156_4:PREPARATION');
	
	if ($arr['name']!='') $item146->set('TITLE', $arr['name']);	
	if ($arr['department']!='') $item146->set('UF_CRM_'.ID_TYPE_VRACH.'_DEPARTMENT', $arr['department']);
	if ($arr['id']!='') $item146->set(UF_CRM_2_1708942581339, $arr['id']);
	if ($arr['email']!='') $item146->set('UF_CRM_'.ID_TYPE_VRACH.'_EMAIL', $arr['email']);
	if ($arr['specialization']!='') $item146->set('UF_CRM_'.ID_TYPE_VRACH.'_SPEC', $arr['specialization']);
	$item146->save();
	

	
	}
	
	// Обновить 
	
}



	




		}

		
	

}





		

	
	
	function CancelDeal($arr)
	{
	
	$deal = new CCrmDeal(false);	
	

if ($arr['sched_id']>0) 
	$deals=$deal->GetList([],["ORIGIN_ID"=>$arr['sched_id']])->fetch();
	
	$arFields = array(
        "STAGE_ID" => status_lose,   
		"UF_CRM_1700572904"=>51
		);



if ($deals['ID']>0) {
	
	AddError('Отменяем #'.$deals['ID'].' '.print_r($arFields,true));
	
$dealId = $deal->Update($deals['ID'],$arFields);
	
	
	
	}
	
	
	}
	
	function AddDeal($arr)
	{
	
// Выгружаем визит	

if (($arr['id']=='') || ($arr['id_visit']!='')) {
	
	// Проверить есть ли сделка с таким визитом
	
	$deal = new CCrmDeal(false);
	
	$deals2=$deal->GetList([],[UF_CRM_1672233998=>$arr['id_visit']])->fetch();
	
	$crma=[];
	
	if ($deals2['ID']<=0) {
		
		
		$arr['id']='NOT_ZAPISI_'.$arr['id_visit']; 
		
if ($arr['clientID']>0) {
	
	
	


		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),array(UF_CRM_NUMBER_POLICA=>$arr['clientID']));		
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}
		
}


$arFD=array('TITLE'=>$crma['LAST_NAME'].' '.$arr['date_visit'],UF_CRM_1672233998=>$arr['id_visit'],'ORIGIN_ID'=>$arr['id'],'STAGE_ID'=>status_won,'CATEGORY_ID'=>0,"TYPE_ID" => "SALE");

$dealId = $deal->Add($arFD);

	} else {
		
		
		
		
	}


}

		$idplan=0;

		if ($arr['plan_id']>0) $arr['visit_plan_id']=$arr['plan_id'];

		if ($arr['visit_plan_id']>0) {
			// Найти план



$factory144 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_PLAN);

$items144 = $factory144->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('UF_CRM_'.TYPE_SMART_PLAN."_ID"=>$arr['visit_plan_id']),
));

if ($items144['0']['ID']>0) $idplan=$items144['0']['ID'];



		}


if (($arr['id']!='') || ($arr['id_visit']!='')) {
	
	if ($arr['doctor_scheduled_visit']>0) {


$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['doctor_scheduled_visit']),
));




$arVrachScheduled=$items146[0];

	
	}
	
	if ($arr['doctor_id']>0) {
	
	
	
$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['doctor_id']),
));

$arVrachScheduled=$items146[0];






	
	}
	
	if ($arr['doctor_visit']>0) {
		


$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array(UF_CRM_2_1708942581339=>$arr['doctor_visit']),
));




$arVrach=$items146[0];
	
	
	
	}
	
	// Услуги 

$ids=array();
$ids2=array();
	
	
	$ss=array();
	
	$su=0;
	$sk=0;
	
	$pr=1;
	
	foreach ($arr['services'] as $services) {

		if ($services[0]>0) {

			$ss[] = trim($services[0]);
			$su = $su + $services[1] * $services[2];
			$sk = $sk + $services[4];
		}
	}
	
	if ($su>0) $pr=1-$sk/$su;
	
	
	if ($ss[0]>0) {
		
		
		
		
		
		
		
	
$arSelect=array('ID','PROPERTY_ID');
	
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, "PROPERTY_ID"=>$ss);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$ids[]=$arFields['ID'];

}



	}




// Услуги направления


$ss2=array();
	foreach ($arr['directions'] as $services)
	$ss2[]=$services[0];
	
	if ($ss2[0]>0) {
	

	
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CATALOG, 'IBLOCK_SECTION_ID'=>SECTION_SERVICE,"ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y","PROPERTY_ID"=>$ss2);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement()){ 
$arFields = $ob->GetFields();  
$ids2[]=$arFields['ID'];
}



	}








// ищем слиента по CLIENT_ID 
$crma=array();
if ($arr['clientID']>0) {
$arFilterClient=array(UF_CRM_NUMBER_POLICA=>$arr['clientID']);
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),$arFilterClient);
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}
		
} 


if ($arr['client_id']>0) {
$arFilterClient=array(UF_CRM_NUMBER_POLICA=>$arr['client_id']);

		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),$arFilterClient);
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}
		
} 



// Создаем сделку по ранее указанным данным 

if ($arr['id']>0) {
$deal = new CCrmDeal(false);
$deals=$deal->GetList([],["ORIGIN_ID"=>$arr['id']])->fetch();
}
 
if ($arr['id']<=0) {
$deal = new CCrmDeal(false);
$deals2=$deal->GetList([],[UF_CRM_1672233998=>$arr['id_visit']])->fetch();

// print_r($deals2);
}




if ($arVrachScheduled['ID']>0) $ASSIGNED_BY_ID=$arVrachScheduled['ID'];
if ($arVrach['ID']>0) $ASSIGNED_BY_ID=$arVrach['ID'];


	

// if ($arVrach['ID']>0) $ASSIGNED_BY_ID=$arVrach['ID'];






	if ($ASSIGNED_BY_ID>0) $arFields = array(
        "TYPE_ID" => "SALE", 
		"CATEGORY_ID"=>0,
		UF_CRM_1672234220=>$ids2,
        "OPENED" => "Y", 
		);

if ($idplan>0) $arFields["PARENT_ID_".ID_SMART_PLAN]=$idplan;

if ($ASSIGNED_BY_ID>0) $arFields["PARENT_ID_".ID_SMART_VRACH]=$ASSIGNED_BY_ID;
if ($ASSIGNED_BY_ID>0) $arFields["UF_CRM_1712750625"]=$ASSIGNED_BY_ID;



	  $arr['date2']=str_replace(' 0:00:00','',$arr['date']);
		
		if ($arr['date']!='') {
			$arr['date']=str_replace('0:00:00',str_pad($arr['hour'], 2, '0', STR_PAD_LEFT).':'.str_pad($arr['min'], 2, '0', STR_PAD_LEFT).':'.':00',$arr['date']);
		}
		
		if ($arr['date']!='') {
			$arr['date']=str_replace('0:00:00',str_pad($arr['hour'], 2, '0', STR_PAD_LEFT).':'.str_pad($arr['min'], 2, '0', STR_PAD_LEFT).':'.':00',$arr['date']);
		}
		
		
		if ($arr['createdate']!='') {
			$arFields[UF_CRM_1712751011]=$arr['createdate'];
		}
		

if ($arr['date']!='')  $arr['date_scheduled_visit']=$arr['date'];
		
	if ($arVrach['ID']>0) $arFields['UF_CRM_1665671453']=$arVrach['ID'];	
	if ($arVrachScheduled['ID']>0) $arFields[UF_CRM_1672234490]=$arVrachScheduled['ID'];
	if ($arr['date_scheduled_visit']!='')	$arFields[UF_CRM_1674746402]=$arr['date_scheduled_visit'];
	if ($arr['recommendations']!='')	$arFields[UF_CRM_1665671917386]=$arr['recommendations'];
	if ($arr['directions']!='')	$arFields['UF_CRM_1669816649']=$arr['directions'];
	if ($arr['diagnosis_visit']!='')	$arFields[UF_CRM_1672234696]=$arr['diagnosis_visit'];
	
	
		if ($arr['filial']>0) {
	
$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_FILIAL,'PROPERTY_ID_IZ_IK'=>$arr['filial']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$ide=0;
while($ob = $res->GetNextElement())
{
	$arFields22 = $ob->GetFields();
	$arFields[UF_CRM_1712750486]=$arFields22['ID'];
}
	
	
		}
		
		if ($arr['department']>0) {
			
			
			
	$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_DEP,'PROPERTY_ID'=>$arr['department']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$ide=0;
while($ob = $res->GetNextElement())
{
	$arFields22 = $ob->GetFields();
	$arFields[UF_CRM_1714218742]=$arFields22['ID'];
}		
			
		
			
		}
		
		
		
			if ($arr['cabinet']>0) {
			
			
			
	$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_ID_IZ_IK');
$arFilter = Array("IBLOCK_ID"=>IBLOCK_CABINET,'PROPERTY_ID'=>$arr['cabinet']);
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>1), $arSelect);
$ide=0;
while($ob = $res->GetNextElement())
{
	$arFields22 = $ob->GetFields();
	$arFields[UF_CRM_1714223722]=$arFields22['ID'];
}		
			
		
			
		}
		
		
		
	

	
	if ($arr['type_visit']!='') {
	
	$arSelect = Array("ID", "NAME");
$arFilter = Array("IBLOCK_ID"=>IBLOCK_TYPE, "NAME"=>$arr['type_visit']);
$res22 = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
while($ob22 = $res22->GetNextElement())
{
	$arFields22 = $ob22->GetFields();
	
	

	
	$arFields[UF_CRM_1674745471]=$arFields22['ID'];
}
	






	}
	
	if ($arr['finish_hour']>0)
	{
		
		
		if ($arr['finish_hour']<10) $pr3='0';
		if ($arr['finish_min']<10) $pr4='0';
		$arr['date2']=$arr['date2'].' '.$pr3.$arr['finish_hour'].':'.$pr4.$arr['finish_min'].':00';

		$d1='2024-03-04 '.$pr1.$arr['hour'].':'.$pr2.$arr['min'].':00';
		$d2='2024-03-04 '.$pr3.$arr['finish_hour'].':'.$pr4.$arr['finish_min'].':00';

		$t1=strtotime($d1);
		$t2=strtotime($d2);
		$t=round(($t2-$t1)/60);

		if ($t<=5) $arFields['STAGE_ID']=status_lose;



	}
	
	

	if ($arr['date_visit']!='') $arFields[UF_CRM_1665671704049]=$arr['date_visit'];
	if ($arr['date']!='') $arFields[UF_CRM_1665671704049]=$arr['date'];
	
	if ($arr['date2']!='') $arFields[UF_CRM_1712751207]=$arr['date2'];
	

		if ($arr['id']>0) {
			$arFields["ORIGIN_ID"]=$arr['id'];
			$arFields[UF_CRM_1715677082]=$arr['id'];
		}
		
		if ($crma['ID']>0) $arFields["CONTACT_ID"] = $crma['ID'];
		
		if ($arr['date']!='') $arFields[UF_CRM_1700650365]=$arr['date'];
		
		
		if ($arr['visit_id']>0) $arFields[UF_CRM_1672233998]=$arr['visit_id'];
		
		// Найти контакт 
		
	if ($arr['date']!='') $arFields["TITLE"]=$crma['LAST_NAME'].' '.$arr['date'];

	$vch='';
	if ($arr['doctor_id']>0) $vch=$arr['doctor_id'];
	if ($arr['doctor_visit']>0) $vch=$arr['doctor_visit'];

	global $vrachs;



	if (!in_array($vch,$vrachs)) {

		$arFields["STAGE_ID"] = status_new;

	} else {
		$arFields["STAGE_ID"] = status_lose;
	}


	

	
	
	if ($arr['id']<=0) {
		$arFields["STAGE_ID" ]=status_won; // Сменить статус на удачно завершено
	
	
	
	}


	
	

	if (($deals['ID']>0) || ($deals2['ID']>0) || ($dealId>0)) {
	
	
	unset($arFields['CATEGORY_ID']);
	unset($arFields['ID']);
	unset($arFields["~ID"]);

	if ($arFields['STAGE_ID']== status_new) {
		unset($arFields['STAGE_ID']);
	}
	
	if ($arr['clvisit']==1) $arFields['STAGE_ID']=status_in;
	if ($arr['onlinetype']==1) $arFields['STAGE_ID']=status_online;
	
$deal = new CCrmDeal(false);

if ($deals['ID']>0)  $dealId = $deal->Update($deals['ID'],$arFields);
if ($deals2['ID']>0)  $dealId = $deal->Update($deals2['ID'],$arFields);
if ($deals['ID']>0) AddError('обновить Cделку #'.$deals['ID']);
if ($deals2['ID']>0) AddError('обновить Cделку ##'.$deals2['ID']);




$su=0;
$sk=0;
	$pr=1;
	
	foreach ($arr['services'] as $services) {
		if ($services[0]>0) {
			$ss[] = trim($services[0]);
			$su = $su + $services[1] * $services[2];
			$sk = $services[4];
		}
	}


	
	if ($su>0) $pr=1-$sk/$su;


$su2=$su-$sk;

$cc=count($ids)-1;

foreach ($ids as $k=>$id)
{
	
	$su2=$su2-round($arr['services'][$k][1]*$arr['services'][$k][2]*$pr,2);
	$kop=0;
	$kop=0;
	if ($k==$cc) $kop=$su2;
	if ($kop>0) $kop=ceil($kop/0.01)*0.01;
	
	
	
	$rows[] = [
                'PRODUCT_ID' => $id, //id товара
                'QUANTITY' => $arr['services'][$k][2], //количество
				'PRICE'=>$arr['services'][$k][1]*$pr+$kop
            ];
		
		
if ($deals2['ID']>0) $res = CCrmProductRow::SaveRows('D', $deals2['ID'], $rows); 
if ($deals['ID']>0) $res = CCrmProductRow::SaveRows('D',$deals['ID'], $rows); 

}





AddError($deal->LAST_ERROR);

CCrmBizProcHelper::AutoStartWorkflows(CCrmOwnerType::Deal, $dealId, CCrmBizProcEventType::Edit, $arErrors, null );  

AddError($arErros);

$starter = new \Bitrix\Crm\Automation\Starter(\CCrmOwnerType::Deal, $dealId);
if ($deals['ID']>0) $starter->runOnUpdate($arFields, $deals);
if ($deals2['ID']>0)  $starter->runOnUpdate($arFields, $deals2);
	
} else {
	
	

		
//UF_CRM_CONF_NAME1 - пользовательское свойство сделки, без кавычек, потому что это константа, в которой хранится системное название поля

$options = array('CURRENT_USER'=>1); //из под админа
$deal = new CCrmDeal(false);

if ($arr['id']>0) {
$arFields["STAGE_ID" ]=status_new; // Для новой сделки задать статус новая сделка



///

$dealId = $deal->Add($arFields,true,$options);

}

if ($dealId<=0) {
	AddError('ошибка: '.$deal->LAST_ERROR);
}

AddError('Добавлена сделка #'.$dealId);

if($dealId > 0){         

  
 
CCrmBizProcHelper::AutoStartWorkflows(CCrmOwnerType::Deal, $dealId, CCrmBizProcEventType::Create, $arErrors, null );  

$starter = new \Bitrix\Crm\Automation\Starter(\CCrmOwnerType::Deal, $dealId);
$starter->runOnAdd();
  

}
   
   
   $su2=$su-$sk;
   $cc=count($ids);
   
foreach ($ids as $k=>$id)
{
	
	
	$su2=$su2-round($arr['services'][$k][1]*$arr['services'][$k][2]*$pr,2);
	$kop=0;
	if ($k==$cc) $kop=$su2;
	if ($kop>0) $kop=ceil($kop/0.01)*0.01;
	
	$rows[] = [
                'PRODUCT_ID' => $id, //id товара
                'QUANTITY' => $arr['services'][$k][2], //количество
				'PRICE'=>$arr['services'][$k][1]*$pr
            ];
		
$res = CCrmProductRow::SaveRows('D', $dealId, $rows); 
}


	
	
	
}  // Создание сделки
	
	
	
	
	} else {
		AddError('Без id не может добавить сделку');
	}
	
	function4026($arr);
	function4034($arr);
	
	}
	
	
	
	function AddUser($arr)
	{
		// Смотрим есть ли такой контакт, если нет,то создаем
		// UF_CRM_1665672449531
		
		if ($arr['id']!='') {
		
		$arFilter=array('ORIGIN_ID'=>$arr['id']);
		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),$arFilter);
		if ($res->SelectedRowsCount()<=0)
		{
	// Создаем
	
	$arParams=array();
	
	
		$sex=array('М'=>81,"Ж"=>82);
		$arParams[UF_CRM_1665672224147]=$sex[$arr['sex']];
		
		$arParams['NAME']=$arr['name'];
		$arParams['LAST_NAME']=$arr['surname'];
		$arParams['SECOND_NAME']=$arr['middle_name'];
		$arParams[UF_CRM_1665672449531]=$arr['number_policy'];
		$arParams[UF_CRM_1665672430009]=$arr['insurance_company'];
		$arParams[UF_CRM_1665672515999]=$arr['date_creation'];
		
		// responsible_id 

/*
		
		if ($arr['responsible_id']>0) {
			
		// 
		
		$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('UF_CRM_'.ID_TYPE_VRACH.'_ID'=>$arr['responsible_id'],'CATEGORY_ID'=>0),
))[0];


if ($items146['ID']>0) $arParams['UF_CRM_1709301600']=$items146['ID'];

	
			
		}
		
		*/
		
		
		/* Новые поля от 27.04 */
		
	if ($arr['comment']!='') $arParams['COMMENTS']=$arr['comment'];
	if ($arr['hidecomment']!='') $arParams[UF_CRM_1714205621]=$arr['hidecomment'];
	if ($arr['specserv']!='') $arParams[UF_CRM_1714205773]=$arr['specserv'];
	if ($arr['progserv']!='') $arParams[UF_CRM_1714206433]=$arr['progserv'];
	if ($arr['pcode']!='') $arParams[UF_CRM_1714206904]=$arr['pcode'];

// Даты	
	if ($arr['sdateserv']!='') $arParams[UF_CRM_1714206777]=$arr['sdateserv'];
	if ($arr['fdateserv']!='') $arParams[UF_CRM_1714206839]=$arr['fdateserv'];
	
// Пациент совершеннолетний

if ($arr['parentsfio']!='') $arParams[UF_CRM_1714207605]=$arr['parentsfio'];
if ($arr['company']!='') $arParams[UF_CRM_1714207780]=$arr['company'];

/////////////
	
	
		
		
	if (($arr['date_client_last']!='') && (substr_count($arr['date_client_last'],'00:00:00')<=0))	$arParams[UF_CRM_1665672361821]=$arr['date_client_last'];
	if (($arr['date_client_nxt']!='') &&  (substr_count($arr['date_client_nxt'],'00:00:00')<=0))	$arParams[UF_CRM_1665672289879]=$arr['date_client_nxt'];
		
		if ($arr['card']!='') $arParams[UF_CRM_1676469377058]=$arr['card'];
		
		if ($arr['date_exit']!='') $arParams['UF_CRM_1686143426']=$arr['date_exit'];
		
		$arParams['BIRTHDATE']=$arr['date_birth'];
		$arParams['TYPE_ID'] ='CLIENT';
		$arParams['SOURCE_ID']= 'WEB';
		$arParams['OPENED'] = 'Y';
		$arParams["EXPORT"] = "Y";
		$arParams['ORIGIN_ID']=$arr['id'];
		
		// Отказ от рассылок
		if ($arr['refuseclmail']==1)  $arParams[UF_CRM_1676900488]='1';
		
		if ($arr['refusecall']==1)  $arParams[UF_CRM_1676890703402]='1';
		
		if ($arr['refusesms']==0)  $arParams[UF_CRM_1676900702]='87';
		if ($arr['refusesms']==1)  $arParams[UF_CRM_1676900702]='88';
		if ($arr['refusesms']==2)  $arParams[UF_CRM_1676900702]='89';
		if ($arr['refusesms']==3)  $arParams[UF_CRM_1676900702]='90';
		
		
	
		
		
		if ($arr['phone1']!='') {
		
		$arParams['FM']['PHONE']['n0']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone1'],
  );

		}
		
		
				if ($arr['phone2']!='') {
		
		$arParams['FM']['PHONE']['n1']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone2'],
  );

		}
		
		
	
					if ($arr['phone3']!='') {
		
		$arParams['FM']['PHONE']['n2']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone3'],
  );

		}
		
	

	
		
		

		
	
	if ($arr['email']!='') {
		
$arParams['FM']['EMAIL'] = array(
   'n0' => array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $arr['email'],
   )
  );
  
	}
	
	
	
	
	
	
		// Обновляем
		$ct=new CCrmContact(false);
		$new_contact_id=$ct->Add($arParams, true, array('DISABLE_USER_FIELD_CHECK' => true));
		
		
		
		
		
	$crma['ID']=$new_contact_id;
		
		if ($crma['ID']>0) {

$entityRequisite = new \Bitrix\Crm\EntityRequisite();

/// Найти реквизит по паспорту, и если есть такой то обновить его

	$dbRes = $entityRequisite->getList([
    "filter" => [
        "ENTITY_ID" => $crma['ID'],
        "ENTITY_TYPE_ID" => \CCrmOwnerType::Contact,
    ],
    "select" => ["ID", "ENTITY_ID", "RQ_INN"]
]);

$idR=0;

while ($arRes = $dbRes->fetch()) {
	$idR=$arRes['ID'];
}








////////////


  $fields =
        [
            'PRESET_ID' => 3,
			'NAME'=>$arr['name'],
            'ACTIVE' => 'Y',
            'ENTITY_TYPE_ID' =>  \CCrmOwnerType::Contact,
            'ENTITY_ID' => $crma['ID'],
    
            
        ];
		
		
		if ($arr['paspser']!='') $fields['RQ_IDENT_DOC_SER'] = $arr['paspser'];
		if ($arr['paspnum']!='') $fields['RQ_IDENT_DOC_NUM'] = $arr['paspnum'];
		if ($arr['paspdate']!='') $fields['RQ_IDENT_DOC_DATE'] = $arr['paspdate'];
		if ($arr['paspplace']!='') $fields['RQ_IDENT_DOC_ISSUED_BY'] = $arr['paspplace'];

    
    
    $entityRequisite = new \Bitrix\Crm\EntityRequisite();
    
    if ($idR<=0) {
	
		$resRec=$entityRequisite->add($fields);
	}
	
	if ($idR>0) {

		$resRec=$entityRequisite->update($idR,$fields);
	}
		
		
		}	
		
		
		
		
		
		
		
		
		
		
		 AddError('Создаем контакт #'.$new_contact_id);
		
		if ($new_contact_id>0)	{
		
		
$factory = Service\Container::getInstance()->getFactory(CCrmOwnerType::Contact);
$item = $factory->getItem($new_contact_id);

// Step 1: get opetation
$operation = $factory->getUpdateOperation($item);
$operationResult = $operation->launch();

if ( $operationResult->isSuccess() )
{

   
}
else
{
	
}


		
 
}
else{
 AddError($ct->LAST_ERROR);
}


} else {
	
	
	

$crma=$res->fetch();



$arParams=array();





		
		if ($arr['responsible_id']>0) {
			
		// 
		
		$factory146 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
	
$items146 = $factory146->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('UF_CRM_2_1708942581339'=>$arr['responsible_id']),
))[0];




if ($items146['ID']>0) $arParams['UF_CRM_1709301600']=$items146['ID'];




		
			
		}

		
			$sex=array('М'=>81,"Ж"=>82);
		$arParams[UF_CRM_1665672224147]=$sex[$arr['sex']];
		
		$arParams['NAME']=$arr['name'];
		$arParams['LAST_NAME']=$arr['surname'];
		$arParams['SECOND_NAME']=$arr['middle_name'];
		$arParams[UF_CRM_1665672449531]=$arr['number_policy'];
		$arParams[UF_CRM_1665672430009]=$arr['insurance_company'];
		$arParams[UF_CRM_1665672515999]=$arr['date_creation'];
		$arParams['BIRTHDATE']=$arr['date_birth'];
		$arParams['TYPE_ID'] ='CLIENT';
		$arParams['SOURCE_ID']= 'WEB';
		$arParams['OPENED'] = 'Y';
		$arParams["EXPORT"] = "Y";
		$arParams[UF_CRM_NUMBER_POLICA]=$arr['id'];
		
		if ($arr['date_exit']!='') $arParams['UF_CRM_1686143426']=$arr['date_exit'];
		
		if ($arr['refuseclmail']==1)  $arParams[UF_CRM_1676900488]='1';
		if ($arr['refusecall']==1)  $arParams[UF_CRM_1676890703402]='1';
		if ($arr['refusesms']==0)  $arParams[UF_CRM_1676900702]='87';
		if ($arr['refusesms']==1)  $arParams[UF_CRM_1676900702]='88';
		if ($arr['refusesms']==2)  $arParams[UF_CRM_1676900702]='89';
		if ($arr['refusesms']==3)  $arParams[UF_CRM_1676900702]='90';
		
		
		
		
		/* Новые поля от 27.04 */
		
	if ($arr['comment']!='') $arParams['COMMENTS']=$arr['comment'];
	if ($arr['hidecomment']!='') $arParams[UF_CRM_1714205621]=$arr['hidecomment'];
	if ($arr['specserv']!='') $arParams[UF_CRM_1714205773]=$arr['specserv'];
	if ($arr['progserv']!='') $arParams[UF_CRM_1714206433]=$arr['progserv'];
	if ($arr['pcode']!='') $arParams[UF_CRM_1714206904]=$arr['pcode'];

// Даты	
	if ($arr['sdateserv']!='') $arParams[UF_CRM_1714206777]=$arr['sdateserv'];
	if ($arr['fdateserv']!='') $arParams[UF_CRM_1714206839]=$arr['fdateserv'];
	
// Пациент совершеннолетний

if ($arr['parentsfio']!='') $arParams[UF_CRM_1714207605]=$arr['parentsfio'];
if ($arr['company']!='') $arParams[UF_CRM_1714207780]=$arr['company'];

/////////////
		
		
		
	
	if (($arr['date_client_last']!='') && (substr_count($arr['date_client_last'],'00:00:00')<=0))	$arParams[UF_CRM_1665672361821]=$arr['date_client_last'];
	if (($arr['date_client_nxt']!='') &&  (substr_count($arr['date_client_nxt'],'00:00:00')<=0))	$arParams[UF_CRM_1665672289879]=$arr['date_client_nxt'];
	
			if ($arr['card']!='') $arParams[UF_CRM_1676469377058]=$arr['card'];




 $arFilterEmail = [
        'ENTITY_ID'  => 'CONTACT',
        'ELEMENT_ID' => $crma['ID'],
        'TYPE_ID'    => 'EMAIL',
        'VALUE_TYPE' => 'WORK',
    ];
	
 $arFilterPhone = [
        'ENTITY_ID'  => 'CONTACT',
        'ELEMENT_ID' => $crma['ID'],
        'TYPE_ID'    => 'PHONE',
        'VALUE_TYPE' => 'WORK',
    ];
	
    $arEmail = \CCrmFieldMulti::GetListEx([],$arFilterEmail,false,['nTopCount'=>1],['VALUE'])->fetch();
	
	$arPhone = \CCrmFieldMulti::GetListEx([],$arFilterPhone,false,['nTopCount'=>1],['VALUE'])->fetch();



if ($arr['phone1']!='') {
		
		$arParams['FM']['PHONE']['n0']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone1'],
  );

		}
		
		
				if ($arr['phone2']!='') {
		
		$arParams['FM']['PHONE']['n1']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone2'],
  );

		}
		
		
	
					if ($arr['phone3']!='') {
		
		$arParams['FM']['PHONE']['n2']= array(
    'VALUE_TYPE' => 'MOBILE',
    'VALUE' => $arr['phone3'],
  );

		}


		
		
	
	if ($arr['email']!='') {
	if ($arEmail['ID']<=0) $arEmail['ID']='n0';
$arParams['FM']['EMAIL'][$arEmail['ID']] = array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $arr['email'],
  );
  
	}
	
if ($crma['ID']>0)
{

$entityRequisite = new \Bitrix\Crm\EntityRequisite();

/// Найти реквизит по паспорту, и если есть такой то обновить его

	$dbRes = $entityRequisite->getList([
    "filter" => [
        "ENTITY_ID" => $crma['ID'],
        "ENTITY_TYPE_ID" => \CCrmOwnerType::Contact,
    ],
    "select" => ["ID", "ENTITY_ID", "RQ_INN"]
]);

$idR=0;

while ($arRes = $dbRes->fetch()) {
	$idR=$arRes['ID'];
}








////////////


  $fields =
        [
            'PRESET_ID' => 3,
			'NAME'=>$arr['name'],
            'ACTIVE' => 'Y',
            'ENTITY_TYPE_ID' =>  \CCrmOwnerType::Contact,
            'ENTITY_ID' => $crma['ID'],
    
            
        ];
		
		
		if ($arr['paspser']!='') $fields['RQ_IDENT_DOC_SER'] = $arr['paspser'];
		if ($arr['paspnum']!='') $fields['RQ_IDENT_DOC_NUM'] = $arr['paspnum'];
		if ($arr['paspdate']!='') $fields['RQ_IDENT_DOC_DATE'] = $arr['paspdate'];
		if ($arr['paspplace']!='') $fields['RQ_IDENT_DOC_ISSUED_BY'] = $arr['paspplace'];

    
    
    $entityRequisite = new \Bitrix\Crm\EntityRequisite();
    
    if ($idR<=0) {
	
		$resRec=$entityRequisite->add($fields);
	}
	
	if ($idR>0) {

		$resRec=$entityRequisite->update($idR,$fields);
	}



}	
	
	
	
	
	
	
	
	
	
	
	

$ct=new CCrmContact(false);
$ct->Update($crma['ID'],$arParams);

AddError($ct->LAST_ERROR);
AddError('обновление '.$crma['ID'].' контакт');

		}
		
	} else {
	
	AddError('Без id не может добавить контакт');
	}
		
	}
	
	
	$inputJSON = file_get_contents('php://input');
	
	
	
	$arr=json_decode($inputJSON,true);
	
	if ((TEST=='Y') && ($_REQUEST['get']!='')) $arr=json_decode($_REQUEST['get'],true);
	
	
	include('config.php');
	
	$sh2=md5($inputJSON.$COMPANY.$CODE);
	
	$path=explode('/',explode('?',$_SERVER['REQUEST_URI'])[0]);
	
	
	$ld=date('dmY',time());
	
	$f=fopen($_SERVER["DOCUMENT_ROOT"].'/api/logs/'.$ld.$path[2].'.txt','a');
	fwrite($f,date('H:i:s').''.$inputJSON."\r\n\r\n");
	fclose($f);
	
	
	if (($_REQUEST['hash']==$sh2) || (TEST=='Y'))
	{

if ($path[2]=='contact') {

	foreach ($arr as $ar)	AddUser($ar);

	}
	
	
	if ($path[2]=='catalog') {

	foreach ($arr as $ar)	AddCatalog($ar);

	}
	
	if ($path[2]=='services') {

	foreach ($arr as $ar)	AddService($ar);

	}
	
		if ($path[2]=='cancel') {

	foreach ($arr as $ar)	CancelDeal($ar);

	}
	
	
		if ($path[2]=='department') {
			
			

	foreach ($arr as $ar)	departmentAdd($ar);

	}
	
	
	
		if ($path[2]=='cabinet') {

	foreach ($arr as $ar)	Addcabibet($ar);

	}
	
		if ($path[2]=='section_service') {
			
			

	foreach ($arr as $ar)	AddSectionService($ar);

	}
	
	if ($path[2]=='user') {
		foreach ($arr as $ar)	AddVrachi($ar);
	}
	
		if ($path[2]=='price') {
		foreach ($arr as $ar)	AddPriceService($ar);
	}

if ($path[2]=='filial') {
	foreach ($arr as $ar) AddFilial($ar);
}

if ($path[2]=='company') {
	foreach ($arr as $ar) AddCompany($ar);
}
	
if ($path[2]=='deal') {
foreach ($arr as $ar) AddDeal($ar);
}

if ($path[2]=='queue') {
foreach ($arr as $ar) Addqueue($ar);
}

if ($path[2]=='plan') {
foreach ($arr as $ar) Addplan($ar);
}



	}  else {
	$OK='ERROR';
	AddError('Ошибка безопасности, неверный контрольная сумма');
	}
	
// $USER->Logout();
	
?><?

/*
Добавить поле для пользователь UF_ORIGIN_ID	
	
*/

$arResult=array();

if (!empty($MESSAGES)) 
{
	$arResult['message']=$MESSAGES;
	$arResult['status']=$OK;
} else $arResult['status']=$OK;

echo json_encode($arResult,JSON_UNESCAPED_UNICODE);

AddLog(print_r($uuu,true),'update_user');


AddLog(json_encode($arResult,JSON_UNESCAPED_UNICODE),'allService');








?>
