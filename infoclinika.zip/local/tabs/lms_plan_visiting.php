<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
{
    die();
}

use Bitrix\Main\Localization\Loc;

return [
    'id' => 'lms_plan_visiting',  // ID вкладки
    'name' => 'Услуги', // Наименование вкладки
    'html' =>PRELOADER,
    'loader' => ['serviceUrl' => '/local/pages/lms_plan_visiting_page.php?&site'.SITE_ID.'&'.bitrix_sessid_get(),
        'componentData' => [
            'entityID' => $entityID,
            'entityTypeID' => $entityTypeID,
            'signedParameters' => \CCrmInstantEditorHelper::signComponentParams([
                'entityID' => $entityID,
                'entityTypeID' => 3, 
                'INTERNAL_FILTER' => ['ENTITY_ID' => $entityID],
            ], 'crm.lms.deal.isiting')
        ],
    ],
];