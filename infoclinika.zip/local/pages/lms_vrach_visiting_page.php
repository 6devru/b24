<?php

use Bitrix\Main\Loader;
use Bitrix\Crm\Service;

use Bitrix\Crm\Relation;
use Bitrix\Crm\ItemIdentifier;
use Bitrix\Crm\Service\Container;

define('NO_KEEP_STATISTIC', 'Y');
define('NO_AGENT_STATISTIC', 'Y');
define('NO_AGENT_CHECK', true);
define('PUBLIC_AJAX_MODE', true);
define('DisableEventsCheck', true);

 
// 

$siteID = isset($_REQUEST['site']) ? mb_substr(preg_replace('/[^a-z0-9_]/i', '', $_REQUEST['site']), 0, 2) : '';
if ($siteID !== '') {
    define('SITE_ID', $siteID);
}

$componentData = isset($_REQUEST['PARAMS']) && is_array($_REQUEST['PARAMS']) ? $_REQUEST['PARAMS'] : [];

require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php');
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}


if (!CModule::IncludeModule('crm') || !CCrmSecurityHelper::IsAuthorized() || !check_bitrix_sessid()) {
    die();
}

$arDeal=CCrmDeal::GetByID($componentData['entityID']);


CUtil::JSPostUnescape();

global $APPLICATION;
Header('Content-Type: text/html; charset=' . LANG_CHARSET);
$APPLICATION->ShowAjaxHead();

CJSCore::Init(array("jquery"));
\Bitrix\Main\UI\Extension::load('ui.entity-selector');
\Bitrix\Main\Loader::includeModule('ui');


?>

    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type="text/css" href="<?= PATH_TO_DEFAULT_TEMPLATE ?>/css/tui-style.css"/>
        <link rel="stylesheet" type="text/css" href="<?= PATH_TO_DEFAULT_TEMPLATE ?>/css/tui-style-custom.css"/>
        <link rel="stylesheet" type="text/css" href="<?= PATH_TO_DEFAULT_TEMPLATE ?>/css/tui-grid.css"/>

        <link rel="stylesheet" type="text/css" href="<?= PATH_TO_DEFAULT_TEMPLATE ?>/css/tui-date-picker.css"/>
    </head>

    <body>
    <div id="preloader" class="fixed-overlay fixed-overlay__modal hide">
        <div id="preloader_modal" class="modal">
            <div id="preloader_content" class="modal_container">

            </div>
        </div>
    </div>
    <div id="msgDiv" class="ui-alert hide">
        <span id="msg" class="ui-alert-message"></span>
    </div>
    <div id="errorsDiv" class="ui-alert ui-alert-danger hideError">
        <span id="errors" class="ui-alert-message"></span>
    </div>
    <div class="main-content">
        <div class="content">
            <div id="gridLms"></div>
        </div>
    </div>
	
	 <div id="ui-button-panel" class="ui-button-panel-wrapper">
        <div class="ui-button-panel">
            <button id="updateData" name="updateData" value="Y" class="ui-btn ui-btn-success" onclick="updateData();">Обновить</button>

		<? /*

			<button id="updateSave" name="createDeal" value="Y" class="ui-btn ui-btn-primary" onclick="createDeal();">Создать сделку</button>
			
			<button id="updateSave" name="createDeals" value="Y" class="ui-btn  ui-btn-primary-dark" onclick="createDeals();">Создать сделки</button>
			
			
			<button id="updateSave" name="removeDeal" value="Y" class="ui-btn ui-btn-active" onclick="dialog.show();">Перенести в сделку</button>


 */ ?>
			
			

<script>			

const  dialog = new BX.UI.EntitySelector.Dialog({
    items: [
	
	<?
	$dbRes = CCrmDeal::GetList(array('TITLE' => 'ASC'), array('CONTACT_ID'=>$arDeal['CONTACT_ID'],"!ID"=>$componentData['entityID']));

        while ($arRes = $dbRes->Fetch()) { 
		 ?>
	
        { id: <?=$arRes['ID'];?>, entityId: 'my-entity', title: '<?=$arRes['TITLE'];?>', tabs: 'my-tab' },

		<? } ?>

    ],
	
	
    tabs: [
        { id: 'my-tab', title: 'Сделки' }
    ],
    showAvatars: false,
    dropdownMode: true,
});


dialog.subscribe('Item:onSelect', (event) => {
	// some code here
		  ID=event.getData().item.id;
		  
		  console.log('test'+ID);
	      
		  $('#dealadd').val(ID);
		 
setTimeout(function(){
  $('.ui-selector-item-box-selected').find('.ui-selector-item-indicator').trigger('click');
}, 1000);
		 
		
		 
		 
		 dialog.hide();
		  
	
 removeDeal();
	
	
	
	
});




</script>


			
			
			<input type="hidden" name='dealadd' id='dealadd' value="">
		
	

        </div>
    </div>
	
	
    <div style="height: 0px;"></div>


    </body>
    <script src="<?= PATH_TO_DEFAULT_TEMPLATE ?>/js/babel.min.js"></script>
    <script type="text/javascript" src="<?= PATH_TO_DEFAULT_TEMPLATE ?>/js/tui-date-picker.js"></script>
    <script type="text/javascript" src="<?= PATH_TO_DEFAULT_TEMPLATE ?>/js/tui-grid.js"></script>
    <script type="text/babel" class="code-js">


  // <a '.$onclick.' href="#'.$url.'">'.$title.'</a>
     
	 function GetDeal(idD,val) {
		 
		 
$.get('/local/api/lms_vrach_visiting.php?addPos=Y&idD='+idD+'&idModule='+val, function(data) {


  updateData();





});

return false;
		 
		 
	 }
	 
	 
   class CustomSliderRenderer {
      constructor(props) {
        const el = document.createElement('span');
        
		
		
		    const { min, max } = props.columnInfo.renderer.options;
	
	
	
	if (props.value!='') {
		
		console.log('B'+props.value.split('|')[0]);
	
var typeD=props.value.split('|')[0];
var valueD=props.value.split('|')[1];
var valueText=props.value.split('|')[2];
	
	}
	
	if (typeD=='create') {
		el.innerHTML='<a OnClick="GetDeal('+<?=$componentData['entityID'];?>+','+valueD+'); return false;" href="#">Создать2</a>';	
	}
	
	if (typeD=='yes') {
		
		el.innerHTML='<a href="'+valueD+'">'+valueText+'</a>';
	}
	
	if (typeD=='no') {
		
		el.innerHTML='<a style="color:#ff0000;" href="'+valueD+'">'+valueText+'</a>';
		el.style.color='red';
	}
	
	
		
		
        el.type = 'range';
        
        this.el = el;
        this.render(props);
      }

      getElement() {
        return this.el;
      }

      render(props) {
        this.el.value = '123';
      }
    }
	
	
	

        const gridLms = new tui.Grid({
            el: document.getElementById('gridLms'),
            data: {
                api: {
                    readData: {url: '/local/api/lms_vrach_visiting.php?entityID=<?=$componentData['entityID']?>', method: 'GET'},
					updateData: {url: '/local/api/lms_vrach_visiting.php?entityID=<?=$componentData['entityID']?>', method: 'GET'}
                }
            },
            rowHeaders: ['checkbox'],
            bodyHeight: 500,
            treeColumnOptions: {
                name: 'name',
                useCascadingCheckbox: true
            },
            columns: [
			
			{
                    header: 'ID',
                    name: 'id',
                    whiteSpace: 'normal'
                },
				
                {
                    header: 'Наименование',
                    name: 'name',
                    whiteSpace: 'normal'
                },
                {
                    header: 'Рекомендации/направления к другим специалистам',
                    name: 'services',
                    whiteSpace: 'normal'
                },
				 {
                    header: 'Пациент',
                    name: 'contacts',
                    whiteSpace: 'normal'
                },
				
				 {
                    header: 'Врач',
                    name: 'vrach',
                    whiteSpace: 'normal'
                },
				
				{
                    header: 'Дата',
                    name: 'date',
                    whiteSpace: 'normal'
                },
				
             
            ]
        });

        
		
		







   





  
  

		

        gridLms.on('collapse', ev => {
            const {rowKey} = ev;
            const descendantRows = gridLms.getDescendantRows(rowKey);

            console.log('2rowKey: ' + rowKey);
            console.log('descendantRows: ' + descendantRows);
        });


   function updateData()
        {
			       
				   
	gridLms.reloadData();
			

	$('.ui-button-panel').show();
			
        }
		


function createDeal() {
	
	
		$('.ui-button-panel').hide();
		
		BX.showWait();
		
		ss='';
		
d=0;

	$('#gridLms').each(function(i){

$(this).find('[type=checkbox]').each(function(iii){

if ($(this).prop('checked')) {
	
	ddd=$('[data-column-name=name]').eq((iii)).find('.checkdeal').attr('class');

	
	if ('_'+ddd!='_undefined') {
	ddd=ddd.replace('checkdeal ddd_','');
	ss=ss+'check[]='+ddd+'&';
	}
	
}


		
});


});



				
		$.ajax({
  url: '/local/api/lms_vrach_visiting.php?entityID='+<?=$componentData['entityID']?>+'&create=1&'+ss,
  context: document.body
}).done(function() {
  


  updateData();


	$('.ui-button-panel').show();
	BX.closeWait();

  
});		


 

			

}		



function createDeals() {
	
		
		$('.ui-button-panel').hide();
		BX.showWait();
		
		ss='';
		
		$('#gridLms').each(function(i){

$(this).find('[type=checkbox]').each(function(iii){

if ($(this).prop('checked')) {
	
	ddd=$('[data-column-name=name]').eq((iii)).find('.checkdeal').attr('class');

	
	if ('_'+ddd!='_undefined') {
	ddd=ddd.replace('checkdeal ddd_','');
	ss=ss+'check[]='+ddd+'&';
	}
	
}


		
});


});
				
		$.ajax({
  url: '/local/api/lms_vrach_visiting.php?entityID='+<?=$componentData['entityID']?>+'&create=2&'+ss,
  context: document.body
}).done(function() {
  

  updateData();
  BX.closeWait();



$('.ui-button-panel').show();
  
});		


	
		
				
			

}	



function removeDeal() {
	
	
		$('.ui-button-panel').hide();
		BX.showWait();
		
		ss='';
		
		$('#gridLms').each(function(i){

$(this).find('[type=checkbox]').each(function(iii){

if ($(this).prop('checked')) {
	
	ddd=$('[data-column-name=name]').eq((iii)).find('.checkdeal').attr('class');

	
	if ('_'+ddd!='_undefined') {
	ddd=ddd.replace('checkdeal ddd_','');
	ss=ss+'check[]='+ddd+'&';
	}
	
}


		
});


});
				

				
	
				
			//	alert(ss);
				
		$.ajax({
  url: '/local/api/lms_vrach_visiting.php?entityID='+<?=$componentData['entityID']?>+'&create=3&'+ss+'&adddeal='+$('#dealadd').val(),
  context: document.body
}).done(function() {
  
   

  updateData();
  BX.closeWait();
  
  

  
});		


 
		
				
			

}	
		
		


    </script>
    </html>

<?php

require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/epilog_after.php');
die();