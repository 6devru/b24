<?php
define('NO_KEEP_STATISTIC',true);
define('NO_CHECK_PERMISSIONS',true);
define('NEED_AUTH',true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Loader;
use Bitrix\Crm\Service;

use Bitrix\Crm\Relation;
use Bitrix\Crm\ItemIdentifier;
use Bitrix\Crm\Service\Container;

Loader::includeModule('crm');
if ($USER->IsAuthorized())
{
	
	
	
	

	
 

///


	$result['result'] = true;
	

$factory151 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(OCH_ID);

// Запросить 

global $deal;


$filter=[
"UF_CRM_16_1712656397"=>$_REQUEST['entityID']];



$items151 = $factory151->getItems(array(
    'order'=>array('ID'=>'ASC'),
	'select' => ['PRODUCT_ROWS'],
	'filter' => $filter,
));

foreach ($items151 as $item151) {
	
	$item151=$factory151->GetItem($item151['ID']);
	
	
// $item['UF_CRM_15_1712656347'] - vrach
// UF_CRM_15_CONTACT - contact

$items156=[];

if ($item151['UF_CRM_16_1712656397']>0) {
	
$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
$items156 = $factory156->getItems(array(
'order'=>array('BEGINDATE'=>'ASC'),
	'select' => ['ID'],
	'filter' => array('ID'=>$item151['UF_CRM_16_1712656397']),
));

if ($items156[0]['TITLE']!='') $items156[0]=$factory156->GetItem($items156[0]['ID']);

}

$crma=[];

		$res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),array('ID'=>$item151['UF_CRM_16_CONTACT']),array("*", "UF_*", "PHONE", "IM","TITLE",'LAST_NAME','NAME'));		
		if ($res->SelectedRowsCount()>0)
		{
		$crma=$res->fetch();
		}

	
	$result['data']['contents'][]=[
							'id'=> $item151['ID'],
							'name'=> '<a class="checkdeal ddd_1" href="/crm/type/'.OCH_ID.'/details/'.$item151['ID'].'/">'.$item151['TITLE'].'</a>',
							'contacts'=> $crma['LAST_NAME'].' '.$crma['NAME'],
							'vrach'=>$items156[0]['TITLE'],
							'services'=>$item151['UF_CRM_16_1712226049'],
							'date'=>' '.$item151['UF_CRM_16_1712226083'].' ',
							'visiting'=> '444',
							
						];
						
						

}



				
					




		




 
	
    $result['data']['pagination'] = [
        'page' => 1,
        'totalCount' => 100,
    ];


   if (is_array($result['data']['contents'])<=0) $result['data']['contents']=[];
	
	// if ($result['result']==true) unset($result);
	
	echo json_encode($result);
	//echo '<pre>'.json_encode($result).'</pre>';
}