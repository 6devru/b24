<?php
define('NO_KEEP_STATISTIC',true);
define('NO_CHECK_PERMISSIONS',true);
define('NEED_AUTH',true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Loader;
use Bitrix\Crm\Service;

use Bitrix\Crm\Relation;
use Bitrix\Crm\ItemIdentifier;
use Bitrix\Crm\Service\Container;

Loader::includeModule('crm');
if ($USER->IsAuthorized())
{
	
	
$aP=[];
$aD=[];
$aCh=[];
$aCj=[];

	$result['result'] = true;

    // Найти все сделки (и услуги в них) в которых есть это план

    $factory2 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(2);
    $factory2->getEntityAbbreviation();

    $factory151 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(PLAN_ID);
    $factory151->getEntityAbbreviation();

    $items2 = $factory2->getItems(array(
        'order'=>array('ID'=>'ASC'),
        'select' => ['CONTACT_ID','TITLE','CLOSEDATE','STAGE_ID'],
        'filter' => array('PARENT_ID_'.PLAN_ID=>$_REQUEST['entityID']),
    ));



    foreach($items2 as $kk=>$item2) {


        $arProducts = CCrmDeal::LoadProductRows($item2['ID']);

        foreach ($arProducts as $arPro)
        {

            $aP[$arPro['PRODUCT_ID']][]=$item2['ID'];

            $aCj[$arPro['PRODUCT_ID']]=$aCj[$arPro['PRODUCT_ID']]+1;

            $aD[$item2['ID']]=$item2;

        }


    }
        //


    $factory151 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(PLAN_ID);
    $factory151->getEntityAbbreviation();

    $products = \Bitrix\Crm\ProductRowTable::getList([
        'select' => ['*'],
        'filter' => [

            // 'PRODUCT_NAME' =>  $arP['PRODUCT_NAME'], // ID Товара
            "OWNER_ID"=>$_REQUEST['entityID'],
            'OWNER_TYPE' => $factory151->getEntityAbbreviation()
            // 'OWNER_TYPE'=>$factory->getEntityAbbreviation()
        ]
    ])->fetchAll();


    // print_r($aP);


    foreach ($products as $idP) {

        $res = CIBlockElement::GetByID($idP['PRODUCT_ID']);
        $ar_res = $res->GetNext();

        $title='123'; // Заголовок для сделки

if ($aCh[$idP['PRODUCT_ID']]<=0) $aCh[$idP['PRODUCT_ID']]=0;

$color='';

        if ($aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]>0) {
            if ($aD[$aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]]['STAGE_ID']=='WON') $color='color:green;';
            if ($aD[$aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]]['STAGE_ID']!='WON') $color='color:yellow;';
            $title='<a href="/crm/deal/details/'.$aD[$aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]]['ID'].'/">'.$aD[$aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]]['TITLE'].'</a>';
        } else {

            $title = '';

        }


        $result['data']['contents'][] = [
            'id' => $idP['PRODUCT_ID'],
            'name' => '<a style="'.$color.'" href="#">'.$ar_res['NAME'].'</a>',
            'deal' => $title,
            'date' =>' '.$aD[$aP[$idP['PRODUCT_ID']][$aCh[$idP['PRODUCT_ID']]]]['CLOSEDATE'].' '
        ];


        $aCh[$idP['PRODUCT_ID']]=$aCh[$idP['PRODUCT_ID']]+1;


    }




				
					




		




 
	
    $result['data']['pagination'] = [
        'page' => 1,
        'totalCount' => 100,
    ];


   if (is_array($result['data']['contents'])<=0) $result['data']['contents']=[];
	
	// if ($result['result']==true) unset($result);
	
	echo json_encode($result);
	//echo '<pre>'.json_encode($result).'</pre>';
}