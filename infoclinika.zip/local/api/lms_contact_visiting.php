<?php
define('NO_KEEP_STATISTIC',true);
define('NO_CHECK_PERMISSIONS',true);
define('NEED_AUTH',true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Main\Loader;
use Bitrix\Crm\Service;

use Bitrix\Crm\Relation;
use Bitrix\Crm\ItemIdentifier;
use Bitrix\Crm\Service\Container;

Loader::includeModule('crm');
if ($USER->IsAuthorized())
{


///


    $result['result'] = true;


    $factory151 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(PLAN_ID);

// Запросить

    global $deal;

    $filter=["UF_CRM_15_CONTACT"=>$_REQUEST['entityID']];



    $items151 = $factory151->getItems(array(
        'order'=>array('ID'=>'ASC'),
        'select' => ['*','UF_*'],
        'filter' => $filter,
    ));

    foreach ($items151 as $item151) {



// $item['UF_CRM_15_1712656347'] - vrach
// UF_CRM_15_CONTACT - contact

        $items156=[];

        if ($item151['UF_CRM_15_1712656347']>0) {

            $factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(ID_SMART_VRACH);
            $items156 = $factory156->getItems(array(
                'order'=>array('BEGINDATE'=>'ASC'),
                'select' => ['ID'],
                'filter' => array('ID'=>$item151['UF_CRM_15_1712656347']),
            ));

        }

        $crma=[];

        $res=CCrmContact::GetList(array('DATE_CREATE' => 'DESC'),array('ID'=>$item151['UF_CRM_15_CONTACT']),array("*", "UF_*", "PHONE", "IM","TITLE",'LAST_NAME','NAME'));
        if ($res->SelectedRowsCount()>0)
        {
            $crma=$res->fetch();
        }


        $result['data']['contents'][]=[
            'id'=> $item151['ID'],
            'name'=> '<a class="checkdeal ddd_1" href="/crm/type/'.PLAN_ID.'/details/'.$item151['ID'].'/">'.$item151['TITLE'].'</a>',
            'contacts'=> $crma['LAST_NAME'].' '.$crma['NAME'],
            'vrach'=>$items156[0]['TITLE'],
            'services'=>'Услуга',
            'date'=>' '.$item151['UF_CRM_15_1712225493'].' ',
            'visiting'=> '444',

        ];



    }
















    $result['data']['pagination'] = [
        'page' => 1,
        'totalCount' => 100,
    ];


    if (is_array($result['data']['contents'])<=0) $result['data']['contents']=[];

    // if ($result['result']==true) unset($result);

    echo json_encode($result);
    //echo '<pre>'.json_encode($result).'</pre>';
}