<?

define('CRM_DEAL',2); // Сделки
define('CRM_CONT',3); // Контакты
define('PLAN_ID',151); // Смарт процесс План лечения
define('OCH_ID',144); // Смарт процесс Очередь
define('ID_SMART_VRACH',156); // Врачи
define('ID_SMART_PLAN',151); // Врачи

define('UF_CRM_VRACH','UF_CRM_2');

define('test','N');

define('UF_CRM_2_1708942581339','UF_CRM_2_1708942581339');   // - ID Врача в смарт процессе
define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24

define("UF_CRM_UYP",'UF_CRM_1714206904');

define('UF_DATE_ZAP','UF_CRM_1712750980');

define('UF_FILIAL','UF_CRM_1712750486');

?>