<?php

use Bitrix\Main\Context,
    Bitrix\Currency\CurrencyManager,
    Bitrix\Sale\Order,
    Bitrix\Sale\Basket,
	Bitrix\Sale\Delivery,
    Bitrix\Sale\PaySystem,
	Bitrix\Crm\Service,
	Bitrix\Crm\Service\Container;

require __DIR__.'/../vendor/autoload.php';

const PATH_TAB_PAGES = __DIR__ . '/../tabs/';
const DEFAULT_TEMPLATE_PATH = '/local/templates/.default/';
const PAGES_PATH = '/local/pages/';
const PRELOADER_IMG_PATH = '/local/templates/.default/preloader/preloader.gif';
const PRELOADER = '<div style="display: table-cell; text-align: center; vertical-align: middle;width: 100vw; height: 50vh;"><img src="'.PRELOADER_IMG_PATH.'" alt="" width="160" height="122" class="alignnone"></div>';

define('PATH_TO_DEFAULT_TEMPLATE',  '/local/templates/.default'); //использовать замену сервиса и контейнера

include('define.php');
include('functions.php');


global $types;
global $bk;
$types=[12=>'alfabank',13=>'tinkoff',8=>'bank'];
$bk=[12=>'bk',13=>'bk',8=>'r_s'];	

/*

Bitrix\Main\EventManager::getInstance()->addEventHandler(
    'crm',
    'onEntityDetailsTabsInitialized',
    static function(\Bitrix\Main\Event $event) {
        $tabs = $event->getParameter('tabs');
        $parameters = $event->getParameters();
        $entityID = $event->getParameter('entityID');
        $entityTypeID = $event->getParameter('entityTypeID');


        if(PURCHASE_FACT==$entityTypeID)
        {
            //array_unshift($tabs,require_once PATH_TAB_PAGES . 'budget_fact_tab.php');
            array_unshift($tabs,require_once PATH_TAB_PAGES . 'budget_koz_fact_tab.php');
        }

        if(PURCHASE==$entityTypeID)
        {
            array_unshift($tabs,require_once PATH_TAB_PAGES . 'purchase_goods_edit_tab.php');
        }

        return new \Bitrix\Main\EventResult(\Bitrix\Main\EventResult::SUCCESS, [
            'tabs' => $tabs,
        ]);
    }
);
*/



Bitrix\Main\EventManager::getInstance()->addEventHandler(
    'crm',
    'onEntityDetailsTabsInitialized',
    static function(\Bitrix\Main\Event $event) {
        $tabs = $event->getParameter('tabs');
        $parameters = $event->getParameters();
        $entityID = $event->getParameter('entityID');
        $entityTypeID = $event->getParameter('entityTypeID');

        /*if(PURCHASE_PLAN==$entityTypeID)
        {
            array_unshift($tabs,require_once PATH_TAB_PAGES . 'budget_plan_tab.php');
        }*/


   if(CRM_CONT==$entityTypeID)
        {
          array_unshift($tabs,require_once PATH_TAB_PAGES . 'lms_contact_visiting.php');
          //  array_unshift($tabs,require_once PATH_TAB_PAGES . 'cashflow_deals.php');
        }


        if(ID_SMART_PLAN==$entityTypeID)
        {
            array_unshift($tabs,require_once PATH_TAB_PAGES . 'lms_plan_visiting.php');
            //  array_unshift($tabs,require_once PATH_TAB_PAGES . 'cashflow_deals.php');
        }



	
	
	
	   if(ID_SMART_VRACH==$entityTypeID)
        {
          array_unshift($tabs,require_once PATH_TAB_PAGES . 'lms_vrach_visiting.php');
          //  array_unshift($tabs,require_once PATH_TAB_PAGES . 'cashflow_deals.php');
        }


        if(CRM_DEAL==$entityTypeID)
        {
            		
 		array_unshift($tabs,require_once PATH_TAB_PAGES . 'lms_deal_visiting.php');
          //  array_unshift($tabs,require_once PATH_TAB_PAGES . 'cashflow_deals.php');
        }
        if(123==$entityTypeID)
        {
            // array_unshift($tabs,require_once PATH_TAB_PAGES . 'discrepancy_report.php');
            //array_unshift($tabs,require_once PATH_TAB_PAGES . 'contract_agreement.php');
        }

        return new \Bitrix\Main\EventResult(\Bitrix\Main\EventResult::SUCCESS, [
            'tabs' => $tabs,
        ]);
    }
);



if (!defined('STATUS_ACTIVE')) {

AddEventHandler('crm', 'OnBeforeCrmDealUpdate', 'OnAfterCrmControlPanelBuildHandler1');
AddEventHandler('crm', 'OnBeforeCrmDealDelete1', 'OnAfterCrmControlPanelBuildHandler1');
// AddEventHandler("main", "OnEndBufferContent", "deletePIC");

}

function OnAfterCrmControlPanelBuildHandler($arMenu) {
   /**Обработка события**/
   
  $f=fopen($_SERVER["DOCUMENT_ROOT"].'','a');
fwrite($f,print_r($arMenu,true));
fclose($f); 
   
$factory25 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_POS_ID);
	 
	 
$items25 = $factory25->getItems(array(
	'select' => ['PRODUCT_ROWS'],
	'filter' => array('PARENT_ID_2'=>$arMenu),
));
$item2=[];

$title='';
$url='';


//echo 'фильтр: ';
//print_r(array('PARENT_ID_130'=>$gro[$i],'CONTACT_ID'=>$arDeal['CONTACT_ID']));
//echo 'конец фильтра';

foreach($items25 as $kk=>$item2)
{
   
// $item2->delete();

}

   
}

define('PROGRAMMS',156); // Группы
define('PROGRAMMS_STATUS_NUM',20); // Номер поля в статусе сущности
define('PROGRAMMS_UF','UF_CRM_'.'16'.'_'); // Префикс для пользовательских полей

define('GROUPS',158); // Группы
define('GROUPS_STATUS_NUM',21); // Номер поля в статусе сущности
define('GROUPS_UF','UF_CRM_'.'17'.'_'); // Префикс для пользовательских полей

define('MODULES',180); // Модули
define('MODULES_STATUS_NUM',22); // Номер поля в статусе сущности
define('MODULES_UF','UF_CRM_'.'18'.'_'); // Префикс для пользовательских полей

CModule::IncludeModule('crm');

if (!defined('CALLBACK_FORM_IBLOCK_ID')) {
    define('CALLBACK_FORM_IBLOCK_ID', 110);//миграция инфоблока  // Письма с главной
}











 ?>