<?

use Bitrix\Main\Context,
    Bitrix\Currency\CurrencyManager,
    Bitrix\Sale\Order,
    Bitrix\Sale\Basket,
    Bitrix\Sale\Delivery,
    Bitrix\Sale\PaySystem,
	Bitrix\Crm\Service,
	Bitrix\Crm\Service\Container;
	use Bitrix\Sale;

global $types;
global $bk;
$types=[12=>'alfabank',13=>'tinkoff',8=>'bank'];	
$bk=[12=>'bk',13=>'bk',8=>'r_s'];	
	
function LogAdd2($s)
{
	
	
	
// $f=fopen($_SERVER["DOCUMENT_ROOT"].'/logs/logEventAddTest.txt','a');
// fwrite($f,print_r($s,true)."\r\n");
// fclose($f);

if (test=='Y') echo $s;
	
}

function PayInTable($i)
{
	
	
global $DB;

if ($i>0) {
	$a=$DB->Query('select * FROM pays WHERE ID='.$i)->fetch();
	if ($a['ID']!=$i) {
		$DB->Query('INSERT INTO pays (ID) VALUES ('.$i.')');
		return true;
	}
	
	if ($a['ID']==$i) {
		return false;
	}
	
}

return true;
	
}

function getImageResizeAndWebp($idFile, $width, $height, $proportional){
    $orig = [];
    $isProptional = false;
    if($proportional){
        $isProportional = true;
        $type = BX_RESIZE_IMAGE_PROPORTIONAL;
    }else{
        $isProportional = false;
        $type = BX_RESIZE_IMAGE_EXACT;
    }
    $orig = \CFile::GetFileArray($idFile);
    if ($orig['CONTENT_TYPE'] != 'image/webp') {
      $result['WEBP'] = MG\HP\Pict::getResizeWebpSrc($orig, $width, $height, $isProportional, 100);
    }else{
     $result['WEBP'] = CFile::ResizeImageGet($idFile, array('width' => $width, 'height' => $height), $type, true)['src'];
    }
    $result['RESIZE'] = CFile::ResizeImageGet($idFile, array('width' => $width, 'height' => $height), $type, true)['src'];

    return $result;
}

CModule::IncludeModule('crm');

function getMGHpUF($ufCode){
    return \Bitrix\Main\Config\Option::get("mg.hp", $ufCode);
}


if (!defined('STATUS_ACTIVE')) {
	
//  Before user register
AddEventHandler("main", "OnBeforeUserRegister", ["RegClass", "OnBeforeUserRegisterHandler"]);
AddEventHandler("iblock", "OnAfterIBlockElementAdd", Array("MyClass", "OnAfterIBlockElementAddHandler"));
\Bitrix\Main\EventManager::getInstance()->addEventHandler('sale', 'OnBeforeSalePaymentSetField', 'changePrice');
AddEventHandler('crm', 'OnBeforeCrmContactAdd', 'OnBeforeCrmContactAddh');
AddEventHandler('crm', 'OnAfterCrmDealAdd', 'OnBeforeCrmDealAddf');

}

class RegClass
{
    public static function OnBeforeUserRegisterHandler(&$arFields)
    {
        $arFields['LOGIN'] = $arFields['EMAIL'];
    }
}

function translate_phone($phone){
    $result = preg_replace('/[^0-9,.]/', '', $phone);
    if(strlen($result) > 10){
        $result = substr($result, (strlen($result) - 10));
    }
    return $result;
}


function contacts($type, $value){
        $searchCondition = '=%VALUE';
        if($type == 'PHONE')
        {
            $searchCondition = '%VALUE';
        }
        $arFilter = array(
            'FM' => array(
                array(
                    'TYPE_ID' => $type,
                    $searchCondition => $value
                )
            ),
            'CHECK_PERMISSIONS' => 'N'
        );
        $obCompany = \CCrmContact::GetListEx(
            array('ID' => 'ASC'),
            $arFilter,
            false,
            false,
            array('*')
        );
        $arResult = [];
        while($arCompany = $obCompany->Fetch()){
            $arResult[] = $arCompany;
        }
        return $arResult;
    }

function GetContact($email,$phone)
{
	
	$phone=translate_phone($phone);
	
\Bitrix\Main\Loader::requireModule('crm');

/**
 * Телефон который будем искать
 * @var string
 */

/**
 * Список всех ID контактов с этим телефонным номером
 * @var int[]
 */
$contactIds = [];


/*
if ($phone!='') {
	
foreach (contacts('PHONE',$phone) as $c)
if (!in_array($c['ID'],$contactIds)) $contactIds[]=$c['ID'];
}

*/

if ($email!='') {
foreach (contacts('EMAIL',$email) as $c)
if (!in_array($c['ID'],$contactIds)) $contactIds[]=$c['ID'];
}

//////////// Поиск по емейлу 

if ($contactIds[0]<=0) {

	// Создать контакт с таким телефон и емейлом 
	
	
	return false;
	
}

return $contactIds;

	
}


function GetSize($si)
{
	if (($si>10000) && ($si<1024*1024)) return round($si/1024,2).' кб.';
	
	if (($si>=1024*1024) && ($si<1024*1024*1024)) return round($si/1024/1024,2).' Мб.';
	
	
	
}

global $mess;
$mess=array('0'=>'','01'=>'января','02'=>'Февраля','03'=>'марта','04'=>'апреля','05'=>'мая','06'=>'июня','07'=>'июля','08'=>'августа','09'=>'сентября','октября','ноября','декабря');

global $mess2;
$mess2=array('','января','Февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря');

function GetDate3($s)
{
	$e=explode('.',$s);
	return $e[1].'/'.$e[0].'/'.$e[2];
}


function getDatePeriod($d1,$d2)
{
	global $mess;
	global $mess2;
	// 
	$e1=explode('/',$d1);
	$e2=explode('/',$d2);
	
	if ($mess[$e2['0']]=='') $mess[$e2['0']]=$mess2[$e2['0']];
	if ($mess[$e1['0']]=='') $mess[$e1['0']]=$mess2[$e1['0']];
	
	if ($e1[0]==$e2[0]) {
		
		
		
		return $e1[1].' '.$mess[$e1[0]].' - <br>'.$e2[1].' '.$mess[$e2[0]].' '.$e2[2];
		
	}
	
	
	if ($e1[0]!=$e2[0]) {
		
		
		
		return $e1[1].' '.$mess[$e1[0]].' - <br>'.$e2[1].' '.$mess[$e2[0]].' '.$e2[2];
		
	}
	
	
}


function GetPhone($phone)
{
	$phone=str_replace('-','',$phone);
	$phone=str_replace('(','',$phone);
	$phone=str_replace(')','',$phone);
	$phone=str_replace(' ','',$phone);
	return $phone;
}







function GetDate4($s)
{
global $mess;
global $mess2;

	$e=explode('/',$s);
	
if ($mess[$e['0']]=='') $mess[$e['0']]=$mess2[$e['0']];	
	
	return $e[1].' '.$mess[$e[0]].' '.$e[2];
}


/// Событие добавление формы







class MyClass
{
    // создаем обработчик события "OnAfterIBlockElementAdd"
    public static function OnAfterIBlockElementAddHandler(&$arFields)
    {
        if($arFields["IBLOCK_ID"]==CALLBACK_FORM_IBLOCK_ID) {
			
			// Создаем лид
			
			// NAME

	$res = CIBlockElement::GetProperty($arFields["IBLOCK_ID"], $arFields["ID"], "sort", "asc", array("CODE" => "NAME"));
    if ($ob = $res->GetNext())
    {
        $NAME = $ob['VALUE'];
    }
	
	$res = CIBlockElement::GetProperty($arFields["IBLOCK_ID"], $arFields["ID"], "sort", "asc", array("CODE" => "PHONE"));
    if ($ob = $res->GetNext())
    {
        $PHONE = $ob['VALUE'];
    }
	
	$res = CIBlockElement::GetProperty($arFields["IBLOCK_ID"], $arFields["ID"], "sort", "asc", array("CODE" => "EMAIL"));
    if ($ob = $res->GetNext())
    {
        $EMAIL = $ob['VALUE'];
    }
	
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/emailT.txt','a');
fwrite($f,print_r($arFields,true)."\r\n\r\n");
fclose($f);	

	
	/////////////// Отправить сообщение форму
	
	$arEventFieldsF=array("EMAIL"=>$EMAIL,"NAME"=>$NAME,'COMMENT'=>$arFields['PREVIEW_TEXT'],'PHONE'=>$PHONE);
	CEvent::Send('FORMA', 's3', $arEventFieldsF);
	
	
	$arEventFieldsF=array("EMAIL"=>$EMAIL,"NAME"=>$NAME,'COMMENT'=>$arFields['PREVIEW_TEXT'],'PHONE'=>$PHONE,'SUBJECT'=>'Форма заказа звонка');
	CEvent::Send('NEW_CALLBACK', 's3', $arEventFieldsF);
	
	
	
	
	


LogAdd2($arFields);
	
	// Создать лид
	
	$PHONE=str_replace('(','',$PHONE);
	$PHONE=str_replace(')','',$PHONE);
	$PHONE=str_replace(' ','',$PHONE);
	$PHONE=str_replace('-','',$PHONE);

$lead = new CCrmLead(false);




	
	$arFields = array(        
"TITLE" => "Заполнена CRM-форма",        
"SOURCE_ID" => "WEBFORM",        
"NAME"=> $NAME,        
"COMMENTS" => $arFields['PREVIEW_TEXT'],        
     
);



$arPhone=[];
$arEmail=[];

if ($PHONE!='') {
	
$arPhone['ID']='n0';
		$arFields['FM']['PHONE'][$arPhone['ID']] = array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $PHONE,
  );
  
		}
	
	if ($EMAIL!='') {
	
	$arEmail['ID']='n0';
$arFields['FM']['EMAIL'][$arEmail['ID']] = array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $EMAIL,
  );
  
	}

$lead->Add($arFields);
	
	/*
	
		
if (!GetContact($EMAIL,$PHONE)) {
	
	$PHONE=str_replace('(','',$PHONE);
	$PHONE=str_replace(')','',$PHONE);
	$PHONE=str_replace(' ','',$PHONE);
	$PHONE=str_replace('-','',$PHONE);
	
$arTranslitParams = array("replace_space"=>"-","replace_other"=>"-"); // Указываем на какой символ заменять пробел, на какой символ заменять все остальные символы отличные от букв и цифр.

$ENAME = Cutil::translit(strtolower($NAME),"ru",$arTranslitParams);


$arFC=array('NAME'=>$NAME,'LAST_NAME'=>$NAME,"PHONE"=>$PHONE,'UF_CRM_1694516008'=>$ENAME,'UF_CRM_1694516019'=>$ENAME);


$arPhone=[];
$arEmail=[];

if ($PHONE!='') {
	
$arPhone['ID']='n0';
		$arFC['FM']['PHONE'][$arPhone['ID']] = array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $PHONE,
  );
  
		}
	
	if ($EMAIL!='') {
	
	$arEmail['ID']='n0';
$arFC['FM']['EMAIL'][$arEmail['ID']] = array(
    'VALUE_TYPE' => 'WORK',
    'VALUE' => $EMAIL,
  );
  
	}

$ct=new CCrmContact(false);
$iC=$ct->Add($arFC);

echo 'AAA'.$iC.'BBB';


	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2211.txt','a');
fwrite($f,'@@@@@@@@@@@@'.$ct->LAST_ERROR.'#######');
fclose($f);	
	
} else {
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2211.txt','a');
fwrite($f,'!!!!!!!!!');
fclose($f);
	
}


*/



			
			
		}
             
    }
}



function  GetInGroup($s,$a)
{
	$bb=0; 
	foreach ($a as $aa)
	{
		if (substr_count($s,$aa)>0) $bb=1;
	}
	
	if ($bb>0) return true;
	if ($bb<=0) return false;
	

	
}



function AddSert($pro, $uid)
{
	$factory131 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_SERT_ID);
	
	// Найти сертификат, есть для пользователя и программы сертификат, если нет создать. 
	
	$items131 = $factory131->getItems(array(
	'select' => ['PRODUCT_ROWS'],
	'filter' => array('PARENT_ID_'.TYPE_PRO_ID=>$pro,'CONTACT_ID'=>$uid),
));

$sert=0;

$bb=0;
foreach($items131 as $kk=>$item131)
{
	$bb=$bb+100;
	return $item131['ID'];
}

if ($bb<=0) {
	
/// Создать сертификат 
	
	$arContact=CCrmContact::GetByID($uid);
	
	$data = [
    'TITLE' => $arContact['LAST_NAME'].' '.$arContact['NAME'].' ICF Certified Coach (PCC)',
	'CATEGORY_ID'=>30,
	"STAGE_ID"=>"DT131_30:NEW",
	'CONTACT_ID'=>$uid,
	'PARENT_ID_'.TYPE_PRO_ID=>$pro,
	'MODE'=>1,
	'ASSIGNED_BY_ID'=>39736,
	"CREATED_BY"=>39736
	
];



$newItem = $factory131->createItem($data);

// echo 'Создание сертификата ';

$newItem->save();
$sert = $newItem->get('ID');

return $sert;



	
}
	
	
	
}




















function AddPos($mod, $idS, $uid,$idDeal)
{
	$factory174 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_POS_ID);
	
	// Найти сертификат, есть для пользователя и программы сертификат, если нет создать. 
	

	
	$items174 = $factory174->getItems(array(
	'select' => ['PRODUCT_ROWS'],
	'filter' => array('PARENT_ID_'.TYPE_MOD_ID=>$mod,'PARENT_ID_'.TYPE_SERT_ID=>$idS,'CONTACT_ID'=>$uid,'PARENT_ID_2'=>$idDeal),
));

$sert=0;

$bb=0;
foreach($items174 as $kk=>$item174)
{
	$bb=$bb+100;
	return $item174['ID'];
}

if ($bb<=0) {
	
/// Создать посещение
	
	$arContact=CCrmContact::GetByID($uid);
	
	// Найти данные по модулю


	
	
	$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	$item180 = $factory180->getItem($mod);
	
	
	$data = [
    'TITLE' => $arContact['LAST_NAME'].' '.$arContact['NAME'].' ICF Certified Coach (PCC)',
	'CATEGORY_ID'=>23,
	"STAGE_ID"=>"DT174_23:NEW",
	'CONTACT_ID'=>$uid,
	'PARENT_ID_'.TYPE_MOD_ID=>$mod,
	'PARENT_ID_'.TYPE_SERT_ID=>$idS,
	'PARENT_ID_'.TYPE_GROUP_ID=>$item180['PARENT_ID_'.TYPE_GROUP_ID],
	'PARENT_ID_'.TYPE_PRO_ID=>$item180['PARENT_ID_'.TYPE_PRO_ID],
	
	'PARENT_ID_2'=>$idDeal,
	'MODE'=>1,
	'ASSIGNED_BY_ID'=>39736,
	"CREATED_BY"=>39736
	
];

$newItem = $factory174->createItem($data);



// print_r($data);

$newItem->save();
$sert = $newItem->get('ID');

return $sert;



	
}
	
	
	
}



function GetPay($idm)
{
	

	
	if ($idm==5) $test=1;
	
	
global $USER;
$rsUser = CUser::GetByID($USER->GetID());
$arUser = $rsUser->Fetch();

	
	// Определяем все сделки
	
$a=GetContact($arUser['EMAIL'],$arUser['PERSONAL_PHONE']);	
	
$ids=[];
$gr=[];	 
$deals=[];
	 
	 foreach ($a as $aa) {
		 
		
		 
		 
	$res = CCrmDeal::GetList(array(), array("CONTACT_ID" =>$aa,UF_CRM_1700489375=>1,'CHECK_PERMISSIONS'=>'N'), array("ID"));
      while($ob = $res->Fetch()){
		  
		  $res2=CCrmDeal::GetById($ob['ID'],false);
  
		 
 		if (!in_array($res2['PARENT_ID_'.TYPE_MOD_ID],$gr)) {
		if ($res2['PARENT_ID_'.TYPE_MOD_ID]>0) $gr[]=$res2['PARENT_ID_'.TYPE_MOD_ID];
		
		
		
		  
	  }   // parrent
	  
	  
	  // Проверка счетов для этой сделки, и сохранение статуса
	  
	  // Определить все товары для этой сделки и от туда взять модули
	  
	  
	  
	  
	  
	  
	  		$arProducts3 = CCrmDeal::LoadProductRows($res2['ID']);
			
	
			
			
	
		foreach ($arProducts3 as $Av) {
			
			// $arProducts3  - данные по товару
			
			
			
			
			$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
			
			
			
			$products = \Bitrix\Crm\ProductRowTable::getList([
    'select' => ['*'],
    'filter' => [
	
        // 'PRODUCT_NAME' =>  $arP['PRODUCT_NAME'], // ID Товара
		// "OWNER_ID"=>$mod,  - модуль
		"PRODUCT_NAME">$Av['PRODUCT_NAME'], // Товар из сделки
		'OWNER_TYPE' => $factory180->getEntityAbbreviation()
		// 'OWNER_TYPE'=>$factory->getEntityAbbreviation()
    ]
])->fetchAll();


foreach ($products as $idP) {
	
	if ($idP['PRODUCT_ID']==$Av['PRODUCT_ID']) {
	
	if ($idP['OWNER_ID']==$idm) $deals[$idP['OWNER_ID']][]=$ob['ID'];





	}

	
}
			
			
			
			
		}
	  
	  
	  
	  
	  
	  
	  
	  	
		
		
	

	
	
	  
	  
	  
	  } // res
	  



 
	foreach ($deals as $dd) {
	
	
if (is_array($dd)) {
	
	foreach ($dd as $d) {
	

	
		if ( ($d>0) &&(!GetPayOrder($d)) ) return 'ok';
		if ( ($d>0) && (GetPayOrder($d)) ) return '2';
		
	}
		
		
}

		
	
	}
	  
	
	
	/////////////
	
}


return '';


}

function GetProgram($idg)
{
	
	// Запросить список всех групп, а потом по группе по каждой запросить список модулей, а потом проверить спомощью команды
	
	$factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);
	
	 
$items158 = $factory158->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'DESC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_'.TYPE_PRO_ID=>$idg),
));

foreach($items158 as $kk=>$item158)
{
	
	$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	
$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'DESC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_'.TYPE_GROUP_ID=>$item158['ID'],'PARENT_ID_'.TYPE_PRO_ID=>$idg),
));

$mb=1;

foreach($items180 as $kk=>$item180)
{
if (!GetPay($item180['ID'])) $mb=0;
}	
	
		
	if ($mb>0) return true;
	
	
}
	
	
	
return false;
	
}



function getCountBasket($pro,&$bo=true)
{
	
	
	$dbRes = \Bitrix\Sale\Basket::getList(
	[
		'select' => ['NAME', 'QUANTITY'],
		'filter' => [
			'=FUSER_ID' => \Bitrix\Sale\Fuser::getId(), 
			'PRODUCT_ID'=>$pro,
			'=ORDER_ID' => null,
			'=LID' => \Bitrix\Main\Context::getCurrent()->getSite(),
			'=CAN_BUY' => 'Y',
		]
	]
);
while ($item = $dbRes->fetch())
{
	
	return round($item['QUANTITY']);
	
}


return 1;

	
}


function getbyBasket($pro)
{
	
	
	$dbRes = \Bitrix\Sale\Basket::getList(
	[
		'select' => ['NAME', 'QUANTITY'],
		'filter' => [
			'=FUSER_ID' => \Bitrix\Sale\Fuser::getId(), 
			'PRODUCT_ID'=>$pro,
			'=ORDER_ID' => null,
			'=LID' => \Bitrix\Main\Context::getCurrent()->getSite(),
			'=CAN_BUY' => 'Y',
		]
	]
);
while ($item = $dbRes->fetch())
{
	
	return round($item['QUANTITY']);
	
}


	
}






function GetPayOrder($id)
{
	

	
	global $DB;

global $IOD;

$results=$DB->Query("SELECT * FROM b_crm_order_entity where OWNER_ID=".$id);
while ($row = $results->Fetch())
{
	$Order_id=$row['ORDER_ID'];
}	

if ($Order_id>0) {
	
$results=$DB->Query("SELECT * FROM b_sale_order_payment where ORDER_ID=".$Order_id.' ORDER BY ID DESC');
while ($row = $results->Fetch())
{
$st=$row['PAID'];
}	

}

if ($st=='Y') return false;
if ($st=='N') return true;
	
}


function GetCountModuleInGr($idg)
{
	// 
	
$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);

$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_'.TYPE_GROUP_ID=>$idg),
));

$co=0;

foreach($items180 as $kk=>$item180) $co=$co+1;

return $co;


}

function GetAllGr($arParams)
{ 

$grs=[];
$grss=[];
	
$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
$factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);
$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);

if ($arParams['ELEMENT_ID2']>0) $arFilterG=array('UF_CRM_'.PRO_ID.'_EVENT'=>$arParams['ELEMENT_ID2']);

$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array(),
));

$co=0;

foreach($items180 as $kk=>$item180) {

$item180 = $factory180->getItem($item180['ID']);
if ((!in_array($item180['PARENT_ID_'.TYPE_GROUP_ID],$grs)) && ($item180['PARENT_ID_'.TYPE_GROUP_ID]>0)) {

$item158 = $factory158->getItem($item180['PARENT_ID_'.TYPE_GROUP_ID]);

$item156 = $factory156->getItem($item158['PARENT_ID_'.TYPE_PRO_ID]);

$event=$item156['UF_CRM_'.PRO_ID.'_EVENT'];
if (!in_array($item158['STAGE_ID'],STAGES_GR)) {
if (($arParams['ELEMENT_ID2']<=0) && ($event>0)) {
	if (!in_array($item180['PARENT_ID_'.TYPE_GROUP_ID],$grss)) {
	$grs[$item156['ID']][]=$item180['PARENT_ID_'.TYPE_GROUP_ID];
	$grss[]=$item180['PARENT_ID_'.TYPE_GROUP_ID];
	}
}
if (($arParams['ELEMENT_ID2']>0) && ($arParams['ELEMENT_ID2']==$event) && ($event>0)) {
	if (!in_array($item180['PARENT_ID_'.TYPE_GROUP_ID],$grss)) {
	$grs[$item156['ID']][]=$item180['PARENT_ID_'.TYPE_GROUP_ID];
	$grss[]=$item180['PARENT_ID_'.TYPE_GROUP_ID];
	}
}
	
}
	
	
}
	
}

$grs2=[];

foreach ($grs as $k=>$g1) {
foreach ($g1 as $o=>$g2) {
	$grs2[]=$g2;
}
}

return $grs2;	
}

function GetProInPath($code)
{
	// Запросить все разделы и на
	
// Сначало запросить список всех разделов для инфоблока

global $USER;



$arS=[];

	$arFilter = Array('IBLOCK_ID'=>CATALOG_IBLOCK_ID,'UF_HIDE'=>0,'GLOBAL_ACTIVE'=>'Y');
	if (($USER->GetID()>0) && (GetInGroup($USER->GetUserGroupString(),HIDE_GROUP))) $arFilter = Array('IBLOCK_ID'=>CATALOG_IBLOCK_ID,'GLOBAL_ACTIVE'=>'Y','CODE'=>$code);

	
	if ($code!='') $arFilter['CODE']=$code;
	
	
	
	$db_list = CIBlockSection::GetList(Array("ID"=>'ASC'), $arFilter, true,array('UF_*'));
	while($ar_result = $db_list->GetNext())
	{
	$arS[]=$ar_result['ID'];
	if ($code!='') $ID=$ar_result['ID'];
	}
	
	
	////////
	
	
	$ID2=[];
	
	$arFilter = Array('IBLOCK_ID'=>CATALOG_IBLOCK_ID,'UF_MODULES'=>1,'GLOBAL_ACTIVE'=>'Y');
	$db_list = CIBlockSection::GetList(Array("ID"=>'ASC'), $arFilter, true,array('UF_*'));
	while($ar_result = $db_list->GetNext())
	{
	$ID2[]=$ar_result['ID'];
	}
	
	// Запросить список всех элементов
	
	$ide=[];
	
	$arSelect = Array("ID", "NAME", "DATE_ACTIVE_FROM",'PROPERTY_HIDE','IBLOCK_SECTION_ID');
	$arFilter = Array("IBLOCK_ID"=>CATALOG_IBLOCK_ID, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y",'!PROPERTY_HIDE_VALUE'=>'Y','CATALOG_AVAILABLE'=>'Y');
	if ($ID>0) $arFilter = Array("IBLOCK_ID"=>CATALOG_IBLOCK_ID, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y",'!PROPERTY_HIDE_VALUE'=>'Y','SECTION_ID'=>$ID,'!SECTION_ID'=>$ID2,'INCLUDE_SUBSECTIONS'=>'Y','CATALOG_AVAILABLE'=>'Y');
		
	

	
	if (($USER->GetID()>0) && (GetInGroup($USER->GetUserGroupString(),HIDE_GROUP))) $arFilter = Array("IBLOCK_ID"=>CATALOG_IBLOCK_ID, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y",'CATALOG_AVAILABLE'=>'Y');
$res = CIBlockElement::GetList(Array("ID"=>'ASC'), $arFilter, false, Array("nPageSize"=>50000), $arSelect);
while($ob = $res->GetNextElement())
{
	$arFields = $ob->GetFields();
	


	
if ($code=='') {
	
	
if (($arFields['IBLOCK_SECTION_ID']<=0)  && ($arFields['PROPERTY_HIDE_VALUE']!='Y') ) $ide[]=$arFields['ID'];

if (($arFields['IBLOCK_SECTION_ID']>0) && (in_array($arFields['IBLOCK_SECTION_ID'],$arS)) && ($arFields['PROPERTY_HIDE_VALUE']!='Y') && (!in_array($arFields['IBLOCK_SECTION_ID'],$ID2)) )  $ide[]=$arFields['ID'];

if ((($arFields['IBLOCK_SECTION_ID']>0) && (!in_array($arFields['IBLOCK_SECTION_ID'],$arS)) ) &&   (($USER->GetID()>0) && (GetInGroup($USER->GetUserGroupString(),HIDE_GROUP))) && (!in_array($arFields['IBLOCK_SECTION_ID'],$ID2))  )  $ide[]=$arFields['ID'];

} else {
	
	
if ($arFields['IBLOCK_SECTION_ID']==$ID) {
	
	

if (($arFields['IBLOCK_SECTION_ID']>0) && (in_array($arFields['IBLOCK_SECTION_ID'],$arS)) && ($arFields['PROPERTY_HIDE_VALUE']!='Y') && (!in_array($arFields['IBLOCK_SECTION_ID'],$ID2)) )  $ide[]=''.$arFields['ID'];

if ((($arFields['IBLOCK_SECTION_ID']>0) && (!in_array($arFields['IBLOCK_SECTION_ID'],$arS)) ) &&   (($USER->GetID()>0) && (GetInGroup($USER->GetUserGroupString(),HIDE_GROUP))) && (!in_array($arFields['IBLOCK_SECTION_ID'],$ID2))  )  $ide[]=$arFields['ID'];	

}
	
	
}
	
	
}



	
	return $ide;
	 
}

/*

	///local/components/magwai/pays/ajax.php (1)	20.03.2024 10:53:52	4.95 КБ
	////local/components/magwai/pays/templates/reg/template.php (2)	29.03.2024 14:39:00	12.39 КБ
	////local/components/magwai/personal/templates/.default/template.php (2)	03.04.2024 15:50:35	65.48 КБ
	/////local/components/magwai/reg/templates/reg/template.php (9)	03.04.2024 15:10:41	52.15 КБ
	/////local/php_interface/functions.php (1)	04.04.2024 14:19:54	55.73 КБ
	/local/templates/main/components/bitrix/news.list/schedule-detail2/template.php (2)

*/

function GetCountModule($idg)
{
	// 
	
$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	 
$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_158'=>$idg),
));

return count($items180);
	
}


function GetDateModule($idg)
{
	// 
	
$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	 
$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_158'=>$idg),
));

$item180 = $factory180->GetItem($items180['0']['ID']);

return $item180['BEGINDATE']->format("Y-m-d 00:00:00");
	
}


function GetPayIDG($idg)
{

$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	 
$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'ASC'),
	'select' => ['CONTACT_ID'],
	'filter' => array('PARENT_ID_158'=>$idg),
));

foreach ($items180 as $item180) {
	
//	echo 'm='.$item180['ID'].'p='.GetPay($item180['ID']).'<br>';
	
}

	
}

function GetPriceByDate($product_id)
{
	
	
	
	// Определяем?
	
	// Узнать дату до котой можно купить товар со скидкой
	
	$pr=0;
	$db=0; // Проверка даты, если дата меньше то выводить со скидкой
	
// Определяем есть ли у этого пользователя сделка с оплатой в период скидки с товаров внутри

$factory2 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(2);

global $USER;
$rsUser = CUser::GetByID($USER->GetID());
$arUser = $rsUser->Fetch();




$aa=GetContact($arUser['EMAIL'],$arUser['PERSONAL_PHONE']);


$items2 = $factory2->getItems(array(
	'select' => ['*'],
	'filter' => array('CONTACT_ID'=>$aa[0]),
));

$itS=[];
foreach ($items2 as $item2)
{
$itS[]=$item2['ID'];
}

$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logP9.txt','a');
fwrite($f,print_r($itS,true));
fclose($f); 



 $products = \Bitrix\Crm\ProductRowTable::getList([
    'select' => ['*','PRODUCT_NAME'],
    'filter' => [
        'PRODUCT_ID' =>  $product_id, // ID Товара
		'OWNER_ID'=>$itS,
		'OWNER_TYPE'=>$factory2->getEntityAbbreviation()
    ]
])->fetchAll();


$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logP0.txt','a');
fwrite($f,print_r($idP,true));
fclose($f); 


foreach ($products as $idP) {

$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logP2.txt','a');
fwrite($f,print_r($idP,true));
fclose($f); 


if ($idP['PRODUCT_ID']==$product_id) {
	
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logP.txt','a');
fwrite($f,print_r($idP,true));
fclose($f); 

if ($idP['OWNER_ID']>0) {


$ob=$factory2->GetItem($idP['OWNER_ID']);	 

//////////111111111111

if ($ob['UF_CRM_1712235597']>0) $db=1;
	

}


}

}


////////



	
$res = CIBlockElement::GetByID($product_id);
$ar_res2 = $res->GetNext();
	
	$res = CIBlockElement::GetProperty($ar_res2['IBLOCK_ID'], $product_id, "sort", "asc", array("CODE" => "DATA_RPRICE"));
	if ($ob = $res->GetNext())
	{
		if ( ($ob['VALUE']!='') && (time()<strtotime($ob['VALUE'])) ) $db=1;
	}
	
$db_res = CPrice::GetList(
	array(),
	array(
		"PRODUCT_ID" => $product_id,
		"CATALOG_GROUP_ID" => 7
	)
);
if ($ar_res = $db_res->Fetch())
{
	
	$pr=$ar_res["PRICE"];
}


if (($pr==0) || ($db<=0)) {


// Найти цену для модуля

/*

$factory = \Bitrix\Crm\Service\Container::getInstance()->getFactory(180);
	 $products = \Bitrix\Crm\ProductRowTable::getList([
    'select' => ['*','PRODUCT_NAME'],
    'filter' => [
        'PRODUCT_ID' =>  $product_id, // ID Товара
		'OWNER_TYPE'=>$factory->getEntityAbbreviation()
    ]
])->fetchAll();



foreach ($products as $idP) {
	// Запросить для данного см
	
	$pr=$idP['PRICE'];
	
}

*/



////////////// 


	
$db_res = CPrice::GetList(
	array(),
	array(
		"PRODUCT_ID" => $product_id,
		"CATALOG_GROUP_ID" => 1
	)
);
if ($ar_res = $db_res->Fetch())
{
	$pr=$ar_res["PRICE"];
}


//	

}
	
return $pr;
	
}

function GetPrice($a,$cm,$idGr=0,$orderBy=1)
{

global $DB;
global $USER;

$rsUser = CUser::GetByID($USER->GetID());
$arUser = $rsUser->Fetch();
	
	$discount=0;	 // Скидка в процентах
	$discountValue=0;     // Скидка в рублях


$factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
$item158 = $factory158->getItem($idGr);	

$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);
$item156 = $factory156->getItem($item158['PARENT_ID_'.TYPE_PRO_ID]);	
$orderID=[];
// Найти заказ в которых есть группа
if ($orderBy>0) {
	// Найти заказ для этой группы

$aC=GetContact($arUser['EMAIL'],$arUser['PERSONAL_PHONE']);	


foreach ($aC as $aa) {
	
	


$res = CCrmDeal::GetList(array(), array("CONTACT_ID" =>$aa,"PARENT_ID_".TYPE_GROUP_ID=>$idGr,UF_CRM_1700489375=>1,'CHECK_PERMISSIONS'=>'N'), array("ID","UF_CRM_1700489375","PARENT_ID_".TYPE_GROUP_ID));
while($ob = $res->Fetch()) {

$factory2 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(2);			
$item2 = $factory2->getItem($ob['ID']);	
	
if ($item2["PARENT_ID_".TYPE_GROUP_ID]==$idGr)	{
		  
$results=$DB->Query("SELECT * FROM b_crm_order_entity where OWNER_ID=".$ob['ID']);
while ($row = $results->Fetch())
{
	$orderID[]=$row['ORDER_ID'];
}	

	}
		  
		  
	  }   // $ob


}  // $aa

}
// 



$total_modules=GetCountModule($idGr);
	


if ($discount<15) {





 if ($arUser['UF_GOLD_STATUS']>0) $discount=15;
 if ($arUser['UF_SOC_STATUS']>0) $discount=15;

}

	// Есть ли данного пользователя и данного заказа купон
	
// $item156['UF_CRM_16_BUCKET_COUPONE_IDS']
// Найти список купонов для этих правл, и этого пользователя

if (count($orderID)>0) {

$d=implode(" or DISCOUNT_ID=",$item156['UF_CRM_16_BUCKET_COUPONE_IDS']);

$cp2=[];

if (count($item156['UF_CRM_16_BUCKET_COUPONE_IDS'])>0) {
	
	

foreach ($orderID as $orderD) {



$res22=$DB->Query('SELECT * FROM b_sale_discount_coupon WHERE ( DISCOUNT_ID='.$d.') and (USER_ID='.$USER->GetID().' or USER_ID=0)');	

/////////// Одноразовый купон

while ($row = $res22->Fetch())
{	

$results=$DB->Query('select * FROM sales where IDU='.$USER->GetID()." and CUPON='".$row['COUPON']."'  and ORDER_ID=".$orderD." ORDER BY STIM DESC;")->Fetch();
if ($results['IDU']>0) $cp2[$results['STIM']]=$results['CUPON'];
}

}


}

foreach ($cp2 as $cupon)
{
	
	$getCoupon = \Bitrix\Sale\DiscountCouponsManager::getData($cupon, true); 

	  if ($getCoupon['DISCOUNT_ID']>0) {
		  
		   $aD=$DB->Query('select * FROM b_sale_discount where ID='.$getCoupon['DISCOUNT_ID'])->fetch();
		   
		   
		   $c=unserialize($aD['SHORT_DESCRIPTION']);
		   
		   
		   
		// Смотрим есть ли условия для докупки   
		   
		   

 if ($c['VALUE_TYPE']=='P') {	

 $v=$c['VALUE'];
 
$discount=$v;
 
	  }
	  

if ($c['VALUE_TYPE']=='S') { 

 $discountValue=$c['VALUE'];
 

 
}
  
	
		  
	  }
	
}

}



/////////// Вечный купон
	
	
	$ap2=getMGHpUF('UF_VECH');
	$cp=[];
	
foreach ($ap2 as $aa2) {	

$results=$DB->Query('select * FROM sales where IDU='.$USER->GetID()." and CUPON='".$aa2."' ORDER BY STIM DESC;")->Fetch();
if ($results['IDU']>0) $cp[$results['STIM']]=$results['CUPON'];
}

foreach ($cp as $cupon)
{
	
	$getCoupon = \Bitrix\Sale\DiscountCouponsManager::getData($cupon, true); 

	  if ($getCoupon['DISCOUNT_ID']>0) {
		  
		   $aD=$DB->Query('select * FROM b_sale_discount where ID='.$getCoupon['DISCOUNT_ID'])->fetch();

		   $c=unserialize($aD['SHORT_DESCRIPTION']);
		   
		// Смотрим есть ли условия для докупки   
		   
		   

 if ($c['VALUE_TYPE']=='P') {	

 $v=$c['VALUE'];
 
$discount=$v;
 
	  }
	  
		  
	  }
	
}


//////////////////////////////////////////////

	
	
	if ($a<=0) return 1;
	
	// $discount 
	


if ($discount<=0) {
	
	
	
	if ($cm==1) return round($a,2);
	if (($cm>1) && ($cm<$total_modules)) $discount=5;
	if ($cm>=$total_modules) $discount=10;

	
} 



$PRICE_NEW=round($a*(100-$discount)/100,2);

if ($discountValue>0) {

$PRICE_NEW=$PRICE_NEW-$discountValue;
	
}
	

return $PRICE_NEW;
	
	
}

function RegTall($idm, $status='paid',$contact_id=0,$pid=0)
{ 

global $USER;

$rsUser = CUser::GetByID($USER->GetID());
$arUser = $rsUser->Fetch();
	
					$module = 'Contact';
							
							if ($_COOKIE['LAST_NAME']=='') $_COOKIE['LAST_NAME']=$arUser['LAST_NAME'];
							if ($_COOKIE['NAME']=='') $_COOKIE['NAME']=$arUser['NAME'];
							if ($_COOKIE['PERSONAL_PHONE']=='') $_COOKIE['PERSONAL_PHONE']=$arUser['PERSONAL_PHONE'];
							if ($_COOKIE['EMAIL']=='') $_COOKIE['EMAIL']=$arUser['EMAIL'];

		//
		
		if ($contact_id>0) {
			
		// Найти 	
		
	
		
		
	$dbResMultiFields = CCrmFieldMulti::GetList(
             array('ID' => 'asc'),
             array('ENTITY_ID' => 'CONTACT', 'ELEMENT_ID' => $contact_id)
);

$idU='';

$ob2=CCrmContact::GetByID($contact_id,false);

while($arMultiFields = $dbResMultiFields->Fetch())
{
	if ($arMultiFields['TYPE_ID']=='EMAIL')  $_COOKIE['EMAIL']=$arMultiFields['VALUE'];
	if ($arMultiFields['TYPE_ID']=='PHONE')  $_COOKIE['PERSONAL_PHONE']=$arMultiFields['VALUE'];
}

if ($ob2['NAME']!='') $_COOKIE['NAME']=$ob2['NAME'];
if ($ob2['LAST_NAME']!='') $_COOKIE['LAST_NAME']=$ob2['LAST_NAME'];
		
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logTalant3AAAAContact.txt','a');
fwrite($f,print_r($ob2,true));
fclose($f);
		 
		
			
		}
		

		
							$params = array(
							    'last_name' => $_COOKIE['LAST_NAME'], // фамилия
							    'first_name' => $_COOKIE['NAME'], // имя
							    'phone_mobile' =>$_COOKIE['PERSONAL_PHONE'], // телефон
							    'email1' => $_COOKIE['EMAIL'], //email
							    'send_sms' => 'На мобильный', 
							    'notice' => 'Тестовый', // комментарий к ученику
							    'most_class_contacts_id' => $idm, // ID занятия
						        'most_class_contacts_reserve' => 0,
								'description'=>'Тест',
							    'data_user_id' => 'd5751f0b-1a87-783d-1203-5cea7b7f214d'
							);
							if(!empty($coord_code)):
								$params['most_class_user_id'] = $coord_code; // ответственный за занятие сотрудник по ID  в Талланто
								$params['assigned_user_id'] = $coord_code; // ответственный сотрудник по ID  в Талланто
							endif;

							if($waiting_list == 'Y' || $waiting_list == 193): //в список ожидания
								$params['most_class_contacts_status'] = 'in-query';
							elseif($registration == 'Y'): //предварительная краткая запись
								$params['most_class_contacts_status'] = 'pre-visit';
							else: //статус не придет временно, статус сменится, если пройдут второй шаг
								$params['most_class_contacts_status'] = 'not-visit';
							endif;
							
							$params['most_class_contacts_status'] = 'pre-visit';
							
							if(!empty($city)):
								$params['primary_address_city'] = $city;
							endif;

							if ($participation == 'Онлайн'):
							    $params['most_class_contacts_role'] = 'online';
							else:
							    $params['most_class_contacts_role'] = 'offline';
							endif;
							
							if ($status=='Y')  {
								$params['most_class_contacts_status']='paid';
							}
							
							if ($status=='A')  {
								$params['most_class_contacts_status']='prepay';
							}
							
		
							

if (($status=='A') || ($status=='Y') )  {
								
$params['update_duplicate_info']=array(								
'most_class_contacts_status' => 'rewrite',
'most_class_contacts_tag' => 'rewrite',
'most_class_contacts2_tag' => 'rewrite',
'most_class_contacts_reserve' => 'rewrite',
'most_class_contacts_role' => 'rewrite',
				);			

global $bk;

$params['most_class_contacts2_tag']=$bk[$pid];
			
}			
							
								
				
							if (isset($check_duplicate_by) AND !empty($check_duplicate_by))  $params['check_duplicate_by'] = $check_duplicate_by;
							if (isset($update_duplicate_info) AND !empty($update_duplicate_info))  $params['update_duplicate_info'] = $update_duplicate_info;
							
						
								
								if (($params['email1']!='') && ($params['last_name']!='') && ($params['first_name']!='') && ($params['phone_mobile']!='') ) $resultContact = senderToTallan2($module, $params);
								
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logTalant3AAAA.txt','a');
fwrite($f,print_r($params,true));
fclose($f);
							
							if ($resultContact['id']!='')	{
								// Обновить ответ с таланта
								global $USER;
								$USER->Update($USER->getID(),array('UF_ID_TALLANTO'=>$resultContact['id']));
							}
							
			
			
	
}

		function senderToTallan2($module, $params)
							{
								
								
								
							    $crm_url = 'http://erickson.tallanto.com';
							    $url = $crm_url . '/index.php?entryPoint=dataCapture&module=' . $module;
							    $key = 'f13bf4a29f5de45f03fe43a210e49deb942fc69f';
							    uksort($params, "strcasecmp");
							    $values = "";
							    foreach ($params as $name => $value) {
							        if (is_array($value) && count($value) === 0) continue;
							        if (is_array($value)) {
							            $values .= 'Array';
							        } else {
							            $values .= $value;
							        }
							    }
							    $params['crc'] = md5($values . $key);
							
							    $options = array(
							        'http' => array(
							            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
							            'method' => 'POST',
							            'content' => http_build_query($params),
							        ),
							    );
							
							    try {
							        $context = stream_context_create($options);
							        $serverRes = file_get_contents($url, false, $context);
							
							       //Здесь можно произвести обработку запроса, но пока убераем вывод любых сообщений
							        $result = json_decode($serverRes, true);
									
							
				
							    } catch (Exception $e) {
							        // серверная ошибка, так же пока ничего не выводим, при неудачи
							        echo $e->getMessage();
							    }
							    return $result;
							}
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
function changePrice(\Bitrix\Main\Event $event) 
{ 




global $DB;

    $name = $event->getParameter('NAME'); 

	$order = $event->getParameter('ENTITY');
	$id = $order->getField('ORDER_ID');
	
	// Найти контак для данной сделки
	
	
	
	
	$ID = $order->getField('ID');
	
	$PAY_ID=$order->getField('PAY_SYSTEM_ID');
	
    $value = $event->getParameter('VALUE'); 
	
	if ($ID>0) {
	
	// Определим данные по этой платежке $ID стоимость, дата и время оплаты, номер оплаты.
	
$ACN='';
$SU='';
$SP='';
$results=$DB->Query("SELECT * FROM b_sale_order_payment where ID=".$ID);
while ($row = $results->Fetch())
{
	$ACN=$row['ACCOUNT_NUMBER'];
	$SU=$row['SUM']; 



$f=fopen($_SERVER["DOCUMENT_ROOT"].'/pd200.txt','a');
fwrite($f,$PAY_ID."\r\n");
fclose($f); 

if ($row['PAY_SYSTEM_ID']>0) {
$paySystemService = PaySystem\Manager::getObjectById($row['PAY_SYSTEM_ID']);
$SP=$paySystemService->getField("NAME");
}




}

}
	
    if ((PayInTable($ID)) && ($id>0) && ($name == 'PAID') && ($value =="Y")) {  // это проверка, что ставится флаг оплаты в этот момент, как пример
	
	// Найти для этого заказа номер сделки 
	global $DB;
	$idDeal=0;
	$results=$DB->Query("SELECT * FROM b_crm_order_entity where ORDER_ID=".$id);
while ($row = $results->Fetch())
{
	$idDeal=$row['OWNER_ID'];
}


/// Является ли заказом интернет магазина

if ($idDeal>0) {
	
$factory2 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(2);	
$item2=$factory2->GetItem($idDeal);

if ($item2['CATEGORY_ID']=='0') {
	
$dbRes = \Bitrix\Sale\PropertyValueCollection::getList([
	'select' => ['*'],
	'filter' => [
		'=ORDER_ID' => $id, 
	]
]);
while ($item = $dbRes->fetch())
{

if ($item['CODE']=='ADDRESS') $addr=$item['VALUE'];
if ($item['CODE']=='EMAIL') $email=$item['VALUE'];
if ($item['CODE']=='PHONE') $phone=$item['VALUE'];
if ($item['CODE']=='FIO') $fio=$item['VALUE'];
if ($item['CODE']=='LAST_NAME') $LAST_NAME=$item['VALUE'];
if ($item['CODE']=='NAME') $NAME=$item['VALUE'];
	
}

	
	
// 
	
	
	
	

	global $DB;
	
	
$aD1=$DB->Query('SELECT * FROM b_sale_order where ID='.$id)->Fetch();


if  ($aD1['DELIVERY_ID']>0) $aD=$DB->Query('SELECT * FROM b_sale_delivery_srv where id='.$aD1['DELIVERY_ID'])->Fetch();

// $da=$order->getField('DATE_INSERT')->format("Y-m-d");


$rsUser2 = CUser::GetByID($item158['ASSIGNED_BY_ID']);
$arUser2 = $rsUser2->Fetch();

/// Телефон для этого контакта
if ($item2['CONTACT_ID']>0) {
	


$dbResMultiFields = CCrmFieldMulti::GetList(
             array('ID' => 'asc'),
             array('ENTITY_ID' => 'CONTACT', 'ELEMENT_ID' => $item2['CONTACT_ID'],'TYPE_ID'=>'PHONE')
);
while($arMultiFields = $dbResMultiFields->Fetch())
{
	  
if ($arMultiFields['VALUE']!='') $phone=$arMultiFields['VALUE'];
		  
}
	
	
}
/// Товары в описание

$desc='';
$type='';
// 

// Получить список товар:

$arProducts = CCrmDeal::LoadProductRows($idDeal);

foreach ($arProducts as $aP)
{
	$desc=$desc.'Товар: '.print_r($aP['PRODUCT_NAME'],true).'<br>';
}



if ($aD1['DELIVERY_ID']!='5') $aD['NAME']=$aD['NAME'].'<br>Адрес доставки: '.$addr;
if ($aD1['DELIVERY_ID']=='5') $aD['NAME']=''.$aD['NAME'].'<br>Выбранный ПВЗ: '.$addr;

	
  $arEventFields = [
                                    "USER_NAME"     => $LAST_NAME.' '.$NAME,
                                    "USER_EMAIL"    => $email,
                                    "ID_ORDER"      => $id,
                                    "DATE_DELIVERY" => $aD1['DATE_INSERT'],
									"PHONE"=>$phone,
                                    // "NUM_DELIVERY"  => 'Трекер доставки',
								    // "DESCRIPTION"   => 'описание',
                                    "PRICE"         => $aD1['PRICE'].' руб.',
                                    "DATETIME"      => date('H:i d.m.Y',time()),
									"DELIVERY"=>$aD['NAME'],
									"ACC"=>$ACN,
									"ACCOUNT"=>$ACN,
									"DESCRIPTION"=>$desc,
                                    "COMMENT_ORDER" => $aD1['USER_DESCRIPTION'],
                                    "TYPE"          => "Карта",
                                ];
											

				

CEvent::Send("DELIVERY_SEND", "s3", $arEventFields);
	
	
	// Отправляю письмо от успешном заказе
	
}
	

}	

////////////////

// Для данной сделки проверить товары, и если есть товары с датой установить что товар был куплен в период скидки. 

if ($idDeal>0) {

$arProducts3 = CCrmDeal::LoadProductRows($idDeal);




		
	$be=0;

		foreach ($arProducts3 as $Av) {
			
			
	// Определить дату для данного товара
	
	
	$res2 = CIBlockElement::GetByID($Av['PRODUCT_ID']);
	$ar_res2 = $res2->GetNext();
	
	$res44 = CIBlockElement::GetProperty($ar_res2['IBLOCK_ID'], $ar_res2['ID'], "sort", "asc", array("CODE" => "DATA_RPRICE"));
	if ($ob44 = $res44->GetNext())
	{
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/be5.txt','a');
fwrite($f,'id='.$ar_res2['ID']. "\r\n\2222"."\r\n\r\n");
fwrite($f,print_r($ob44,true)."\r\n\r\n");
fclose($f);		

	
	
		
		
		if ( ($ob44['VALUE']!='') && (time()<strtotime($ob44['VALUE'])) ) $be=1;
	}
	
	
	
	
	
	
			
	
			
		}
		
		$upD15=array('UF_CRM_1712235597'=>1);
if ($be>0) {
	
$entity = new CCrmDeal(false); 
$entity->update($idDeal,$upD15);
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/be.txt','a');
fwrite($f,print_r($ar_res2,true)."\r\n\r\n");
fclose($f);	
	
}

		}

// Получает список всех оплаченных сделок

$prs=[];
$sprs=[];
$idss=[];


$results=$DB->Query("SELECT * FROM b_sale_order_payment where ORDER_ID=".$id);
while ($row = $results->Fetch())
{
	
	$prs[$row['ID']]=$row['SUM'];
	$sprs[$row['ID']]=$row['PAID'];
	$idss[]=$row['ID'];
	
	if ($row['PAID']=='Y') $pd=$pd+$row['SUM'];
	if ( ($row['PAID']!='Y') && ($row['ID']==$ID) ) $pd=$pd+$row['SUM'];
	
	if ( ($row['PAID']=='Y') && ($row['ID']==$ID) ) $pd=$pd-$row['SUM'];
	
}


/////// Отправить сообщение по этой сделке

if ($idDeal>0) {
	
	
$ob=CCrmDeal::GetById($idDeal,false);

if ($ob['CONTACT_ID']>0) {
	

	
$ob2=CCrmContact::GetById($ob['CONTACT_ID'],false);

$rs = CCrmFieldMulti::GetList(
    array(),
    array('ELEMENT_ID' => $ob['CONTACT_ID'],'TYPE_ID'=>'EMAIL','')
);

// Сохранить 

while($arMultiFields = $rs->Fetch())
{

$arEventFields = array(
	"EMAIL"             => $arMultiFields['VALUE'],
	"FIRST_NAME"=>$ob2['EMAIL'],
	"LAST_NAME"=>$ob2['LAST_NAME']

);	

//$ACN='';
//$SU='';
// $SP='';

if ($SU!='') $arEventFields['SUMMA']=number_format($SU, 2, ',', ' ').' руб.';
if ($SP!='') $arEventFields['PAY']=$SP;
if ($ACN!='') $arEventFields['ACCOUNT']=$ACN;

$arEventFields['DATEA']=date('d.m.Y H:i:s',time());


}



}






$idg=$ob['PARENT_ID_158'];
	
if ($idg>0) {
	
$EP='REG_PAY';
	
$factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
$item158 = $factory158->getItem($idg);		

$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);	
$item156 = $factory156->getItem($item158['PARENT_ID_'.TYPE_PRO_ID]);

$arEventFields['EVENT_START_DATE']=$item158['BEGINDATE']->format("Y-m-d");
$arEventFields['EVENT_END_DATE']=$item158['CLOSEDATE']->format("Y-m-d");

$res = CIBlockElement::GetByID($item158['UF_CRM_17_EVENT_CITY']);
if($ar_res = $res->GetNext()) $arEventFields['EVENT_CITY']=$ar_res['NAME'];


$res = CIBlockElement::GetByID($item156['UF_CRM_16_EVENT']);
if($ar_res = $res->GetNext()) {
	$arEventFields['NAME']=$ar_res['NAME'];
	$arEventFields['EVENT_NAME']=$ar_res['NAME'];
}


if ($item158['ASSIGNED_BY_ID']>0) {
	
	 // найти данные по пользователю
	 
$rsUser2 = CUser::GetByID($item158['ASSIGNED_BY_ID']);
$arUser2 = $rsUser2->Fetch();
	 
	


if ($arUser2['PERSONAL_PHOTO']>0) $arEventFields['COORD_PHOTO']='<img src="http://new.erickson.ru/'.CFile::GetPAth($arUser2['PERSONAL_PHOTO']).'">';



 $arEventFields['COORD_NAME']=$arUser2['NAME'];
 $arEventFields['COORD_PHONE']=$arUser2['PERSONAL_PHONE'];


	
	
}
	
	
}
	
	
	


if ($EP!='') CEvent::Send($EP, 's3', $arEventFields);	
	
	
	
}

////////////////////////////////


if (($pd>0) && ($idDeal>0) ) {
	

// Обновить это свойство

CModule::IncludeModule('crm');

$factoryLead = Service\Container::getInstance()->getFactory(\CCrmOwnerType::Deal);
$newLead = $factoryLead->getItem($idDeal);

$f=fopen($_SERVER["DOCUMENT_ROOT"].'/pd.txt','a');
fwrite($f,'');
fclose($f); 

$newLead->set('UF_CRM_1707412730', $pd.'|RUB');
$newLead->save();





$operation = $factoryLead->getAddOperation($newLead);
            $operation
                ->disableCheckAccess()
                ->enableAfterSaveActions()
                ->enableBizProc()
                ->enableAutomation()
            ;
$resultOperation=$operation->launch();
$errorsNewLead=[];
if ($resultOperation->isSuccess())
{
	// success
}
else
{
	//fail
	$errorsTmp = $resultOperation->getErrors();
    foreach ($errorsTmp as $err)
    {
       $errorsNewLead []= $err->getMessage();
	}
}



	
}


	


////////


if ($idDeal>0) {

// Найти все поля 

$obD=CCrmDeal::GetById($idDeal,false);


if ($obD['CONTACT_ID']>0) {
	
// Найти емейл и телефоны этого контакта



$dbResMultiFields = CCrmFieldMulti::GetList(
             array('ID' => 'asc'),
             array('ENTITY_ID' => 'CONTACT', 'ELEMENT_ID' => $obD['CONTACT_ID'],'TYPE_ID'=>'EMAIL')
);

$idU='';

while($arMultiFields = $dbResMultiFields->Fetch())
{
	
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2YES.txt','a');
fwrite($f,print_r($arMultiFields,true));
fclose($f); 

// Найти пользователя по телефону




if ($arMultiFields['TYPE_ID']=='EMAIL') {
	
	if ($arMultiFields['VALUE']!='') {
		
		
	
$dbUser = CUser::GetList(($by="personal_country"), ($order="desc"), array('LOGIN' => $arMultiFields['VALUE']),array("SELECT"=>array('UF_*')));
if ($arUser = $dbUser->fetch()){ 

if ($arUser['UF_ID_TALLANTO']!='') $idU=$arUser['UF_ID_TALLANTO'];


}	


	}
	
	
	
}









	
	
}

// Если нашел пользователи и его код

if ($idU!='') {
	
	
	
	$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2YESO9999999.txt','a');
fwrite($f,"ssssssss\r\n");
fclose($f); 

//////////////// найти модули по сделке $idDeal


$mss=[];
$pm=[];
$ms=[];

$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(180);

$arProducts3 = CCrmDeal::LoadProductRows($idDeal);

$w=0;

foreach ($arProducts3 as $arP)
{
	
	$w=$w+1;
	
	
	
		$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2YESOWWWWWWWWWW.txt','a');
fwrite($f,"wwwwwwwwww\r\n");
fclose($f);
	
	
	
	
	


			$products = \Bitrix\Crm\ProductRowTable::getList([
    'select' => ['*'],
    'filter' => [
    'PRODUCT_ID' =>  $arP['PRODUCT_ID'], // ID Товара
	'OWNER_TYPE' => $factory180->getEntityAbbreviation()
    ]
])->fetchAll();


foreach ($products as $idP) {
	

	
if ($arP['PRODUCT_ID']==$idP['PRODUCT_ID']) {
	
	
	
	
$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(180);
$item180 = $factory180->getItem($idP['OWNER_ID']);


$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2YESOqqqqqqqqqq.txt','a');
fwrite($f,$item180['UF_CRM_18_TALANTO_ID']."\r\n");
fclose($f); 
	

if ($obD['PARENT_ID_158']==$item180['PARENT_ID_158']) {
	
	if ($item180['UF_CRM_18_TALANTO_ID']!='111') {
		$mss[]=$item180['UF_CRM_18_TALANTO_ID'];
		$ms[$item180['UF_CRM_18_TALANTO_ID']]=$item180['ID'];
	}
	$pm[$item180['UF_CRM_18_TALANTO_ID']]=$arP['PRICE'];
	
}
	
	
}
	
	
	
	
}

	
	
}



$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logMSS20.txt','a');
fwrite($f,'A::'.print_r($sprs,true)."\r\n");
fwrite($f,'VV'.print_r($prs,true)."\r\n");
fwrite($f,'ZZZ'.print_r($idss,true)."\r\n");
fclose($f); 

$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logMSS0.txt','a');
fwrite($f,print_r($mss,true));
fclose($f); 

$type='Безналичный расчет';

if (max($prs)>$prs[$ID]) {
	
	$type='Предоплата';
	
	$mss2=$mss;
	
	
	 
	$idm=reset($mss2);
	
	
	
	global $types;
	global $bk;
	
	
			
		$module = 'most_finances';			
					
					$params = array(
						'contact_id'    => $idU, // Ученик
						'cost'          => $prs[$ID], // Сумма
						'date_payment'  => date('Y-m-d'), // Дата операции
						'direction'     => 'Поступление на баланс 2', // Направление платежа
						'name'          => $name_order, // Название
						'most_class_id' => $idm, // Занятие
						'most_class_contacts2_tag'=>$bk[$PAY_ID],
						'type' => $types[$PAY_ID],
						'description' => 'Оплаченный счет с сайта через эквайринг',
						'data_user_id' => 'd5751f0b-1a87-783d-1203-5cea7b7f214d'
					);
					if (isset($check_duplicate_by) AND !empty($check_duplicate_by))  $params['check_duplicate_by'] = $check_duplicate_by;
					if (isset($update_duplicate_info) AND !empty($update_duplicate_info))  $params['update_duplicate_info'] = $update_duplicate_info;
					
					
				if (($idU!='') && ($pm[$idm]>0) && ($idm!='') ) {	
					
				$resultContact22 = senderToTallan2($module, $params);	
				
				RegTall($idm,'A',$ob['CONTACT_ID'],$PAY_ID);
				
				}
					
		
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2YESTalanA_'.$idm.'.txt','a');
fwrite($f,print_r($resultContact22,true)."\r\n");

fwrite($f,'@: '.print_r($params,true)."\r\n");


fwrite($f,'idU='.$idU."\r\n");
fwrite($f,'pm='.$pm[$idm]."\r\n");
fwrite($f,'name='.$name_order."\r\n");
fwrite($f,'idm='.$idm."\r\n");
fclose($f); 	
		
	
	
	
	
	
	
	
	
} else {
	
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logMSS10.txt','a');
fwrite($f,print_r($mss,true));
fclose($f); 

// Определяем предоплату и уменьшаем на ее размер окончательный рассчет

$sp0=0;

foreach ($prs as $k=>$p)
{
	if ($sprs[$k]=='Y') $sp0=$sp0+$prs[$k];
}

$pi=0;

foreach ($mss as $idm) {
	
	$pi=$pi+1;
	
	if ($pi==1) $pm[$idm]=$pm[$idm]-$sp0;
	





$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logMSS1OK.txt','a');
fwrite($f,print_r($mss,true));
fclose($f); 
	

					//Заполняем массив с параметрами ученика
					
					
global $types;					
					
			
		$module = 'most_finances';			
					
					$params = array(
						'contact_id'    => $idU, // Ученик
						'cost'          => $pm[$idm], // Сумма
						'date_payment'  => date('Y-m-d'), // Дата операции
						'direction'     => 'Поступление на баланс 2', // Направление платежа
						'name'          => $name_order, // Название
						'most_class_id' => $idm, // Занятие
						'most_class_contacts2_tag'=>'bk',
						'type' => $types[$PAY_ID],
						'description' => 'Оплаченный счет с сайта через эквайринг',
						'data_user_id' => 'd5751f0b-1a87-783d-1203-5cea7b7f214d'
					);
					if (isset($check_duplicate_by) AND !empty($check_duplicate_by))  $params['check_duplicate_by'] = $check_duplicate_by;
					if (isset($update_duplicate_info) AND !empty($update_duplicate_info))  $params['update_duplicate_info'] = $update_duplicate_info;
					
					
				if (($idU!='') && ($pm[$idm]>0) && ($idm!='') ) {	
					
				$resultContact = senderToTallan2($module, $params);	
				
				}
					
					
RegTall($idm,'Y',$ob['CONTACT_ID'],$PAY_ID);
				
		
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log222222222222YESTalanA22_'.$idm.'.txt','a');
fwrite($f,print_r($resultContact22,true)."\r\n");

fwrite($f,'@: '.print_r($params,true)."\r\n");


fwrite($f,'idU='.$idU."\r\n");
fwrite($f,'pm='.$pm[$idm]."\r\n");
fwrite($f,'name='.$name_order."\r\n");
fwrite($f,'idm='.$idm."\r\n");
fclose($f); 	

		

	
	
}

} // Не предоплата

/// Сохраним список модулей


















	
}



	
}






}
	

	
          //  return new \Bitrix\Main\EventResult(\Bitrix\Main\EventResult::ERROR, new \Bitrix\Sale\ResultError('You cant pay this now', 'code'), 'sale');
        }
        else
        {
			
		$f=fopen($_SERVER["DOCUMENT_ROOT"].'/log2NO.txt','a');
fwrite($f,$id);
fclose($f); 	
			
            // return new \Bitrix\Main\EventResult(\Bitrix\Main\EventResult::SUCCESS);
        }
  
  
}
		
		
		
		
		
		
		
		
		
		
		








function GetAllProSort($arFi)
{
	$chi=0;
	global $msE;
	$msE=[];

$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);			
				  
				  $items156 = $factory156->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFi,
));

/////// Запросить все группы


foreach($items156 as $kk=>$item156)
{


  $arFilter2=array('PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']);
					  if (($_REQUEST['cities']>1) && ($_REQUEST['cities']!='undefined')) $arFilter2['UF_CRM_'.GR_ID.'_EVENT_CITY']=$_REQUEST['cities'];
					  
					 if ($_REQUEST['formats']>1) $arFilter2['UF_CRM_17_FORMAT_1694767121']=$_REQUEST['formats'];  
			  
			$arFilter2['!STAGE_ID']=STAGES_GR;	  
			$arFilter2['!STAGE_ID'][]=STAGES_GR2;	  
				
					  
 $factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
				  
$items158 = $factory158->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter2,
));




foreach($items158 as $kk=>$item158)
{
	
	$chi=$chi+1;
	
	if ((!in_array($item158['STAGE_ID'],STAGES_GR)) && (!in_array($item158['STAGE_ID'],STAGES_GR2))) {
	
	$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);
	 
$items180 = $factory180->getItems(array(
'order'=>array('UF_CRM_'.MOD_ID.'_DATE_START'=>'DESC'),
	'select' => ['CONTACT_ID'],
	//'filter' => array('PARENT_ID_'.TYPE_GROUP_ID=>$item158['ID'],'PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']),
	'filter' => array('PARENT_ID_'.TYPE_GROUP_ID=>$item158['ID'],'PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']),
));

$d='';

$min='2300000000';

// if ($item158['ID']==227) echo $item156['ID'].'@@@<br>';

foreach($items180 as $kk=>$item180)
{

$item180 = $factory180->getItem($item180['ID']);	

if ($min>$item180['BEGINDATE']->getTimestamp()) $min=$item180['BEGINDATE']->getTimestamp();


// echo $item158['ID'].'@'.$item180['BEGINDATE'].'<br>';



}	
	
	
	
	
$msE[$min+$chi]=$item158['ID'];
	
	
	
	
}	
	


}

}

ksort($msE);

return $msE;

	
}



function GetAll($value,$type)
{
	$ids=[];
	if ($type=='format') {
	


	
		// Определяем данные
		
		
		global $msE;
	$msE=[];

$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);			
				  
				  $items156 = $factory156->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFi,
));

/////// Запросить все группы


foreach($items156 as $kk=>$item156)
{


	
	 $arFilter2=array('PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']);

$arFilter2['UF_CRM_17_FORMAT_1694767121']=$value;  
			  
			$arFilter2['!STAGE_ID']=STAGES_GR;	  
			$arFilter2['!STAGE_ID'][]=STAGES_GR2;	  
				
					  
 $factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
				  
$items158 = $factory158->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter2,
));




foreach($items158 as $kk=>$item158)
{
	


if (!in_array($item158['ID'],$ids)) $ids[]=$item158['ID'];

}

}

		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
if ($type=='category')
{
	
	
	$arFilter=[];
	
	
			
			// Смотрим элменты в этом разделе
			
			
			
			
			$res = CIBlockElement::GetList(Array(), array("IBLOCK_ID"=>TRAININGS_IBLOCK_ID,"SECTION_ID"=>$value,"INCLUDE_SUBSECTIONS"=>'Y'), false, Array("nPageSize"=>50), $arSelect);
while($ob = $res->GetNextElement())
{
$arFields = $ob->GetFields();
$arFilter['UF_CRM_'.PRO_ID.'_EVENT'][]=$arFields['ID'];
}
			
			
			
			
	$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);			
				  
				  $items156 = $factory156->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter,
));

/////// Запросить все группы


foreach($items156 as $kk=>$item156)
{


  $arFilter2=array('PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']);
					  if (($_REQUEST['cities']>1) && ($_REQUEST['cities']!='undefined')) $arFilter2['UF_CRM_'.GR_ID.'_EVENT_CITY']=$_REQUEST['cities'];
					  
					 if ($_REQUEST['formats']>1) $arFilter2['UF_CRM_17_FORMAT_1694767121']=$_REQUEST['formats'];  
			  
			$arFilter2['!STAGE_ID']=STAGES_GR;	  
			$arFilter2['!STAGE_ID'][]=STAGES_GR2;	  
				
					  
 $factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
				  
$items158 = $factory158->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter2,
));




foreach($items158 as $kk=>$item158)
{

if (!in_array($item158['ID'],$ids)) $ids[]=$item158['ID'];

}

}	
			
			
}		



if ($type=='pro')
{
	
	
	
	
$arFilter['UF_CRM_'.PRO_ID.'_EVENT'][]=$value;  

			
			
			
			
	$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);			
				  
				  $items156 = $factory156->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter,
));

/////// Запросить все группы


foreach($items156 as $kk=>$item156)
{


  $arFilter2=array('PARENT_ID_'.TYPE_PRO_ID=>$item156['ID']);
					  if (($_REQUEST['cities']>1) && ($_REQUEST['cities']!='undefined')) $arFilter2['UF_CRM_'.GR_ID.'_EVENT_CITY']=$_REQUEST['cities'];
					  
					 if ($_REQUEST['formats']>1) $arFilter2['UF_CRM_17_FORMAT_1694767121']=$_REQUEST['formats'];  
			  
			$arFilter2['!STAGE_ID']=STAGES_GR;	  
			$arFilter2['!STAGE_ID'][]=STAGES_GR2;	  
				
					  
 $factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
				  
$items158 = $factory158->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter2,
));




foreach($items158 as $kk=>$item158)
{

if (!in_array($item158['ID'],$ids)) $ids[]=$item158['ID'];

}

}	
			
			
}
				
			
	
	
	
	
	
	
	
	
	
	
if ($type=='city')
{
	
	
	
	
$arFilter=[];  

			
			
			
			
	$factory156 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_PRO_ID);			
				  
				  $items156 = $factory156->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter,
));

/////// Запросить все группы


foreach($items156 as $kk=>$item156)
{


  					  $arFilter2['UF_CRM_'.GR_ID.'_EVENT_CITY']=$value;
					  
				  
			$arFilter2['!STAGE_ID']=STAGES_GR;	  
			$arFilter2['!STAGE_ID'][]=STAGES_GR2;	  
				
					  
 $factory158 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_GROUP_ID);			
				  
$items158 = $factory158->getItems(array(
	'select' => ['CONTACT_ID'],
	'filter' => $arFilter2,
));




foreach($items158 as $kk=>$item158)
{

if (!in_array($item158['ID'],$ids)) $ids[]=$item158['ID'];

}

}	
			
			
}
				
			
	
	
	

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
return $ids;	
	
}






function OnBeforeCrmContactAddh(&$arMenu) {
	
	$arMenu['ASSIGNED_BY_ID']=39736;
	
if ($arMenu['LAST_NAME']=='Контакт #') {
	return false;
}




LogAdd2($arMenu);
LogAdd2($_SERVER);
LogAdd2($_REQUEST);




   
   
}



function GetProductBy($p,$co)
{

if ($co>0) {
	
$res = CCrmDeal::GetList(array(), array("CONTACT_ID" =>$co,UF_CRM_1700489375=>1,'CHECK_PERMISSIONS'=>'N'), array("ID","UF_CRM_1700489375","PARENT_ID_".TYPE_GROUP_ID));

      while($ob = $res->Fetch()) {


$ob=CCrmDeal::GetById($ob['ID'],false);

$arProducts = CCrmDeal::LoadProductRows($ob['ID']);

foreach ($arProducts as $arP)
{
	if ($arP['PRODUCT_ID']==$p) return $ob['ID'];
}


}
}

if ($co<=0) {
	
	global $USER;

$rsUser = CUser::GetByID($USER->GetID());
$arUser = $rsUser->Fetch();

$cos=GetContact($arUser['EMAIL'],$arUser['PERSONAL_PHONE']);

foreach ($cos as $co)	
	{	
	
	$res = CCrmDeal::GetList(array(), array("CONTACT_ID" =>$co,UF_CRM_1700489375=>1,'CHECK_PERMISSIONS'=>'N'), array("ID","UF_CRM_1700489375","PARENT_ID_".TYPE_GROUP_ID));

      while($ob = $res->Fetch()) {


$ob=CCrmDeal::GetById($ob['ID'],false);

$arProducts = CCrmDeal::LoadProductRows($ob['ID']);

foreach ($arProducts as $arP)
{
	if ($arP['PRODUCT_ID']==$p) return $ob['ID'];
}


}

}
	
	
	
	
	
	
	
	
	
	
}

}



function GetBPrice($id)
{
global $DB;
if ($id>0) {
	$arPrice=$DB->Query('select * FROM b_catalog_price where PRODUCT_ID='.$id)->Fetch();
	return $arPrice;
}
	
}



//AddEventHandler('crm', 'OnBeforeCrmDealAdd', 'OnBeforeCrmDealAddf');

function OnBeforeCrmDealAddf(&$arMenu) {
   /**Обработка события**/



   
   global $DB;
   global $USER;
   
   if ($arMenu['CONTACT_ID']<=0) {
	   // То определим контакт из массива
$Order_id=$arMenu['ORDER_ID'];


if ($Order_id>0)
{
	$ui=0;
	
$results=$DB->Query("SELECT * FROM b_sale_order where ID=".$Order_id);
while ($row = $results->Fetch())
{
	$ui=$row['USER_ID'];
}		
	
	
}


$u_phone='';
$u_email='';
	   
if ($ui>0) {
	
	
	
$results=$DB->Query("SELECT * FROM b_user where ID=".$ui);
while ($row = $results->Fetch())
{
	$u_email=$row['EMAIL'];
	$u_phone=$row['PERSONAL_PHONE'];
}	






$ai=GetContact($u_email,$u_phone)[0];	



	
if ($ai>0) {
	$arF['CONTACT_ID']=$ai;
	
	unset($arMenu['COMPANY_ID']);
	
		$entity = new CCrmDeal(false); 
		
		$entity->Update($arMenu['ID'],$arF);
	
}






LogAdd2($arMenu);

	
}

	   
   }
   
}


// запретить изменять раздел для пользователя  OnBeforeIBlockElementUpdate

AddEventHandler("iblock", "OnBeforeIBlockElementUpdate", 'OnBeforeIBlockElementUpdateHandler');

function OnBeforeIBlockElementUpdateHandler(&$arF)
{
	
	if ($arF['MODIFIED_BY']==23260) unset($arF['IBLOCK_SECTION']);
	

LogAdd2($arF);
	
}



AddEventHandler("main", "OnEndBufferContent", "deletePIC");



function deletePIC(&$content)
 {
	
	
	$a2=mb_stripos($content,'<div class="adm-info-message-title">Ошибка</div>');
	
	
	
  $a1=mb_stripos($content,'id="NAME" maxlength="255" value="');  // 32 длина блока
  
  if (1>2) {
  if (($a1>0) && ($a2>0)) {
	  
	  $t=explode('<title>Тренинги: Элемент: ',$content);
	  $t=explode(' - Редактирование - ',$t[1]);
	  $t=$t[0];
  
  
  $c3=mb_substr($content,$a1+32,mb_strlen($content)-$a1-32);
  $c3=explode('"',$c3)[1];
  
  
    
  $content=str_replace('id="NAME" maxlength="255" value="'.$c3.'"','id="NAME" maxlength="255" value="'.$t.'"',$content);
  
  
  

LogAdd2($c3);

  }
  
  }
  
	

 }
 
 // СОбытие создание пользователя
 
 AddEventHandler("main", "OnAfterUserAdd", "OnAfterUserAddHandler");

function OnAfterUserAddHandler(&$arFields)
	{
		
	if (($_REQUEST['register_submit_button']!='') &&  ($arFields['RESULT']) ) {

// отправить сообщение об успешной регистрации

$arEventFieldsF=array("EMAIL"=>$arFields['EMAIL'],"NAME"=>$arFields['NAME']);
CEvent::Send('NEW_USER_CONFIRM', 's3', $arEventFieldsF);

	



LogAdd2($arFields);



	}
	
	
	}

 // 
 
 
 function setPayDeal($idDeal)
 {
	 //  Установить цену для товаров внутри платежки, как в сделке, но с учетом того является ли скидкой
	global $DB;
 
	 
$results=$DB->Query("SELECT * FROM b_crm_order_entity where OWNER_ID=".$idDeal);
while ($row = $results->Fetch())
{
	$Order_id=$row['ORDER_ID'];
}		 
	 


$prices=[];
$acc=[];
$pays=[];
$idp=[];
	if ($Order_id>0) {
$results2=$DB->Query("SELECT * FROM b_sale_order_payment  where ORDER_ID=".$Order_id);
while ($row2 = $results2->Fetch())
{
$prices[]=$row2['SUM'];
$acc[]=$row2['ACCOUNT_NUMBER'];
$pays[]=$row2['PAY_SYSTEM_ID'];
$idp[]=$row2['ID'];
}	 
	 
	
//  Удалить все товары в  данной платежке

$arProducts = CCrmDeal::LoadProductRows($idDeal);


// $DB->Query("delete FROM b_sale_basket where ORDER_ID=".$Order_id);



$basket = Sale\Order::load($Order_id)->getBasket();


foreach ($arProducts as $idP) {

$itemB = $basket->createItem('catalog',$idP['PRODUCT_ID']);
$itemB->setFields(array(
    'QUANTITY' => 1,
	'NAME'=>$idP['PRODUCT_NAME'],
    'CURRENCY' => 'RUB',
    'LID' => 's3',
));

}


$basket->save();

/////
	 
	 
	}
	 
	// 
 }
 
 
 function getContactIDByPhone($id,$phone)
 {
	 

 $f=fopen($_SERVER["DOCUMENT_ROOT"].'/phones.txt','a');
 fwrite($f,print_r($phone,true)."\r\n");
 fclose($f);
	 
// Найти ID телефона по телефону

$rs = CCrmFieldMulti::GetList(
    array(),
    array('ELEMENT_ID' => $id,'ENTITY_ID' => 'CONTACT','TYPE_ID'=>'PHONE')
);

while($arMultiFields = $rs->Fetch()) {
	if ($phone==$arMultiFields['VALUE']) return $arMultiFields['ID'];
}
	 
 }
 
 
 
 function getContactIDByEmail($id,$email)
 {
	 
$rs = CCrmFieldMulti::GetList(
    array(),
    array('ELEMENT_ID' => $id,'ENTITY_ID' => 'CONTACT','TYPE_ID'=>'EMAIL')
);

while($arMultiFields = $rs->Fetch()) {
	if ($email==$arMultiFields['VALUE']) return $arMultiFields['ID'];
}
	
	 
 }
 
 
 function GetByIDPrice($idp)
 {
	

$factory180 = \Bitrix\Crm\Service\Container::getInstance()->getFactory(TYPE_MOD_ID);	
	 
	$products = \Bitrix\Crm\ProductRowTable::getList([
    'select' => ['*'],
    'filter' => [
	
        // 'PRODUCT_NAME' =>  $arP['PRODUCT_NAME'], // ID Товара
		"PRODUCT_ID"=>$idp,
		'OWNER_TYPE' => $factory180->getEntityAbbreviation()
		// 'OWNER_TYPE'=>$factory->getEntityAbbreviation()
    ]
])->fetchAll();


return $products[0];

	 
 }
 
 
 function setContactPhone($phone,$idc)
 {
	 
 }
 
 
 
function OnAfterCrmControlPanelBuildHandler1($arMenu) {
   /**Обработка события**/
   
   if ($arMenu['CATEGORY_ID']==1) {




	global $DB;

global $IOD;

$results=$DB->Query("SELECT * FROM b_crm_order_entity where OWNER_ID=".$arMenu['ID']);
while ($row = $results->Fetch())
{
	$Order_id=$row['ORDER_ID'];
}	

if ($Order_id>0) {
	
$results=$DB->Query("SELECT * FROM b_sale_order_payment where ORDER_ID=".$Order_id);
while ($row = $results->Fetch())
{
	
$st=$row['PAID'];
}	
	
	
}




   


   }
   
   
}





AddEventHandler("main", "OnBeforeUserUpdate", Array("MyClassU", "OnAfterUserUpdateHandler"));
class MyClassU
{
	// создаем обработчик события "OnAfterUserUpdate"
	public static function OnAfterUserUpdateHandler(&$arFields)
	{
		

global $USER;
$rsUser = CUser::GetByID($arFields['ID']);
$arUser = $rsUser->Fetch();

if (($_REQUEST['UF_M_CARDS'][0]>0) && ($arUser['UF_M_CARDS'][0]==0)) {

$arEventFieldsF=array('USER_EMAIL'=>$arUser['EMAIL'],'USER_NAME'=>$arUser['NAME'].' '.$arUser['LAST_NAME']);
CEvent::Send('SEND_DECK_M_CARDS', 's3', $arEventFieldsF);

$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logUser2.txt','w');
fwrite($f,print_r($_REQUEST['UF_M_CARDS'],true));
fclose($f); 	


}

// if ($arUser['UF_M_CARDS']) 



//  Найти данные по текущему USER_ID   SEND_DECK_M_CARDS
		
		
	}
}



///////////////

AddEventHandler("iblock", "OnBeforeIBlockElementUpdate","OnBeforeIBlockElementUpdateHandler2");

	// создаем обработчик события "OnBeforeIBlockElementUpdate"
function OnBeforeIBlockElementUpdateHandler2(&$arFields)
	{
		
$aps=array(763,768);  // Обязательные поля
	
$f=fopen($_SERVER["DOCUMENT_ROOT"].'/logElement.txt','w');
fwrite($f,print_r($arFields,true));
fclose($f); 

if ($arFields['IBLOCK_ID']==10) {
	
$b=0;

foreach ($aps as $v) {
foreach ($arFields['PROPERTY_VALUES'][$v] as $aP) {
	
$block=json_decode($aP['VALUE'],true);
foreach ($block['blocks'] as $arB) {
if ($arB['value']!='') $b=10;
}
}
}



if ($b==0) {
	
			global $APPLICATION;
			$APPLICATION->throwException("Не все обязательные поля заполнены");
			return false;
}
	
}
	
	}


