<?

//////// Скрипт напоминает о записи на завтра

function GetA($e,$a2)
{
	
	foreach ($a2 as $a)
	if ($a==$e) return true;
	return false;
}

$_SERVER["DOCUMENT_ROOT"] = realpath(dirname(__FILE__)."/../..");

set_time_limit(0);

ini_set('max_execution_time', 36000);



	define('USER_ADMIN',1);
	define('IBLOCK_SECTION',3);
	define('DOMEN','mos-clinics.ru');
	define('IBLOCK_CATALOG',14);
	define('SECTION_SERVICE',14);
	define('ASSIGNED_BY_ID',94);
	
define('UF_CRM_1700148623','UF_CRM_1712750486');  // ФИЛИАЛ
	
   //  define('TEST','Y');  // Если Y то позволяет отправлять запрос через ?get=    и без SH
	define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	header("Access-Control-Allow-Headers: X-Requested-With");	
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	
	global $USER;
	
	$USER->Authorize(USER_ADMIN);
	
	// Запросить список сделок на завтра
	$deal = new CCrmDeal(false);
	// ,"UF_CRM_1672234950"=>date('d.m.Y',time())
	
$nextDay =new DateTime();
$nextDay->modify('+1 day');

echo 'Старт: <br>';
	
	
	
// $deals=$deal->GetList([UF_DATE_ZAP=>'ASC'],["STAGE_ID"=>"C1:NEW",">=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 00:00:00'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N']);

$arD=["STAGE_ID"=>"C1:PREPARATION",">=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 00:00:00'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N'];


$arD=["STAGE_ID"=>"PREPARATION",">=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 00:00:00'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N'];


$deals=$deal->GetList([UF_DATE_ZAP=>'DESC'],$arD);


print_r($arD);

	 
	 while($aDeal = $deals->Fetch()) {
		 
		 
echo $aDeal[UF_CRM_1700148623].'<br>';		
		 
		 // Отправить 
		 
		//  print_r($aDeal);
		
		$a=$ids[$aDeal[UF_CRM_1700148623]];
		
		print_r($a);
		 
		 if((CModule::IncludeModule("bizproc")) && (!GetA($aDeal['CONTACT_ID'],$a))) {
			 
			 
			 echo 'AAA:';
			  print_r($aDeal['ID']);
			  echo '<br><br>';
			  
			  
			  
			 
			 
			 $ids[$aDeal[UF_CRM_1700148623]][]=$aDeal['CONTACT_ID'];
			 
			 echo 'Отправили '.$aDeal['CONTACT_ID'].'<br>';





     $wfId=CBPDocument::StartWorkflow(
     363,
     array('crm', 'CCrmDocumentDeal', 'DEAL_'.$aDeal['ID']),
     array(),
     $arErrors
     );







echo 'Результат запуска БП<br>'.'!'.$wfId.'@';
		 print_r($arErrors);

}
		 
		 
	 } 
	
	

	
// $USER->Logout();
	
?><?





?>
