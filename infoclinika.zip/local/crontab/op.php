<?


set_time_limit(0);

ini_set('max_execution_time', 36000);

// Скрипт запуска Бизне процесса Клиент  Опоздал  каждые 2 минут

	define('USER_ADMIN',1);
	define('IBLOCK_SECTION',3);
	define('DOMEN','mos-clinics.ru');
	define('IBLOCK_CATALOG',14);
	define('SECTION_SERVICE',14);
	define('ASSIGNED_BY_ID',94);

	
ob_start();
	
   //  define('TEST','Y');  // Если Y то позволяет отправлять запрос через ?get=    и без SH
	define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	header("Access-Control-Allow-Headers: X-Requested-With");	
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	
	global $USER;
	
	$USER->Authorize(USER_ADMIN);
	
	
	
	// Запросить список сделок на завтра
	$deal = new CCrmDeal(false);
	// ,"UF_CRM_1672234950"=>date('d.m.Y',time())
	
$nextDay =new DateTime();
$nextDay->modify('-10 min');

$nextDay2 =new DateTime();
$nextDay2->modify('-12 min');
	
	// // $arFilter=["!STAGE_ID"=>array("EXECUTING","FINAL_INVOICE","WON"),"<=".UF_DATE_ZAP=>$nextDay2->format('d.m.Y H:i:s'),">=".UF_DATE_ZAP=>$nextDay2->format('d.m.Y H:i:s')];
	
	$arFilter=["!STAGE_ID"=>array("EXECUTING","FINAL_INVOICE","WON",'LOSE'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y H:i:s'),">=".UF_DATE_ZAP=>$nextDay2->format('d.m.Y H:i:s'),"CHECK_PERMISSIONS"=>'N'];
	


	
	print_r($arFilter);
	
	echo '<br><br>';
	
$d=[];
$d2=[];

$deals=$deal->GetList(["UF_CRM_1665671704049"=>'ASC'],$arFilter);
$ids=array();
	 
	 while($aDeal = $deals->Fetch()) {

$nextDay3 =new DateTimeImmutable($aDeal[UF_DATE_ZAP]);
		 
$i2=$nextDay2->format('U');		
$i1=$nextDay->format('U');		
$i3=$nextDay3->format('U');		


 print_r($aDeal);
 

$arfS=array('STAGE_ID'=>'EXECUTING');
$deal = new CCrmDeal(false);
$deal->Update($aDeal['ID'],$arfS);

echo 'Обновить'.$aDeal['ID'];
print_r($arfS);

$deal->LAST_ERROR;



		




		 
	 }
	 
	 

	 
	 
	$cn=ob_get_contents();

$f=fopen($_SERVER['DOCUMENT_ROOT'].'/local/crontab/logs/ob.txt','a');
fwrite($f,time().':'.$cn."\r\n");
fclose($f);


	 
	 
?>