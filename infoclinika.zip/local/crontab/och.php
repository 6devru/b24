<?



$_SERVER["DOCUMENT_ROOT"] = realpath(dirname(__FILE__)."/../..");

set_time_limit(0);

ini_set('max_execution_time', 36000);



	define('USER_ADMIN',1);
	define('IBLOCK_SECTION',3);
	define('DOMEN','mos-clinics.ru');
	define('IBLOCK_CATALOG',14);
	define('SECTION_SERVICE',14);
	define('ASSIGNED_BY_ID',94);
	

	
   //  define('TEST','Y');  // Если Y то позволяет отправлять запрос через ?get=    и без SH
	define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	header("Access-Control-Allow-Headers: X-Requested-With");	
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	
	global $USER;
	
	$USER->Authorize(USER_ADMIN);
	
	// Запросить список сделок на завтра
	$deal = new CCrmDeal(false);
	// ,"UF_CRM_1672234950"=>date('d.m.Y',time())
	
$nextDay =new DateTime();
 

echo 'Старт: <br>';
	

print_r(array([">=".'UF_CRM_1699612132'=>$nextDay->format('d.m.Y 00:00:00'),"<=".'UF_CRM_1699612132'=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N']));
	
	
// $deals=$deal->GetList([UF_DATE_ZAP=>'ASC'],["STAGE_ID"=>"C1:NEW",">=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 00:00:00'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N']);
$deals=$deal->GetList(['UF_CRM_1699612132'=>'ASC'],["STAGE_ID"=>'C1:NEW',"CATEGORY_ID"=>"1",">=".'UF_CRM_1699612132'=>$nextDay->format('d.m.Y 00:00:00'),"<=".'UF_CRM_1699612132'=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N']);
$ids=array();

// print_r(array(UF_DATE_ZAP=>'ASC'],["STAGE_ID"=>"PREPARATION",">=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 00:00:00'),"<=".UF_DATE_ZAP=>$nextDay->format('d.m.Y 23:59:59'),"CHECK_PERMISSIONS"=>'N'));


	 
	 while($aDeal = $deals->Fetch()) {
		 
		 echo 'DDDD<br>';
		
		 
		 // Отправить 
		 
		//  print_r($aDeal);
		 
		 
		 if((CModule::IncludeModule("bizproc")) && (!in_array($aDeal['CONTACT_ID'],$ids))) {
			 
			  
			  
			 
			 
			 $ids[]=$aDeal['CONTACT_ID'];
			 
			 echo 'Сделка '.$aDeal['ID'].'Контакт '.$aDeal['CONTACT_ID'].'<br>';
			 
			 


	
	$deal = new CCrmDeal(false);
	$db=['STAGE_ID'=>'C1:PREPARATION'];
	$deal->Update($aDeal['ID'],$db);


echo '<br>'.'!'.$wfId.'@';
		 print_r($arErrors);

}
		 
		 
	 } 
	
	

	
// $USER->Logout();
	
?><?





?>
