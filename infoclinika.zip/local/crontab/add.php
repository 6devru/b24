<?

$_SERVER["DOCUMENT_ROOT"] = realpath(dirname(__FILE__)."/../.."); 


/////////// */10 * * * * wget -O /dev/null https://crm.mos-clinics.ru/local/cron/add.php
///////////  Раз в 10 минут, в момент создания сделки
/////////// 

define('UF_CRM_1665671704049','UF_CRM_1699610665');  // Дата записи
define('UF_CRM_1678429942','UF_CRM_1705316974');     // Уведомить от создании Да/Нет

define('UF_CRM_1700148623','UF_CRM_1714485828');                      // Филиалы

function GetA($e,$a2)
{
	
	foreach ($a2 as $a)
	if ($a==$e) return true;
	return false;
}

set_time_limit(0);

ini_set('max_execution_time', 36000);




	define('USER_ADMIN',1);
	define('IBLOCK_SECTION',3);
	define('DOMEN','mos-clinics.ru');
	define('IBLOCK_CATALOG',14);
	define('SECTION_SERVICE',14);
	define('ASSIGNED_BY_ID',94);
	

	
   //  define('TEST','Y');  // Если Y то позволяет отправлять запрос через ?get=    и без SH
	define('UF_CRM_NUMBER_POLICA',"ORIGIN_ID");  // Поле с номером полиса, в него же данные сверяем в битрикс24
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	header("Access-Control-Allow-Headers: X-Requested-With");	
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	
	global $USER;
	
	$USER->Authorize(USER_ADMIN);
	
	// Запросить список сделок на завтра
	$deal = new CCrmDeal(false);
	// ,"UF_CRM_1672234950"=>date('d.m.Y',time())
	
$nextDay =new DateTime();

$d1=$nextDay->format('d.m.Y H:i:s');
$nextDay->modify('-10 minutes');

$d2=$nextDay->format('d.m.Y H:i:s');
$nextDay->modify('-10 minutes');

$d3=$nextDay->format('d.m.Y H:i:s');
	

$contacts=[];

// $deals=$deal->GetList(["ID"=>'DESC'],[">=DATE_CREATE"=>$d2,"<=DATE_CREATE"=>$d1,"CONTACT_ID"=>	150785]);  // Я

$arF=["STAGE_ID"=>"C1:PREPARATION",">=DATE_CREATE"=>$d2,"<=DATE_CREATE"=>$d1,">".UF_CRM_1665671704049=>date("d.m.Y H:i:s",time()),'CHECK_PERMISSIONS'=>'N'];

// $arF=["STAGE_ID"=>"C1:PREPARATION",UF_CRM_1665671704049=>date("d.m.Y H:i:s",time()),'CHECK_PERMISSIONS'=>'N','CONTACT_ID'=>27223];

print_r($arF);



// $arF=[];

//  unset($arF);

$deals=$deal->GetList(["ID"=>'DESC'],$arF);   // Юля




$ids=array();
	  
	 while($aDeal = $deals->Fetch()) {
		 
		 
		

		 $a=$ids[$aDeal[UF_CRM_1700148623]];
		 
		 
		 if ((!GetA($aDeal['CONTACT_ID'],$a)) && ($aDeal['CONTACT_ID']>0)) $ids[$aDeal[UF_CRM_1700148623]][]=$aDeal['CONTACT_ID'];
		 
	 }
	 
	
foreach ($ids as $filial=>$contacts) {
foreach ($contacts as $contact) {
	
	echo 'Контакт '.$contact.'<br>';
	
	
	

$deals=$deal->GetList([UF_CRM_1665671704049=>'ASC',"ID"=>'ASC'],["CONTACT_ID"=>$contact,">=DATE_CREATE"=>$d2,UF_CRM_1700148623=>$filial,"<=DATE_CREATE"=>$d1,">".UF_CRM_1665671704049=>date("d.m.Y H:i:s",time())]);	 



$D=0;

$dt=[];

while($aDeal = $deals->Fetch()) {
	
	
	
	
;
	
	
	echo 'ID=';
	print_r($aDeal['ID']);
	echo '<br>';
	
	
	
	//if (!in_array(explode(' ',$aDeal[UF_CRM_1665671704049])[0],$dt)) { 
	
	if ($D==0) {
	
	echo '123';
	
	
	$dt[]=explode(' ',$aDeal[UF_CRM_1665671704049])[0];
	
	// Проверяет есть ли данные для предыдущего участка в 10 минут где было отправлено
	$deals2=$deal->GetList([UF_CRM_1665671704049=>'ASC',"ID"=>'ASC'],['UF_CRM_1700148623'=>$filial,"CONTACT_ID"=>$contact,">=DATE_CREATE"=>$d3,"<=DATE_CREATE"=>$d2,UF_CRM_1678429942=>1,"<".UF_CRM_1665671704049=>$aDeal[UF_CRM_1665671704049]]);	 	


	$dd2=0;
	while($aDeal2 = $deals2->Fetch()) {
		$dd2=$aDeal2['ID'];


		
	}
	
	
	echo '@uf='.$aDeal[UF_CRM_1678429942].'@dd2='.$dd2.'@';
	
	
	// 
	
	if (($aDeal[UF_CRM_1678429942]<=0) && ($dd2<=0)) {
		
		$D=10;
		
		
		
	
	$da=[UF_CRM_1678429942=>1];
	$deal->Update($aDeal['ID'],$da);
	echo 'Шлет этому '.$aDeal['ID'].' дата '.$aDeal['DATE_CREATE'].' дата записи '.$aDeal[UF_CRM_1665671704049].'<br>';
	
	
	$wfId=CBPDocument::StartWorkflow(
19,
array('crm', 'CCrmDocumentDeal', 'DEAL_'.$aDeal['ID']),
array(),
$arErrors
);

echo 'Удачный БП: '.$wfId.' DEAL_'.$aDeal['ID'].'<br>';
	
	
	} else {
		
	$deal = new CCrmDeal(false);	
	$da=[UF_CRM_1678429942=>1];
	$deal->Update($aDeal['ID'],$da);
	
	echo 'НЕТ @@@@';
	echo 'обновить для '.$aDeal['ID'];
		
	
		
	}
	
	
	}
	

	
	$D=10;

}
	

}
	 
}
	 


print_r($contracts);
	
	

	

	
?><?


$f=fopen($_SERVER["DOCUMENT_ROOT"].'/local/crontab/logs/add.txt','a');
fwrite($f,'Время '.date(DATE_RFC2822));
fclose($f);




?>
