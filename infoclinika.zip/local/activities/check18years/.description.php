<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arActivityDescription = array(
	"NAME" => GetMessage("NAME"),
	"DESCRIPTION" => GetMessage("DESCRIPTION"),
	"TYPE" => "activity",
	"CLASS" => "Check18Years",
	"JSCLASS" => "BizProcActivity",
	"CATEGORY" => array(
		"ID" => "rest",
	),
	'RETURN' => [
		'is18OrOlder' => [
			'NAME' => GetMessage('is18OrOlder'),
			'TYPE' => 'bool',
		],
		'debug' => [
			'NAME' => GetMessage('debug'),
			'TYPE' => 'string',
		],
	],
);
?>
