<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
?>

<tr>
    <td align="right" width="40%"><span style="color:#FF0000;"><?= GetMessage("DATE_BIRTHDAY") ?>*:</td>
    <td width="60%">
        <input type="text" name="userBirthday" id="id_userBirthday" value="<?= htmlspecialchars($arCurrentValues["userBirthday"]) ?>" size="50">
        <input type="button" value="..." onclick="BPAShowSelector('id_userBirthday', 'string');">
    </td>
</tr>