<?
$MESS ['DATE_BIRTHDAY'] = "Дата рождения";
?>
