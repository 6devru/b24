<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
{
    die();
}

class CBPCheck18Years extends CBPActivity
{
    public function __construct($name)
    {
        parent::__construct($name);
        $this->arProperties = [
            "userBirthday" => "",

            //return properties
            "is18OrOlder" => true,
            "debug" => 'empty',
        ];

        //return properties mapping
        $this->SetPropertiesTypes([
            'is18OrOlder' => [
                'Type' => 'bool',
            ],
            'debug' => [
                'Type' => 'string',
            ],
        ]);
    }

    public function Execute()
    {
        if (strlen($this->userBirthday) > 0&& $this->userBirthday!=date('d.m.Y',time()))
        {
            /*$birthday=$this->userBirthday;
            if(gettype($isString)=='string') {
                $birthday = strtotime($birthday);
            }*/
			$birthday = strtotime($this->userBirthday);

            $min = strtotime('+18 years', $birthday);

            if(time() < $min)  {
                $this->is18OrOlder=false;
            }
			$this->debug ='DEBUG: '. "\r\n".' 1.1.Какая Дата пришла из б24: '.$this->userBirthday
			."\r\n".' 1.2. Timestamp пришедшей из б24 даты: '.$birthday
			."\r\n".' 1.5.Тип пришедшей даты: '.gettype($isString)
			."\r\n".' 2.1. Дата 18 летия (от сегодня): '.date('d-m-Y',$min)
			."\r\n".' 2.2. Дата 18 летия (от сегодня) timestamp: '.$min
			."\r\n".' 3.1. Текущая дата: '.date('d-m-Y',time())
			."\r\n".' 3.2. Текущая дата timestamp: '.time()
			."\r\n";
        }

        // Возвратим исполняющей системе указание, что действие завершено
        return CBPActivityExecutionStatus::Closed;
    }

    public static function GetPropertiesDialog($documentType, $activityName, $arWorkflowTemplate, $arWorkflowParameters, $arWorkflowVariables, $arCurrentValues = null, $formName = "")
    {
        $runtime = CBPRuntime::GetRuntime();

        if (!is_array($arWorkflowParameters))
        {
            $arWorkflowParameters = [];
        }
        if (!is_array($arWorkflowVariables))
        {
            $arWorkflowVariables = [];
        }

        // Если диалог открывается первый раз, то подгружаем значение
        // свойства, которое было сохранено в шаблоне бизнес-процесса
        if (!is_array($arCurrentValues))
        {
            $arCurrentValues = ["userBirthday" => ""];

            $arCurrentActivity = &CBPWorkflowTemplateLoader::FindActivityByName($arWorkflowTemplate, $activityName);
            if (is_array($arCurrentActivity["Properties"]))
            {
                $arCurrentValues["userBirthday"] = $arCurrentActivity["Properties"]["userBirthday"];
            }
        }

        // Код, формирующий диалог, расположен в отдельном файле
        // properties_dialog.php в папке действия.
        // Возвращаем этот код.
        return $runtime->ExecuteResourceFile(__FILE__, "properties_dialog.php", [
                "arCurrentValues" => $arCurrentValues,
                "formName" => $formName,
            ]);
    }

    public static function GetPropertiesDialogValues($documentType, $activityName, &$arWorkflowTemplate, &$arWorkflowParameters, &$arWorkflowVariables, $arCurrentValues, &$arErrors)
    {
        $arErrors = array();

        $runtime = CBPRuntime::GetRuntime();

        if (empty($arCurrentValues["userBirthday"]))
        {
            $arErrors[] = array(
                "code" => "emptyCode",
                "message" => GetMessage("MYACTIVITY_EMPTY_TEXT"),
            );
            return false;
        }

        $arProperties = array("userBirthday" => $arCurrentValues["userBirthday"]);

        $arCurrentActivity = &CBPWorkflowTemplateLoader::FindActivityByName(
            $arWorkflowTemplate,
            $activityName
        );
        $arCurrentActivity["Properties"] = $arProperties;

        return true;
    }
}

?>