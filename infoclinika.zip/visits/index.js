const FORM_VISIT = document.querySelector("[data-id='popup-visit']");
if (FORM_VISIT != null) {
  const OPEN_FORM = FORM_VISIT.querySelector("[data-id='popup-open']");
  const CLOSE_FORM = FORM_VISIT.querySelector("[data-id='popup-close']");

  FORM_VISIT.addEventListener("submit", (e) => {
    e.preventDefault();
    const btnClicked = e.submitter;

    if (btnClicked.getAttribute("data-id") == "reject") {
	
		
      FORM_VISIT.classList.add("reject");
    } else {
      FORM_VISIT.classList.add("success");
    }

    setTimeout(() => {
      FORM_VISIT.classList.remove("active");

      setTimeout(() => {
        FORM_VISIT.classList.remove("success");
        FORM_VISIT.classList.remove("reject");
        FORM_VISIT.reset();
      }, 1000);
    }, 200000);
  });
  if (OPEN_FORM != null) {
    OPEN_FORM.addEventListener("click", () => {
      FORM_VISIT.classList.add("active");
    });
  }

  if (CLOSE_FORM != null) {
    CLOSE_FORM.addEventListener("click", () => {
      FORM_VISIT.classList.remove("active");
     FORM_VISIT.reset();
    });
  }
}

const FORM_FEEDBACK = document.querySelector("[data-id='popup-feedback']");
if (FORM_FEEDBACK != null) {
  const OPEN_FORM_FEEDBACK = FORM_FEEDBACK.querySelector(
    "[data-id='popup-open']"
  );
  const CLOSE_FORM_FEEDBACK = FORM_FEEDBACK.querySelector(
    "[data-id='popup-close']"
  );
  const FEEDBACK_TEXTBOX = FORM_FEEDBACK.querySelector(
    "[data-id='popup-feedback-textbox']"
  );
  let itemSelected = null;

  FORM_FEEDBACK.addEventListener("submit", (e) => {
    e.preventDefault();
    const btnClicked = e.submitter;

    if (itemSelected == null) return;

    if (btnClicked.getAttribute("data-id") == "confirm") {
		

		
      FORM_FEEDBACK.classList.add("success");
      console.log(itemSelected);

      setTimeout(() => {
        FORM_FEEDBACK.classList.remove("active");

        setTimeout(() => {
          FORM_FEEDBACK.classList.remove("success");
          FORM_FEEDBACK.reset();
        }, 1000);
      }, 200000);
    } else {
      FORM_FEEDBACK.classList.remove("active");
      FEEDBACK_TEXTBOX.classList.remove("active");
      FORM_FEEDBACK.reset();
    }
  });

  const BTNS_EVALUATIONS = FORM_FEEDBACK.querySelectorAll(
    "[name='popup-feedback-radio']"
  );

  BTNS_EVALUATIONS.forEach((item) => {
    item.addEventListener("click", () => {
      itemSelected = item.id;

      if (
        item.id != "popup-feedback-radio-10" &&
        item.id != "popup-feedback-radio-9" &&
        item.id != "popup-feedback-radio-8" &&
		item.id != "popup-feedback-radio-7"
      ) {
        if (!FEEDBACK_TEXTBOX.classList.contains("active")) {
          FEEDBACK_TEXTBOX.classList.add("active");
        }
      } else {
        FEEDBACK_TEXTBOX.classList.remove("active");
        FEEDBACK_TEXTBOX.value = "";
      }
    });
  });

  if (OPEN_FORM_FEEDBACK != null) {
    OPEN_FORM_FEEDBACK.addEventListener("click", () => {
      FORM_FEEDBACK.classList.add("active");
    });
  }

  if (CLOSE_FORM_FEEDBACK != null) {
    CLOSE_FORM_FEEDBACK.addEventListener("click", () => {
      FORM_FEEDBACK.classList.remove("active");
      FEEDBACK_TEXTBOX.classList.remove("active");
      FORM_FEEDBACK.reset();
    });
  }
}



$( ".confirm" ).click(function() {
	

	
	
	
	add='?add=Y';
	if ($('.popup-visit-feedback__evaluation-item input:checked ~ span').length>0) {
		var ocenka=$('.popup-visit-feedback__evaluation-item input:checked ~ span').html();
		
		if (ocenka>8) $('.popup-visit-feedback__content-extra-text').html('Спасибо за Вашу высокую оценку. <br>Будем благодарны за Ваш <a href="https://yandex.ru/maps/-/CCUGuLC4hD">отзыв на Яндексе</a>');
		
		add='?back=Y';
		var text2=$('.popup-visit-feedback .popup-visit-feedback__evaluations-feedback-textbox')[0].value;
	}
	
$.get( '/visits/'+CODES+'/'+add+'&text='+text2+'&ocenka='+ocenka, function( data ) {
    
});
});


$( ".reject" ).click(function() {
$.get( window.location+'?add=N', function( data ) {
  
});
});



