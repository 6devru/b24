<?

define('CODE','UF_CRM_1717500155');  // Код сделки
define('DATAZ','UF_CRM_1712750980'); // Дата регистрации
define('UF_CRM_1699610767','UF_CRM_1712751136'); // Список для регистрации
define('UF_CRM_1699610767_Y','83');
define('UF_CRM_1699610767_N','84');

define('UF_CRM_1700148623','UF_CRM_1712750486'); // Филиал

define('PHONE_TEXT',array('32'=>'1111111'));

define('UF_CRM_OCENKA','UF_CRM_1717501593');  // Оценка список от 1 до 5
define('UF_CRM_OCENKA_TEXT','UF_CRM_1717501769'); // Текст отзыва

$code=explode('?',$_SERVER['REQUEST_URI']);
$cod=explode('/',$code[0]);
$cod=$cod[2];

include('define.php');

	define('USER_ADMIN',94);

	
	require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php');
	
global $USER;
$USER->Authorize(1);
	

	use Bitrix\Crm\Service;
	\Bitrix\Main\Loader::includeModule('crm');
	
	global $USER;
	


if (strlen($cod)>3) {

$deal = new CCrmDeal(false);	
$deals=$deal->GetList([],[CODE=>$cod])->fetch();



$deal = new CCrmDeal(false);

 $da=array(UF_CRM_1699610767=>UF_CRM_1699610767_Y);
 $db=array(UF_CRM_1699610767=>UF_CRM_1699610767_N);

if ($_REQUEST['back']=='') {
if ($_REQUEST['add']=='Y') {
	$dd=$deal->Update($deals['ID'],$da);
	
	if (($deals['CONTACT_ID']>0) && ($deals[DATAZ]!='')) {
		
		$dt=strtotime($deals[DATAZ]);
$deals2=$deal->GetList(["ID"=>'DESC'],["CONTACT_ID"=>$deals['CONTACT_ID'],UF_CRM_1700148623=>$deals[UF_CRM_1700148623],">=".DATAZ=>date('d.m.Y 00:00:00',$dt),"<=".DATAZ=>date('d.m.Y 23:59:59',$dt)]);
	 
	 while($aDeal = $deals2->Fetch()) {
$dd=$deal->Update($aDeal['ID'],$da);



CCrmBizProcHelper::AutoStartWorkflows(CCrmOwnerType::Deal, $aDeal['ID'], CCrmBizProcEventType::Edit, $arErrors, null );  
$starter = new \Bitrix\Crm\Automation\Starter(\CCrmOwnerType::Deal, $aDeal['ID']);

$factory = Service\Container::getInstance()->getFactory(CCrmOwnerType::Deal);
$item = $factory->getItem($aDeal['ID']);
$operation = $factory->getUpdateOperation($item);
$operation->enableCheckWorkflows()->enableBizProc()->enableAutomation();

$result = $operation->launch();
if (!$result->isSuccess())
{
    print_r($result->getErrorMessages());
} else {
	echo 'OK';
}



	 }		 
		
		
	}
	
	
	
}
if ($_REQUEST['add']=='N') {
	$dd=$deal->Update($deals['ID'],$db);
	
	if (($deals['CONTACT_ID']>0) && ($deals[DATAZ]!='')) {
		
		$dt=strtotime($deals[DATAZ]);
$deals2=$deal->GetList(["ID"=>'DESC'],["CONTACT_ID"=>$deals['CONTACT_ID'],UF_CRM_1700148623=>$deals[UF_CRM_1700148623],">=".DATAZ=>date('d.m.Y 00:00:00',$dt),"<=".DATAZ=>date('d.m.Y 23:59:59',$dt)]);
	 
	 while($aDeal = $deals2->Fetch()) {
$dd=$deal->Update($aDeal['ID'],$db);

CCrmBizProcHelper::AutoStartWorkflows(CCrmOwnerType::Deal, $aDeal['ID'], CCrmBizProcEventType::Edit, $arErrors, null );  
$starter = new \Bitrix\Crm\Automation\Starter(\CCrmOwnerType::Deal, $aDeal['ID']);

$factory = Service\Container::getInstance()->getFactory(CCrmOwnerType::Deal);
$item = $factory->getItem($aDeal['ID']);
$operation = $factory->getUpdateOperation($item);
$operation->enableCheckWorkflows()->enableBizProc()->enableAutomation();



	 }		 
		
		
	}
	
	
}
} else { 

if ($_REQUEST['ocenka']>0) {
	$db=array(UF_CRM_OCENKA=>($_REQUEST['ocenka']+97),UF_CRM_OCENKA_TEXT=>$_REQUEST['text']);
	if (($deals[UF_CRM_OCENKA]=='')  || ($deals[UF_CRM_OCENKA_TEXT]=='')) $dd=$deal->Update($deals['ID'],$db);
	

CCrmBizProcHelper::AutoStartWorkflows(CCrmOwnerType::Deal, $deals['ID'], CCrmBizProcEventType::Edit, $arErrors, null );  
$starter = new \Bitrix\Crm\Automation\Starter(\CCrmOwnerType::Deal, $deals['ID']);

$factory = Service\Container::getInstance()->getFactory(CCrmOwnerType::Deal);
$item = $factory->getItem($deals['ID']);
$operation = $factory->getUpdateOperation($item);
$operation->enableCheckWorkflows()->enableBizProc()->enableAutomation();
	
}
}

if ($deals['CONTACT_ID']>0) {
	
$contact = new CCrmContact(false);	 
$contacts=$contact->GetList([],["ID"=>$deals['CONTACT_ID']])->fetch();

	
}
	




}

if ($deals['ID']<=0) {
	header("HTTP/1.0 404 Not Found");
	
	?>
	
	<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="/visits/main.css" />
  </head>
  <body>
    <form data-id="popup-visit" class="popup-visit-feedback active reject">
      <div class="popup-visit-feedback__wrapper">
        <div class="popup-visit-feedback__content">
          <div class="popup-visit-feedback__content-inner-wrapper small">
            <div data-id="popup-close" class="popup-visit-feedback__cross">
              <span>
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.91663 2.91663L11.0833 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                  <path
                    d="M11.0833 2.91663L2.91663 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                </svg>
              </span>
            </div>
			
			
			
          
			
			
			
            <div class="popup-visit-feedback__content-success">
              <div class="popup-visit-feedback__content-extra-icon">
                <svg
                  width="52"
                  height="52"
                  viewBox="0 0 52 52"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M26 0C11.6637 0 0 11.6637 0 26C0 40.3363 11.6637 52 26 52C40.3363 52 52 40.3363 52 26C52 11.6637 40.3363 0 26 0ZM39.5312 17.2863L22.7313 37.2863C22.547 37.5057 22.3177 37.6831 22.0589 37.8062C21.8001 37.9294 21.5178 37.9955 21.2313 38H21.1975C20.9172 37.9999 20.64 37.9409 20.384 37.8267C20.1279 37.7126 19.8987 37.5459 19.7113 37.3375L12.5112 29.3375C12.3284 29.1436 12.1862 28.915 12.0929 28.6653C11.9996 28.4156 11.9572 28.1498 11.9681 27.8835C11.9791 27.6171 12.0431 27.3557 12.1565 27.1145C12.27 26.8733 12.4305 26.6571 12.6286 26.4788C12.8267 26.3005 13.0585 26.1636 13.3103 26.0762C13.5621 25.9887 13.8288 25.9525 14.0948 25.9696C14.3608 25.9867 14.6207 26.0568 14.8592 26.1758C15.0978 26.2948 15.3101 26.4603 15.4837 26.6625L21.145 32.9525L36.4688 14.7138C36.8125 14.3163 37.2988 14.0702 37.8226 14.0284C38.3463 13.9867 38.8655 14.1528 39.2678 14.4907C39.6701 14.8287 39.9233 15.3114 39.9726 15.8345C40.0219 16.3576 39.8634 16.8791 39.5312 17.2863Z"
                    fill="#16BE45"
                  />
                </svg>
              </div>
              <p class="popup-visit-feedback__content-extra-text">
                Благодарим!<br />Ваш визит подтвержден
              </p>
            </div>
            <div class="popup-visit-feedback__content-reject">
              <div class="popup-visit-feedback__content-extra-icon">
                <svg
                  width="52"
                  height="46"
                  viewBox="0 0 52 46"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M24.16 1.50989L0.839991 41.8999C0.654479 42.2232 0.55707 42.5896 0.557497 42.9623C0.557923 43.3351 0.656172 43.7012 0.842423 44.0241C1.02868 44.3471 1.29641 44.6154 1.61887 44.8024C1.94133 44.9895 2.30722 45.0886 2.67999 45.0899H49.32C49.6928 45.0886 50.0587 44.9895 50.3811 44.8024C50.7036 44.6154 50.9713 44.3471 51.1576 44.0241C51.3438 43.7012 51.4421 43.3351 51.4425 42.9623C51.4429 42.5896 51.3455 42.2232 51.16 41.8999L27.84 1.50989C27.6524 1.18826 27.3838 0.921407 27.061 0.735943C26.7381 0.550478 26.3723 0.452881 26 0.452881C25.6277 0.452881 25.2618 0.550478 24.939 0.735943C24.6161 0.921407 24.3476 1.18826 24.16 1.50989Z"
                    fill="#FFCB00"
                  />
                  <path
                    d="M23 36.0001C23 35.4067 23.1759 34.8267 23.5056 34.3334C23.8352 33.84 24.3038 33.4555 24.8519 33.2285C25.4001 33.0014 26.0033 32.942 26.5853 33.0577C27.1672 33.1735 27.7017 33.4592 28.1213 33.8788C28.5409 34.2983 28.8266 34.8329 28.9423 35.4148C29.0581 35.9968 28.9987 36.6 28.7716 37.1481C28.5446 37.6963 28.16 38.1649 27.6667 38.4945C27.1733 38.8241 26.5933 39.0001 26 39.0001C25.6015 39.0171 25.2038 38.9511 24.8321 38.8063C24.4605 38.6616 24.1229 38.4412 23.8409 38.1592C23.5589 37.8771 23.3385 37.5396 23.1937 37.1679C23.049 36.7963 22.983 36.3986 23 36.0001ZM24.09 31.3401L23.33 16.3401H28.59L27.86 31.3401H24.09Z"
                    fill="#353535"
                  />
                </svg>
              </div>
              <p class="popup-visit-feedback__content-extra-text">404 Страница не найдена</p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-visit-feedback__backdrop"></div>
    </form>
  </body>
  
  <script  src="https://code.jquery.com/jquery-3.6.3.js"></script>
  
  <script>
  var CODES="<?=$cod;?>";
  </script>
  
  <script src="/visits/index.js"></script>
  
  
</html>
	
	
	
	
<?
	
	
	
} else {
	


if ($_REQUEST['back']=='') {


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="/visits/main.css" />
  </head>
  <body>
    <form data-id="popup-visit" class="popup-visit-feedback active <? if ($deals['UF_CRM_1670514831298']==47) echo 'success';?> <? if ($deals['UF_CRM_1670514831298']==48) echo 'reject';?> ">
      <div class="popup-visit-feedback__wrapper">
        <div class="popup-visit-feedback__content">
          <div class="popup-visit-feedback__content-inner-wrapper small">
            <div data-id="popup-close" class="popup-visit-feedback__cross">
              <span>
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.91663 2.91663L11.0833 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                  <path
                    d="M11.0833 2.91663L2.91663 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                </svg>
              </span>
            </div>
			
			
			
            <div class="popup-visit-feedback__content-main">
              <div class="popup-visit-feedback__icon">
                <img src="/visits/logo_<?=$deals[UF_CRM_1700148623];?>.jpg" alt="flower icon form" />
              </div>
              <p class="popup-visit-feedback__title">
                <?=$contacts['NAME'];?> <?=$contacts['SECOND_NAME'];?>, подтвердите визит
              </p>
              <p class="popup-visit-feedback__text">
                Просим подтвердить Ваш визит, нажав на кнопку “Подтвердить”.
                Если Вы хотите перенести визит, свяжитесь с нами по телефону
                <span class="popup-visit-feedback__text bold"><?=PHONE_TEXT[$deals[UF_CRM_1700148623]];?></span>
              </p>
              <div class="popup-visit-feedback__btns">
                <button data-id="reject" type="submit" class="popup-visit-feedback__btn reject">
                  Отклонить
                </button>
                <button data-id="confirm" type="submit" class="popup-visit-feedback__btn confirm btn-blue">
                  
                  Подтвердить
                </button>
              </div>
            </div>
			
			
			
            <div class="popup-visit-feedback__content-success">
              <div class="popup-visit-feedback__content-extra-icon">
                <svg
                  width="52"
                  height="52"
                  viewBox="0 0 52 52"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M26 0C11.6637 0 0 11.6637 0 26C0 40.3363 11.6637 52 26 52C40.3363 52 52 40.3363 52 26C52 11.6637 40.3363 0 26 0ZM39.5312 17.2863L22.7313 37.2863C22.547 37.5057 22.3177 37.6831 22.0589 37.8062C21.8001 37.9294 21.5178 37.9955 21.2313 38H21.1975C20.9172 37.9999 20.64 37.9409 20.384 37.8267C20.1279 37.7126 19.8987 37.5459 19.7113 37.3375L12.5112 29.3375C12.3284 29.1436 12.1862 28.915 12.0929 28.6653C11.9996 28.4156 11.9572 28.1498 11.9681 27.8835C11.9791 27.6171 12.0431 27.3557 12.1565 27.1145C12.27 26.8733 12.4305 26.6571 12.6286 26.4788C12.8267 26.3005 13.0585 26.1636 13.3103 26.0762C13.5621 25.9887 13.8288 25.9525 14.0948 25.9696C14.3608 25.9867 14.6207 26.0568 14.8592 26.1758C15.0978 26.2948 15.3101 26.4603 15.4837 26.6625L21.145 32.9525L36.4688 14.7138C36.8125 14.3163 37.2988 14.0702 37.8226 14.0284C38.3463 13.9867 38.8655 14.1528 39.2678 14.4907C39.6701 14.8287 39.9233 15.3114 39.9726 15.8345C40.0219 16.3576 39.8634 16.8791 39.5312 17.2863Z"
                    fill="#16BE45"
                  />
                </svg>
              </div>
              <p class="popup-visit-feedback__content-extra-text">
                Благодарим!<br />Ваш визит подтвержден
              </p>
            </div>
            <div class="popup-visit-feedback__content-reject">
              <div class="popup-visit-feedback__content-extra-icon">
                <svg
                  width="52"
                  height="46"
                  viewBox="0 0 52 46"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M24.16 1.50989L0.839991 41.8999C0.654479 42.2232 0.55707 42.5896 0.557497 42.9623C0.557923 43.3351 0.656172 43.7012 0.842423 44.0241C1.02868 44.3471 1.29641 44.6154 1.61887 44.8024C1.94133 44.9895 2.30722 45.0886 2.67999 45.0899H49.32C49.6928 45.0886 50.0587 44.9895 50.3811 44.8024C50.7036 44.6154 50.9713 44.3471 51.1576 44.0241C51.3438 43.7012 51.4421 43.3351 51.4425 42.9623C51.4429 42.5896 51.3455 42.2232 51.16 41.8999L27.84 1.50989C27.6524 1.18826 27.3838 0.921407 27.061 0.735943C26.7381 0.550478 26.3723 0.452881 26 0.452881C25.6277 0.452881 25.2618 0.550478 24.939 0.735943C24.6161 0.921407 24.3476 1.18826 24.16 1.50989Z"
                    fill="#FFCB00"
                  />
                  <path
                    d="M23 36.0001C23 35.4067 23.1759 34.8267 23.5056 34.3334C23.8352 33.84 24.3038 33.4555 24.8519 33.2285C25.4001 33.0014 26.0033 32.942 26.5853 33.0577C27.1672 33.1735 27.7017 33.4592 28.1213 33.8788C28.5409 34.2983 28.8266 34.8329 28.9423 35.4148C29.0581 35.9968 28.9987 36.6 28.7716 37.1481C28.5446 37.6963 28.16 38.1649 27.6667 38.4945C27.1733 38.8241 26.5933 39.0001 26 39.0001C25.6015 39.0171 25.2038 38.9511 24.8321 38.8063C24.4605 38.6616 24.1229 38.4412 23.8409 38.1592C23.5589 37.8771 23.3385 37.5396 23.1937 37.1679C23.049 36.7963 22.983 36.3986 23 36.0001ZM24.09 31.3401L23.33 16.3401H28.59L27.86 31.3401H24.09Z"
                    fill="#353535"
                  />
                </svg>
              </div>
              <p class="popup-visit-feedback__content-extra-text">Ваш визит отклонен</p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-visit-feedback__backdrop"></div>
    </form>
  </body>
  
  <script  src="https://code.jquery.com/jquery-3.6.3.js"></script>
  
  <script>
  var CODES="<?=$cod;?>";
  </script>
  
  <script src="/visits/index.js"></script>
  
  
</html>

<?

} else { ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="/visits/main.css" />
  </head>
  <body>
<form data-id="popup-feedback" class="popup-visit-feedback active <? if (($deals[UF_CRM_OCENKA]!='')  || ($deals['UF_CRM_DEAL_1674737641834']!='')) echo 'success';?>">
      <div class="popup-visit-feedback__wrapper">
        <div class="popup-visit-feedback__content">
          <div class="popup-visit-feedback__content-inner-wrapper">
            <div data-id="popup-close" class="popup-visit-feedback__cross">
              <span>
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.91663 2.91663L11.0833 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                  <path
                    d="M11.0833 2.91663L2.91663 11.0833"
                    stroke="#040300"
                    stroke-linecap="round"
                  />
                </svg>
              </span>
            </div>
            <div class="popup-visit-feedback__content-main">
              <div class="popup-visit-feedback__icon">
                <img src="/visits/flower.png" alt="flower icon" />
              </div>
              <p class="popup-visit-feedback__title">Обратная связь</p>
              <p class="popup-visit-feedback__text">
                Недавно Вы посетили наш медицинский центр, оцените, пожалуйста,
                вероятность того, что Вы порекомендуете нас другу или коллеге по
                шкале от 0 до 10, где 10 - точно порекомендую, 0 - точно не
                порекомендую
              </p>
              <div class="popup-visit-feedback__evaluations">
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-1"
                  />
                  <span>1</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-2"
                  />
                  <span>2</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-3"
                  />
                  <span>3</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-4"
                  />
                  <span>4</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-5"
                  />
                  <span>5</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-6"
                  />
                  <span>6</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-7"
                  />
                  <span>7</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-8"
                  />
                  <span>8</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-9"
                  />
                  <span>9</span>
                </label>
                <label class="popup-visit-feedback__evaluation-item">
                  <input
                    type="radio"
                    name="popup-feedback-radio"
                    id="popup-feedback-radio-10"
                  />
                  <span>10</span>
                </label>
              </div>
              <textarea
                data-id="popup-feedback-textbox"
                placeholder="Что вам больше всего не понравилось"
                class="popup-visit-feedback__evaluations-feedback-textbox"
              ></textarea>
              <div class="popup-visit-feedback__btns">
               
                <button
                  data-id="confirm"
                  type="submit"
                  class="popup-visit-feedback__btn confirm"
                >
                  Подтвердить
                </button>
              </div>
            </div>
            <div class="popup-visit-feedback__content-success">
              <div style="padding-bottom: 0" class="popup-visit-feedback__icon">
                <img src="/visits/flower.png" alt="flower icon" />
              </div>
              <p class="popup-visit-feedback__content-extra-text">
                Благодарим, за Вашу оценку!
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-visit-feedback__backdrop"></div>
    </form>
  </body>
  
  <script  src="https://code.jquery.com/jquery-3.6.3.js"></script>
  
  <script>
  var CODES="<?=$cod;?>";
  </script>
  
  <script src="/visits/index.js"></script>
</html>




<?

}


}


$USER->logOut();

?>